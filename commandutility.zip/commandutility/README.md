# commandutility

Generate the jar file by building the app.

And run the jar file with following way

java -jar <jarfile> username=<username> password=<password>
