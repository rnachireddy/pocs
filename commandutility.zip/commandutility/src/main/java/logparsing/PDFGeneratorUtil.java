package logparsing;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);
	public final static Font VERY_SMALL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.NORMAL);

	public static void main(String[] args) {
		List<Log> logList = new ArrayList<>();
		List<ParameterSummary> parameterSummaryList = new ArrayList<ParameterSummary>();
		PDFGeneratorUtil.generateReport(logList, parameterSummaryList, "");
	}
	public static void generateReport(List<Log> logList, List<ParameterSummary> parameterSummaryList, String clusterName) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + "\\Report_" + (new Date()).getTime() + ".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			HeaderFooter event = new HeaderFooter();
			event.setHeader(clusterName+" ("+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+")");
			writer.setPageEvent(event);
			document.open();
			addMetaData(document);
			document.add(addEmptyLine());
			document.add(createSummaryTable(parameterSummaryList));
			document.add(addEmptyLine());
			document.add(createErrorWarningTable(logList));
			document.add(addEmptyLine());

			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
		}
	}
	
	private static Paragraph createSummaryTable(List<ParameterSummary> parameterSummaryList) throws IOException {
		Paragraph paragraph = new Paragraph();
		paragraph.add("The following table highlights the monitoring of GcInspector on individual nodes");
		paragraph.add(Chunk.NEWLINE);
		PdfPTable table = createTable(9);
		String headerArray[] = { "Status", "Node IP", "TimeStamp", "Max GC",
				"Commit Log Allocator Count", "SlabPool Cleaner Count",
				"Schedule Task Count", "Compaction Executor Count",
				"Repair Job Task Count" };
		addHeaderInTable(table, headerArray);
		if (parameterSummaryList != null && !parameterSummaryList.isEmpty()) {
			for (ParameterSummary parameterSummary : parameterSummaryList) {
				table.addCell(createCell(parameterSummary.getStatus()));
				table.addCell(createCell(parameterSummary.getNode()));
				table.addCell(createCell(parameterSummary.getTimeStamp()));
				table.addCell(createCell(String.valueOf(parameterSummary.getMaxGC())));
				table.addCell(createCell(String.valueOf(parameterSummary.getCommitLogAllocatorCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getSlabPoolCleanerCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getScheduleTaskCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getCompactionExecutorCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getRepairJobTaskCount())));
					
			}
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph createErrorWarningTable(List<Log> logList) throws IOException {
		Paragraph paragraph = new Paragraph();
		PdfPTable table = createTable(3);
		String headerArray[] = { "Node", "Thread", "Error/Warning Count" };
		addHeaderInTable(table, headerArray);
		if (logList != null && !logList.isEmpty()) {
			for (String host : NodesProcessingUtil.getHosts()) {
				List<Log> logs = logList.stream().filter(data -> {
					return data.getHostName().equals(host)
							&& (data.getLogType().equals("ERROR") || data.getLogType().equals("WARN"));
				}).collect(Collectors.toList());
				Map<String, Integer> map = new HashMap<>();
				logs.stream().forEach(data -> {
					Integer count = map.get(data.getThreadName());
					if (count == null) {
						map.put(data.getThreadName(), 1);
					} else {
						map.put(data.getThreadName(), ++count);
					}
				});
				if (!map.isEmpty()) {
					for (Map.Entry<String, Integer> entry : map.entrySet()) {
						table.addCell(createCell(String.valueOf(host)));
						table.addCell(createCell(String.valueOf(entry.getKey())));
						table.addCell(createCell(String.valueOf(entry.getValue())));
					}
				}
			}
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph addEmptyLine() {
		Paragraph p = new Paragraph();
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		return p;
	}

	private static PdfPTable createTable(int i) {
		PdfPTable table = new PdfPTable(i);
		if (i == 4) {
			table.setWidthPercentage(100);
		} else if (i == 2) {
			table.setWidthPercentage(50);
		} else if (i == 1) {
			table.setWidthPercentage(100);
		} else if (i == 3) {
			table.setWidthPercentage(100);
		} else if (i == 5) {
			table.setWidthPercentage(100);
		} else {
			table.setWidthPercentage(100);
		}

		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		return table;
	}

	private static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.LIGHT_GRAY);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}

	private static void addHeaderInTable(PdfPTable table, String headerArray[]) {

		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			c1.setBorderColor(BaseColor.GRAY);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}
}
