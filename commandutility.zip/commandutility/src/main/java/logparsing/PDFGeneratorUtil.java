package logparsing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import logparsing.model.ClusterViewDetail;
import logparsing.model.KeySpaceDetails;
import logparsing.model.ParameterSummary;

public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.NORMAL);
	public final static Font NORMAL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 6, Font.BOLD);
	public final static Font VERY_SMALL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.NORMAL);
	
	private static final long  MEGABYTE = 1024L * 1024L;
	
	public static void main(String[] args) {
		List<Log> logList = new ArrayList<>();
		PDFGeneratorUtil.generateReport(logList, null, null);
	}

	public static void generateReport(List<Log> logList, Map<String, List<Log>> logMap, ParseRequest request) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + File.separator + "Report_" + (new Date()).getTime() + ".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			HeaderFooter event = new HeaderFooter();
			event.setHeader("Cassandra Log Detailed Summary");
			writer.setPageEvent(event);
			document.open();
			addMetaData(document);
			document.add(Chunk.NEWLINE);
			document.add(overViewSummary());
			document.add(Chunk.NEWLINE);
			document.add(introDetails());
			document.add(addEmptyLine());
			document.add(createSummaryTable(getParameterSummaryList(logMap)));
			document.add(addEmptyLine());
			document.add(createErrorWarningTable(logList));
			document.add(addEmptyLine());
			document.add(createSSCountSummaryTable(request.getSsCountThreshold()));
			document.add(addEmptyLine());
			document.add(createReadPercentSummaryTable(request.getReadPercentageThreshold()));
			document.add(addEmptyLine());
			document.add(createWritePercentSummaryTable(request.getWritePercentageThreshold()));
			document.add(addEmptyLine());
			document.add(createPartMaxSummaryTable(request.getPartMaxThreshold()));
			document.add(addEmptyLine());
			document.add(createCellsMeanSummaryTable(request.getCellsMeanThreshold()));
			document.add(addEmptyLine());
			document.add(createTombstonesMeanSummaryTable(request.getTombstoneMeanThreshold()));
			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
		}
	}

	private static Element createSSCountSummaryTable(String ssCountThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of ss_count from cfstats : ", NORMAL_BOLD));
		int threshold = (ssCountThreshold == null || ssCountThreshold.length() == 0) ? Constants.DEFAULT_SSCOUNT_THRESHOLD : Integer.parseInt(ssCountThreshold);
		paragraph.add(new Chunk("Tables containing sstable count greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(12);
		String headerArray[] = { "State", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				if(Integer.valueOf(data.getSsTablesCount()) > threshold) {
					table.addCell(createCell("INFO"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				}
			});

		}
		paragraph.add(table);
		return paragraph;
	}
	
	private static Element createReadPercentSummaryTable(String readPercentageThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of read_percent from cfstats : ", NORMAL_BOLD));
		int threshold = (readPercentageThreshold == null || readPercentageThreshold.length() == 0) ? Constants.DEFAULT_READ_PERCENTAGE_THRESHOLD : Integer.parseInt(readPercentageThreshold);
		paragraph.add(new Chunk("Tables with node level read percentage greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(14);
		String headerArray[] = { "State", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max read %", "max write %" ,"max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				long maxRead = 0;
				long maxWrite = 0;
				maxRead = getPercentage(data.getTotalReadCount(), data.getLocalReadCount());
				maxWrite = getPercentage(data.getTotalWriteCount(), data.getLocalWriteCount());
				if(maxRead > threshold){
					table.addCell(createCell("INFO"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(maxRead)));
					table.addCell(createCell(String.valueOf(maxWrite)));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				}
			});
		}
		paragraph.add(table);
		return paragraph;
	}
	
	private static Element createWritePercentSummaryTable(String writePercentageThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of write_percent from cfstats : ", NORMAL_BOLD));
		int threshold = (writePercentageThreshold == null || writePercentageThreshold.length() == 0) ? Constants.DEFAULT_WRITE_PERCENTAGE_THRESHOLD : Integer.parseInt(writePercentageThreshold);
		paragraph.add(new Chunk("Tables with node level write percentage greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(14);
		String headerArray[] = { "State", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max read %", "max write %" ,"max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				long maxRead = 0;
				long maxWrite = 0;
				maxRead = getPercentage(data.getTotalReadCount(), data.getLocalReadCount());
				maxWrite = getPercentage(data.getTotalWriteCount(), data.getLocalWriteCount());
				if(maxWrite > threshold){
					table.addCell(createCell("INFO"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(maxRead)));
					table.addCell(createCell(String.valueOf(maxWrite)));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				}
			});
		}
		paragraph.add(table);
		return paragraph;
	}
	
	private static Element createPartMaxSummaryTable(String partMaxThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of part_max from cfstats : ", NORMAL_BOLD));
		int threshold = (partMaxThreshold == null || partMaxThreshold.length() == 0) ? Constants.DEFAULT_PART_MAX_THRESHOLD : Integer.parseInt(partMaxThreshold);
		paragraph.add(new Chunk("Tables with max partition size (MB) greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(15);
		String headerArray[] = { "State", "Analysis Type", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max read %", "max write %" ,"max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				long maxRead = 0;
				long maxWrite = 0;
				maxRead = getPercentage(data.getTotalReadCount(), data.getLocalReadCount());
				maxWrite = getPercentage(data.getTotalWriteCount(), data.getLocalWriteCount());
				long maxPartition = parseBytesToMb(data.getMaxPartition());
				if(maxPartition > threshold){
					table.addCell(createCell("INFO"));
					table.addCell(createCell("max_part"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(maxRead)));
					table.addCell(createCell(String.valueOf(maxWrite)));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				}
			});
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Element createCellsMeanSummaryTable(String cellsMeanThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of cells_mean from cfstats : ", NORMAL_BOLD));
		int threshold = (cellsMeanThreshold == null || cellsMeanThreshold.length() == 0) ? Constants.DEFAULT_CELL_MEAN_THRESHOLD : Integer.parseInt(cellsMeanThreshold);
		paragraph.add(new Chunk("Tables with average cells requested greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(14);
		String headerArray[] = { "State", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max read %", "max write %" ,"max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				long maxRead = 0;
				long maxWrite = 0;
				maxRead = getPercentage(data.getTotalReadCount(), data.getLocalReadCount());
				maxWrite = getPercentage(data.getTotalWriteCount(), data.getLocalWriteCount());
				long cellsMean = data.getCellsMean().equalsIgnoreCase("NaN")?0:(long)Double.parseDouble(data.getCellsMean());
				if(cellsMean > threshold){
					table.addCell(createCell("INFO"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(maxRead)));
					table.addCell(createCell(String.valueOf(maxWrite)));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				} else {
					paragraph.add(addEmptyLine());
					paragraph.add(new Chunk("For the specified duration there are no cells_mean exceeds "+threshold+". ", SMALL_BOLD));
				}
			});
		}
		paragraph.add(table);
		return paragraph;
	}
	
	private static Element createTombstonesMeanSummaryTable(String tombstoneMeanThreshold) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Analysis of tombstones_mean from cfstats : ", NORMAL_BOLD));
		int threshold = (tombstoneMeanThreshold == null || tombstoneMeanThreshold.length() == 0) ? Constants.DEFAULT_TOMBSTONES_MEAN_THRESHOLD : Integer.parseInt(tombstoneMeanThreshold);
		paragraph.add(new Chunk("TTables with average tombstones scanned greater than : "+threshold, SMALL_BOLD));
		PdfPTable table = createTable(14);
		String headerArray[] = { "State", "Keyspace", "Table", "Node", "sstables", "space (mb)", "max read %", "max write %" ,"max partition", "mean partition", 
				"cells mean", "cells max", "mean tombstones", "max tombstones" };
		addHeaderInTable(table, headerArray);
		List<KeySpaceDetails> keySpaceSummary = CommandProcessingUtil.getKeySpaceSummary();
		if (keySpaceSummary != null && !keySpaceSummary.isEmpty()) {
			keySpaceSummary.forEach(data -> {
				long maxRead = 0;
				long maxWrite = 0;
				maxRead = getPercentage(data.getTotalReadCount(), data.getLocalReadCount());
				maxWrite = getPercentage(data.getTotalWriteCount(), data.getLocalWriteCount());
				long tombstonesMean = data.getCellsMean().equalsIgnoreCase("NaN")?0:(long)Double.parseDouble(data.getMeanTombStones());
				if(tombstonesMean > threshold){
					table.addCell(createCell("INFO"));
					table.addCell(createCell(data.getKeySpace()));
					table.addCell(createCell(data.getTable()));
					table.addCell(createCell(data.getNode()));
					table.addCell(createCell(data.getSsTablesCount()));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getSpace()))));
					table.addCell(createCell(String.valueOf(maxRead)));
					table.addCell(createCell(String.valueOf(maxWrite)));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMaxPartition()))));
					table.addCell(createCell(String.valueOf(parseBytesToMb(data.getMeanPartition()))));
					table.addCell(createCell(data.getCellsMean()));
					table.addCell(createCell(data.getCellsMax()));
					table.addCell(createCell(data.getMeanTombStones()));
					table.addCell(createCell(data.getMaxTombStones()));
				} else {
					paragraph.add(addEmptyLine());
					paragraph.add(new Chunk("For the specified duration there are no tombstones_mean exceeds "+threshold+". ", SMALL_BOLD));
				}
			});
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph createErrorWarningTable(List<Log> logList) throws IOException {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Cluster View Table : ", SMALL_BOLD));
		PdfPTable table = createTable(4);
		String headerArray[] = { "Node", "Data Center", "Errors", "Warnings" };
		addHeaderInTable(table, headerArray);
		List<ClusterViewDetail> list = getClusterViewDetailList(logList);
		if (list != null && !list.isEmpty()) {
			list.forEach(data -> {
				table.addCell(createCell(String.valueOf(data.getHost())));
				table.addCell(createCell(String.valueOf(data.getCluster())));
				table.addCell(createCell(String.valueOf(data.getErrorCount())));
				table.addCell(createCell(String.valueOf(data.getWarningCount())));
			});

		} else {
			paragraph.add(addEmptyLine());
			paragraph.add(new Chunk("For the specified duration there are no errors and warnings. ", SMALL_BOLD));
		}
		paragraph.add(table);
		return paragraph;
	}

	private static List<ClusterViewDetail> getClusterViewDetailList(List<Log> logList) {
		List<ClusterViewDetail> details = new ArrayList<>();
		Map<String, Integer> errorMap = new HashMap<>();
		Map<String, Integer> warningMap = new HashMap<>();
		logList.stream().forEach(log -> {
			if (log.getLogType().equals("ERROR")) {
				Integer errorCount = errorMap.get(log.getHostName());
				if (errorCount != null) {
					errorMap.put(log.getHostName(), ++errorCount);
				} else {
					errorMap.put(log.getHostName(), 1);
				}
			} else if (log.getLogType().equals("WARN")) {
				Integer warningCount = warningMap.get(log.getHostName());
				if (warningCount != null) {
					warningMap.put(log.getHostName(), ++warningCount);
				} else {
					warningMap.put(log.getHostName(), 1);
				}
			}
		});
		for (Entry<String, Integer> entry : errorMap.entrySet()) {
			ClusterViewDetail detail = new ClusterViewDetail();
			detail.setCluster(NodesProcessingUtil.getHostsAsMap().get(entry.getKey()).getCluster());
			detail.setHost(entry.getKey());
			detail.setErrorCount(entry.getValue().toString());
			detail.setWarningCount(String.valueOf(0));
			details.add(detail);
		}
		for (Entry<String, Integer> entry : warningMap.entrySet()) {
			ClusterViewDetail detail = null;
			Optional<ClusterViewDetail> x = details.stream().filter(data -> {
				return data.getHost().equals(entry.getKey());
			}).findFirst();
			if (x.isPresent()) {
				x.get().setWarningCount(entry.getValue().toString());
			} else {
				detail = new ClusterViewDetail();
				detail.setCluster(NodesProcessingUtil.getHostsAsMap().get(entry.getKey()).getCluster());
				detail.setHost(entry.getKey());
				detail.setErrorCount(String.valueOf(0));
				detail.setWarningCount(entry.getValue().toString());
				details.add(detail);
			}
		}
		return details;
	}

	private static Paragraph addEmptyLine() {
		Paragraph p = new Paragraph();
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		return p;
	}

	private static PdfPTable createTable(int i) {
		PdfPTable table = new PdfPTable(i);
		if (i == 4) {
			table.setWidthPercentage(50);
		} else if (i == 12) {
			table.setWidthPercentage(100);
		} else if (i == 14) {
			table.setWidthPercentage(100);
		} else if (i == 1) {
			table.setWidthPercentage(100);
		} else if (i == 3) {
			table.setWidthPercentage(100);
		} else if (i == 5) {
			table.setWidthPercentage(100);
		} else {
			table.setWidthPercentage(100);
		}

		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		return table;
	}

	private static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}

	private static void addHeaderInTable(PdfPTable table, String headerArray[]) {

		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}

	private static List<ParameterSummary> getParameterSummaryList(Map<String, List<Log>> logMap) {
		List<ParameterSummary> parameterSummaryList = new ArrayList<ParameterSummary>();
		for (Map.Entry<String, List<Log>> entry : logMap.entrySet()) {
			parameterSummaryList.add(getSummaryTabelReport(entry.getKey(), entry.getValue()));

		}
		return parameterSummaryList;
	}

	private static ParameterSummary getSummaryTabelReport(String hostName, List<Log> logListObj) {
		ParameterSummary summaryTableObj = null;
		String node = hostName;
		String maxStatus = null;
		String maxTimeStamp = null;
		int maxGC = Integer.MIN_VALUE;
		String minTimeStamp = null;
		int minGC = Integer.MAX_VALUE;
		int slabPoolCleanerCount = 0;
		int commitLogAllocatorCount = 0;
		int scheduleTaskCount = 0;
		int compactionExecutorCount = 0;
		int repairJobTaskCount = 0;
		int gcCount = 0;

		for (Log log : logListObj) {
			if (log.getClassName().equalsIgnoreCase("GCInspector.java")) {
				Integer timeInMilliSeconds = log.getTimeInMilliSeconds();
				if (timeInMilliSeconds != null && (timeInMilliSeconds > maxGC)) {
					maxGC = timeInMilliSeconds;
					maxStatus = log.getLogType();
					maxTimeStamp = log.getTimeStamp();

				} else if (timeInMilliSeconds < minGC) {
					minGC = timeInMilliSeconds;
					minTimeStamp = log.getTimeStamp();
				}
				gcCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SCHEDULEDTASKS)) {
				scheduleTaskCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SLABPOOLCLEANER)) {
				slabPoolCleanerCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				commitLogAllocatorCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_COMPACTIONEXECUTOR)) {
				compactionExecutorCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_REPAIRJOBTASK)) {
				repairJobTaskCount++;
 			}
		}

		summaryTableObj = new ParameterSummary(maxStatus, node, maxTimeStamp, maxGC, commitLogAllocatorCount,
				slabPoolCleanerCount, scheduleTaskCount, compactionExecutorCount, repairJobTaskCount, minTimeStamp,
				minGC, gcCount);
		return summaryTableObj;

	}

	private static Paragraph createSummaryTable(List<ParameterSummary> parameterSummaryList) throws IOException {
		Paragraph paragraph = new Paragraph();
		PdfPTable table = createTable(12);
		String headerArray[] = { "Max GC Status", "Node IP", "Max GC TimeStamp", "Max GC", "Min GC TimeStamp", "Min GC",
				"Commit Log Allocator Count", "SlabPool Cleaner Count", "Schedule Task Count",
				"Compaction Executor Count", "Repair Job Task Count", "GC Count" };
		addHeaderInTable(table, headerArray);
		if (parameterSummaryList != null && !parameterSummaryList.isEmpty()) {
			for (ParameterSummary parameterSummary : parameterSummaryList) {
				if (!(parameterSummary.getMinGC() == Integer.MAX_VALUE && parameterSummary.getMaxGC() == Integer.MIN_VALUE
						&& parameterSummary.getCommitLogAllocatorCount() == 0
						&& parameterSummary.getSlabPoolCleanerCount() == 0
						&& parameterSummary.getScheduleTaskCount() == 0
						&& parameterSummary.getCompactionExecutorCount() == 0
						&& parameterSummary.getRepairJobTaskCount() == 0)) {
					table.addCell(createCell(parameterSummary.getMaxStatus()));
					table.addCell(createCell(parameterSummary.getNode()));
					if (parameterSummary.getMaxGC() == Integer.MIN_VALUE) {
						table.addCell(createCell("NA"));
						table.addCell(createCell("NA"));
					} else {
						table.addCell(createCell(parameterSummary.getMaxTimeStamp()));
						table.addCell(createCell(String.valueOf(parameterSummary.getMaxGC())));
					}
					if (parameterSummary.getMinGC() == Integer.MAX_VALUE) {
						table.addCell(createCell("NA"));
						table.addCell(createCell("NA"));
					} else {
						table.addCell(createCell(parameterSummary.getMinTimeStamp()));
						table.addCell(createCell(String.valueOf(parameterSummary.getMinGC())));
					}
					table.addCell(createCell(String.valueOf(parameterSummary.getCommitLogAllocatorCount())));
					table.addCell(createCell(String.valueOf(parameterSummary.getSlabPoolCleanerCount())));
					table.addCell(createCell(String.valueOf(parameterSummary.getScheduleTaskCount())));
					table.addCell(createCell(String.valueOf(parameterSummary.getCompactionExecutorCount())));
					table.addCell(createCell(String.valueOf(parameterSummary.getRepairJobTaskCount())));
					table.addCell(createCell(String.valueOf(parameterSummary.getGcCount())));
				}

			}
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph overViewSummary() {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Overview Summary: : ", NORMAL_BOLD));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk(
				"This is a high level analysis of a diagnostic created by Logparser application, This tarball contains a large amount of information and the diag_analyser is designed to perform a rapid analysis and highlight some commonly found issues. It is broken into sections on cluster topology, logfile content, parameter settings and table level analysis",
				NORMAL_FONT));
		return paragraph;
	}

	private static Paragraph introDetails() {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Date : " + new SimpleDateFormat("MM/dd/yyyy").format(new Date()), NORMAL_FONT));
		paragraph.add(Chunk.NEWLINE);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm aa");
		Date endTime = new Date();
		Date startTime = new Date(endTime.getTime()-ParsingUtil.getTimeInMilliSeconds());
		String endTimeStamp = dateFormat.format(endTime);
		String startTimeStamp = dateFormat.format(startTime);
		paragraph.add(new Chunk("Duration : " + startTimeStamp +" To "+ endTimeStamp, NORMAL_FONT));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk("No of Nodes : " + NodesProcessingUtil.getHosts().size(), NORMAL_FONT));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk("Data Centers : " + NodesProcessingUtil.getDataCenters().size(), NORMAL_FONT));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk("Racks : " + NodesProcessingUtil.getRacks().size(), NORMAL_FONT));
		return paragraph;
	}
	
	private static long parseBytesToMb(String bytes){
		long longBytes = Long.parseLong(bytes);
		if(longBytes != 0){
			return Math.round(longBytes/MEGABYTE);
		}
		return longBytes;
	}
	
	private static long getPercentage(String totalCount, String localCount){
		double maxPercentage = 0;
		if(Integer.parseInt(totalCount) > 0 && Integer.parseInt(localCount) > 0){
			maxPercentage = (Double.parseDouble(localCount) / Double.parseDouble(totalCount)) * 100;
		}
		return Math.round(maxPercentage);
		
	}

}
