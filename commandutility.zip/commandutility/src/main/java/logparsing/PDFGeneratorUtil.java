package logparsing;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import logparsing.model.ClusterViewDetail;
import logparsing.model.ParameterSummary;

public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);
	public final static Font NORMAL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
	public final static Font VERY_SMALL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.NORMAL);

	public static void main(String[] args) {
		List<Log> logList = new ArrayList<>();
		PDFGeneratorUtil.generateReport(logList, null);
	}

	public static void generateReport(List<Log> logList, Map<String, List<Log>> logMap) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + "\\Report_" + (new Date()).getTime() + ".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			HeaderFooter event = new HeaderFooter();
			event.setHeader("Cassandra Log Detailed Summary");
			writer.setPageEvent(event);
			document.open();
			addMetaData(document);
			document.add(Chunk.NEWLINE);
			document.add(overViewSummary());
			document.add(Chunk.NEWLINE);
			document.add(introDetails(NodesProcessingUtil.getHosts().size()));
			document.add(addEmptyLine());
			document.add(createSummaryTable(getParameterSummaryList(logMap)));
			document.add(addEmptyLine());
			document.add(createErrorWarningTable(logList));
			document.add(addEmptyLine());
			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
		}
	}

	private static Paragraph createErrorWarningTable(List<Log> logList) throws IOException {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Cluster View Table : ", SMALL_BOLD));
		PdfPTable table = createTable(4);
		String headerArray[] = { "Node", "Data Center", "Errors", "Warnings" };
		addHeaderInTable(table, headerArray);
		List<ClusterViewDetail> list = getClusterViewDetailList(logList);
		if (list != null && !list.isEmpty()) {
			list.forEach(data -> {
				table.addCell(createCell(String.valueOf(data.getHost())));
				table.addCell(createCell(String.valueOf(data.getCluster())));
				table.addCell(createCell(String.valueOf(data.getErrorCount())));
				table.addCell(createCell(String.valueOf(data.getWarningCount())));
			});

		}
		paragraph.add(table);
		return paragraph;
	}

	private static List<ClusterViewDetail> getClusterViewDetailList(List<Log> logList) {
		List<ClusterViewDetail> details = new ArrayList<>();
		Map<String, Integer> errorMap = new HashMap<>();
		Map<String, Integer> warningMap = new HashMap<>();
		logList.stream().forEach(log -> {
			if (log.getLogType().equals("ERROR")) {
				Integer errorCount = errorMap.get(log.getHostName());
				if (errorCount != null) {
					errorMap.put(log.getHostName(), ++errorCount);
				} else {
					errorMap.put(log.getHostName(), 1);
				}
			} else if (log.getLogType().equals("WARN")) {
				Integer warningCount = warningMap.get(log.getHostName());
				if (warningCount != null) {
					warningMap.put(log.getHostName(), ++warningCount);
				} else {
					warningMap.put(log.getHostName(), 1);
				}
			}
		});
		for (Entry<String, Integer> entry : errorMap.entrySet()) {
			ClusterViewDetail detail = new ClusterViewDetail();
			detail.setCluster(NodesProcessingUtil.getHostsAsMap().get(entry.getKey()).getCluster());
			detail.setHost(entry.getKey());
			detail.setErrorCount(entry.getValue().toString());
			detail.setWarningCount(String.valueOf(0));
			details.add(detail);
		}
		for (Entry<String, Integer> entry : warningMap.entrySet()) {
			ClusterViewDetail detail = null;
			Optional<ClusterViewDetail> x = details.stream().filter(data -> {
				return data.getHost().equals(entry.getKey());
			}).findFirst();
			if (x.isPresent()) {
				x.get().setWarningCount(entry.getValue().toString());
			} else {
				detail = new ClusterViewDetail();
				detail.setCluster(NodesProcessingUtil.getHostsAsMap().get(entry.getKey()).getCluster());
				detail.setHost(entry.getKey());
				detail.setErrorCount(String.valueOf(0));
				detail.setWarningCount(entry.getValue().toString());
				details.add(detail);
			}
		}
		return details;
	}

	private static Paragraph addEmptyLine() {
		Paragraph p = new Paragraph();
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		return p;
	}

	private static PdfPTable createTable(int i) {
		PdfPTable table = new PdfPTable(i);
		if (i == 4) {
			table.setWidthPercentage(50);
		} else if (i == 11) {
			table.setWidthPercentage(100);
		} else if (i == 1) {
			table.setWidthPercentage(100);
		} else if (i == 3) {
			table.setWidthPercentage(100);
		} else if (i == 5) {
			table.setWidthPercentage(100);
		}

		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		return table;
	}

	private static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}

	private static void addHeaderInTable(PdfPTable table, String headerArray[]) {

		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.LIGHT_GRAY);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}

	private static List<ParameterSummary> getParameterSummaryList(Map<String, List<Log>> logMap) {
		List<ParameterSummary> parameterSummaryList = new ArrayList<ParameterSummary>();
		for (Map.Entry<String, List<Log>> entry : logMap.entrySet()) {
			parameterSummaryList.add(getSummaryTabelReport(entry.getKey(), entry.getValue()));

		}
		return parameterSummaryList;
	}

	private static ParameterSummary getSummaryTabelReport(String hostName, List<Log> logListObj) {
		ParameterSummary summaryTableObj = null;
		String node = hostName;
		String maxStatus = null;
		String maxTimeStamp = null;
		int maxGC = Integer.MIN_VALUE;
		String minTimeStamp = null;
		int minGC = Integer.MAX_VALUE;
		int slabPoolCleanerCount = 0;
		int commitLogAllocatorCount = 0;
		int scheduleTaskCount = 0;
		int compactionExecutorCount = 0;
		int repairJobTaskCount = 0;

		for (Log log : logListObj) {
			if (log.getClassName().equalsIgnoreCase("GCInspector.java")) {
				Integer timeInMilliSeconds = log.getTimeInMilliSeconds();
				if (timeInMilliSeconds != null && (timeInMilliSeconds > maxGC)) {
					maxGC = timeInMilliSeconds;
					maxStatus = log.getLogType();
					maxTimeStamp = log.getTimeStamp();

				} else if (timeInMilliSeconds < minGC) {
					minGC = timeInMilliSeconds;
					minTimeStamp = log.getTimeStamp();
				}
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SCHEDULEDTASKS)) {
				scheduleTaskCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SLABPOOLCLEANER)) {
				slabPoolCleanerCount++;
			} else if (log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				commitLogAllocatorCount++;
			}
			// compactionExecutorCount and repairJobTaskCount updatres to be implemented
		}

		summaryTableObj = new ParameterSummary(maxStatus, node, maxTimeStamp, maxGC, commitLogAllocatorCount,
				slabPoolCleanerCount, scheduleTaskCount, compactionExecutorCount, repairJobTaskCount, minTimeStamp,
				minGC);
		return summaryTableObj;

	}

	private static Paragraph createSummaryTable(List<ParameterSummary> parameterSummaryList) throws IOException {
		Paragraph paragraph = new Paragraph();
		PdfPTable table = createTable(11);
		String headerArray[] = { "Max GC Status", "Node IP", "Max GC TimeStamp", "Max GC", "Min GC TimeStamp", "Min GC",
				"Commit Log Allocator Count", "SlabPool Cleaner Count", "Schedule Task Count",
				"Compaction Executor Count", "Repair Job Task Count" };
		addHeaderInTable(table, headerArray);
		if (parameterSummaryList != null && !parameterSummaryList.isEmpty()) {
			for (ParameterSummary parameterSummary : parameterSummaryList) {
				table.addCell(createCell(parameterSummary.getMaxStatus()));
				table.addCell(createCell(parameterSummary.getNode()));
				table.addCell(createCell(parameterSummary.getMaxTimeStamp()));
				table.addCell(createCell(String.valueOf(parameterSummary.getMaxGC())));
				table.addCell(createCell(parameterSummary.getMinTimeStamp()));
				table.addCell(createCell(String.valueOf(parameterSummary.getMinGC())));
				table.addCell(createCell(String.valueOf(parameterSummary.getCommitLogAllocatorCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getSlabPoolCleanerCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getScheduleTaskCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getCompactionExecutorCount())));
				table.addCell(createCell(String.valueOf(parameterSummary.getRepairJobTaskCount())));

			}
		}
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph overViewSummary() {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Overview Summary: : ", NORMAL_BOLD));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk(
				"This is a high level analysis of a diagnostic created by Logparser application, This tarball contains a large amount of information and the diag_analyser is designed to perform a rapid analysis and highlight some commonly found issues. It is broken into sections on cluster topology, logfile content, parameter settings and table level analysis",
				NORMAL_FONT));
		return paragraph;
	}

	private static Paragraph introDetails(int hostsCount) {
		Paragraph paragraph = new Paragraph();
		paragraph.add(new Chunk("Date : " + new SimpleDateFormat("MM/dd/yyyy").format(new Date()), NORMAL_FONT));
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(new Chunk("No of Nodes : " + hostsCount, NORMAL_FONT));
		return paragraph;
	}

}
