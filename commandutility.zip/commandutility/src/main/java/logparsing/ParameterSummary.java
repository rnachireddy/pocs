package logparsing;

public class ParameterSummary {

	private String status;
	private String node;
	private String timeStamp;
	private int maxGC;
	private int commitLogAllocatorCount;
	private int slabPoolCleanerCount;
	private int scheduleTaskCount;
	private int compactionExecutorCount;
	private int repairJobTaskCount;
	
	public ParameterSummary(String status, String node, String timeStamp,
			int maxGC, int commitLogAllocatorCount, int slabPoolCleanerCount,
			int scheduleTaskCount, int compactionExecutorCount,
			int repairJobTaskCount) {
		super();
		this.status = status;
		this.node = node;
		this.timeStamp = timeStamp;
		this.maxGC = maxGC;
		this.commitLogAllocatorCount = commitLogAllocatorCount;
		this.slabPoolCleanerCount = slabPoolCleanerCount;
		this.scheduleTaskCount = scheduleTaskCount;
		this.compactionExecutorCount = compactionExecutorCount;
		this.repairJobTaskCount = repairJobTaskCount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public int getMaxGC() {
		return maxGC;
	}

	public void setMaxGC(int maxGC) {
		this.maxGC = maxGC;
	}

	public int getCommitLogAllocatorCount() {
		return commitLogAllocatorCount;
	}

	public void setCommitLogAllocatorCount(int commitLogAllocatorCount) {
		this.commitLogAllocatorCount = commitLogAllocatorCount;
	}

	public int getSlabPoolCleanerCount() {
		return slabPoolCleanerCount;
	}

	public void setSlabPoolCleanerCount(int slabPoolCleanerCount) {
		this.slabPoolCleanerCount = slabPoolCleanerCount;
	}

	public int getScheduleTaskCount() {
		return scheduleTaskCount;
	}

	public void setScheduleTaskCount(int scheduleTaskCount) {
		this.scheduleTaskCount = scheduleTaskCount;
	}

	public int getCompactionExecutorCount() {
		return compactionExecutorCount;
	}

	public void setCompactionExecutorCount(int compactionExecutorCount) {
		this.compactionExecutorCount = compactionExecutorCount;
	}

	public int getRepairJobTaskCount() {
		return repairJobTaskCount;
	}

	public void setRepairJobTaskCount(int repairJobTaskCount) {
		this.repairJobTaskCount = repairJobTaskCount;
	}

	@Override
	public String toString() {
		return "SummaryTable [status=" + status + ", node=" + node
				+ ", timeStamp=" + timeStamp + ", maxGC=" + maxGC
				+ ", commitLogAllocatorCount=" + commitLogAllocatorCount
				+ ", slabPoolCleanerCount=" + slabPoolCleanerCount
				+ ", scheduleTaskCount=" + scheduleTaskCount
				+ ", compactionExecutorCount=" + compactionExecutorCount
				+ ", repairJobTaskCount=" + repairJobTaskCount + "]";
	}
	
	
	
	
	
	
	
}
