package logparsing;

public class Log {

	private String logType;
	private String timeStamp;
	private String className;
	private String threadName;
	private String description;
	private Integer timeInMilliSeconds;
	private Double memoryUsed;
	private String hostName;
	private String cluster;
	private String rack;

	public Log() {

	}

	public Log(String logType, String timeStamp, String className, String threadName, String description) {
		this.logType = logType;
		this.timeStamp = timeStamp;
		this.className = className;
		this.threadName = threadName;
		this.description = description;
	}

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getTimeInMilliSeconds() {
		return timeInMilliSeconds;
	}

	public void setTimeInMilliSeconds(Integer timeInMilliSeconds) {
		this.timeInMilliSeconds = timeInMilliSeconds;
	}

	public Double getMemoryUsed() {
		return memoryUsed;
	}

	public void setMemoryUsed(Double memoryUsed) {
		this.memoryUsed = memoryUsed;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public String getRack() {
		return rack;
	}

	public void setRack(String rack) {
		this.rack = rack;
	}

}
