package logparsing;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

/**
 *	Entry class for the application 
 *
 */


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class Main {
	
	private static Logger log =LoggerFactory.getLogger(Main.class.getName());

	public static void main(String[] args) {
		ParseRequest request = new ParseRequest();
		File file = new File("commands.properties");
		if (file.exists()) {
			Properties prop = new Properties();
			try {
				prop.load(new FileInputStream(file));
				NodesProcessingUtil.setCassandraLogPath(prop.getProperty("cassandra.log.path"));
				NodesProcessingUtil.setCassandraNodePath(prop.getProperty("cassandra.nodetool.path"));
				NodesProcessingUtil.setNodeToolCommands(prop.getProperty("cassandra.commands"));
				request.setHours(prop.getProperty("hours"));
				request.setMinutes(prop.getProperty("minutes"));
				request.setUserName(prop.getProperty("username"));
				request.setPassword(prop.getProperty("password"));
				request.setHost(prop.getProperty("host"));
				request.setSsCountThreshold(prop.getProperty("ssCountThreshold"));
				request.setReadPercentageThreshold(prop.getProperty("readPercentageThreshold"));
				request.setWritePercentageThreshold(prop.getProperty("writePercentageThreshold"));
				request.setPartMaxThreshold(prop.getProperty("partMaxThreshold"));
				request.setCellsMeanThreshold(prop.getProperty("cellsMeanThreshold"));
				request.setTombstoneMeanThreshold(prop.getProperty("tombstoneMeanThreshold"));
				request.setCustomRun(prop.getProperty("customRun"));
			} catch (Exception ex) {
				System.out.println("Properties File doesn't exists");
				System.exit(0);
			}
		}
		if(StringUtils.isEmpty(request.getUserName()) || StringUtils.isEmpty(request.getPassword()) || StringUtils.isEmpty(request.getHost()) ) {
			System.out.println("Please give username & password & cluster information to continue the process \n\n");
			System.out.println("The below commandline arguments are mandatory to run this jar\n\n");
			System.out.println("host=<clusterip> \nusername=<username>\npassword=<password>\n\n");
			System.out.println("The following are the available optional command line arguments : \n");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_CUSTOM_RUN + "=<true/false>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_TOMBSTONES_MEAN_THRESHOLD + "=<tombstones_mean_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_CELLS_MEAN_THRESHOLD + "=<cells_mean_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_PART_MAX_THRESHOLD + "=<part_max_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_WRITE_PERCENTAGE_THRESHOLD + "=<write_percentage_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_READ_PERCENTAGE_THRESHOLD + "=<true/false>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_SSCOUNT_THRESHOLD + "=<sscount_value>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_PASSWORD + "=<password>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_HOST + "=<clusterip>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_USERNAME + "=<uername>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_MINUTES + "=<minutes>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_HOURS + "=<hours>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_CUSTOM_RUN + "<true/false>");
		} else {
			try {
				ParsingUtil.parseLogFile(request);
			} catch (IOException e) {
				log.error(e.getMessage());
				log.error("IOException :: {}", e);
			} catch (ParseException e) {
				log.error(e.getMessage());
				log.error("ParseException :: {}", e);
			} catch (JSchException e) {
				log.error(e.getMessage());
				log.error("JSchException :: {}", e);
			} catch (SftpException e) {
				log.error(e.getMessage());
				log.error("SftpException :: {}", e);
			} catch (Exception e) {
				log.error(e.getMessage());
				log.error("Exception :: {}", e);
			}
		}
	}
	
	
}
