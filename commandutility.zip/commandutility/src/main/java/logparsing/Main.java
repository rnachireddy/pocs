package logparsing;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class Main {

	public static void main(String[] args) throws IOException, ParseException, JSchException, SftpException {
		Date date = new Date();
		ParseRequest request = new ParseRequest();
		if (args != null && args.length > 0) {
			for (String string : args) {
				String[] parameter = string.split("=");
				if (parameter.length == 2) {
					if (Constants.COMMAND_LINE_ARGUMENT_THRESHOLD.equals(parameter[0])) {
						request.setThresholdInMilliSeconds(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_HOURS.equals(parameter[0])) {
						request.setHours(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_MINUTES.equals(parameter[0])) {
						request.setMinutes(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_USERNAME.equals(parameter[0])) {
						request.setUserName(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_PASSWORD.equals(parameter[0])) {
						request.setPassword(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_NOOFMAXGC.equals(parameter[0])) {
					} else if (Constants.COMMAND_LINE_ARGUMENT_HOST.equals(parameter[0])) {
						request.setHost(parameter[1]);
					}
				}
			}
		}
		if(StringUtils.isEmpty(request.getUserName()) || StringUtils.isEmpty(request.getPassword()) || StringUtils.isEmpty(request.getHost()) ) {
			System.out.println("Please give username & password & cluster information to continue the process");
		} else {
			ParsingUtil.parseLogFile(request);
		}
		System.out.println("Log Parsing is Done");
		Date date2 = new Date();
		
		long dd = date2.getTime()-date.getTime();
		System.out.println(dd);
		
	}
}
