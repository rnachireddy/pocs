package logparsing;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class Main {

	public static void main(String[] args) throws IOException, ParseException, JSchException, SftpException, Exception {
		ParseRequest request = new ParseRequest();
		if (args != null && args.length > 0) {
			for (String string : args) {
				String[] parameter = string.split("=");
				if (parameter.length == 2) {
					if(Constants.COMMAND_LINE_ARGUMENT_PROPERTIESFILE.equals(parameter[0])) {
						ParsingUtil.processPropertiesFile(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_THRESHOLD.equals(parameter[0])) {
						request.setThresholdInMilliSeconds(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_HOURS.equals(parameter[0])) {
						request.setHours(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_MINUTES.equals(parameter[0])) {
						request.setMinutes(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_USERNAME.equals(parameter[0])) {
						request.setUserName(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_PASSWORD.equals(parameter[0])) {
						request.setPassword(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_NOOFMAXGC.equals(parameter[0])) {
					} else if (Constants.COMMAND_LINE_ARGUMENT_HOST.equals(parameter[0])) {
						request.setHost(parameter[1]);
					}  else if (Constants.COMMAND_LINE_ARUGMENT_SSCOUNT_THRESHOLD.equals(parameter[0])) {
						request.setSsCountThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARUGMENT_READ_PERCENTAGE_THRESHOLD.equals(parameter[0])) {
						request.setReadPercentageThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARUGMENT_WRITE_PERCENTAGE_THRESHOLD.equals(parameter[0])) {
						request.setWritePercentageThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARUGMENT_PART_MAX_THRESHOLD.equals(parameter[0])) {
						request.setPartMaxThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARUGMENT_CELLS_MEAN_THRESHOLD.equals(parameter[0])) {
						request.setCellsMeanThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARUGMENT_TOMBSTONES_MEAN_THRESHOLD.equals(parameter[0])) {
						request.setTombstoneMeanThreshold(parameter[1]);
					} else if (Constants.COMMAND_LINE_ARGUMENT_CUSTOM_RUN.equals(parameter[0])) {
						request.setCustomRun(parameter[1]);
					}
				}
			}
		}
		if(StringUtils.isEmpty(request.getUserName()) || StringUtils.isEmpty(request.getPassword()) || StringUtils.isEmpty(request.getHost()) ) {
			System.out.println("Please give username & password & cluster information to continue the process \n\n");
			System.out.println("The below commandline arguments are mandatory to run this jar\n\n");
			System.out.println("host=<clusterip> \nusername=<username>\n password=<password>\n\n");
			System.out.println("The following are the available command line arguments : \n");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_CUSTOM_RUN + "=<true/false>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_TOMBSTONES_MEAN_THRESHOLD + "=<tombstones_mean_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_CELLS_MEAN_THRESHOLD + "=<cells_mean_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_PART_MAX_THRESHOLD + "=<part_max_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_WRITE_PERCENTAGE_THRESHOLD + "=<write_percentage_value>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_READ_PERCENTAGE_THRESHOLD + "=<true/false>");
			System.out.println(Constants.COMMAND_LINE_ARUGMENT_SSCOUNT_THRESHOLD + "=<sscount_value>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_PASSWORD + "=<password>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_HOST + "=<clusterip>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_USERNAME + "=<uername>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_MINUTES + "=<minutes>");
			System.out.println(Constants.COMMAND_LINE_ARGUMENT_HOURS + "=<hours>");
		} else {
			ParsingUtil.parseLogFile(request);
		}
	}
}
