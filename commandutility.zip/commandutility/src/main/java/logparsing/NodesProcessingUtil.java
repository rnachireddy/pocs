package logparsing;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import logparsing.model.HostDetails;

/**
 * This class is used to connect to the linux host and process all the linux related commands 
 * 
 */
public class NodesProcessingUtil {
	
	private static Logger log =LoggerFactory.getLogger(NodesProcessingUtil.class.getName());

	private static Session session = null;
	private static String _host = null;
	private static String _user = null;
	private static String _password = null;
	private static int _port = 22;
	private static String _logOutputFolder = null;
	private static String _commandOutputFolder = null;
	private static List<HostDetails> _clusterList = null;
	private static Set<String> _dataCenters = null;
	private static Set<String> _racks = null;
	private static Map<String, HostDetails> _hostMap = null;
	private static String _cassandraLogPath = null;
	private static String _cassandraNodePath = null;
	private static List<String> _nodetoolCommands = null;

	public static void processAllCassandraNodesInACluster(String user, String password, String host, String customRun,
			String commandOutputFolder, String logsOutputFolder) throws JSchException, IOException, SftpException {
		log.info("Entering inside processAllCassandraNodesInACluster : customRun :: {}", customRun);
		_logOutputFolder = logsOutputFolder;
		_commandOutputFolder = commandOutputFolder;
		_clusterList = new ArrayList<>();
		_hostMap = new HashMap<>();
		_dataCenters = new HashSet<>();
		_racks = new HashSet<>();
		if(customRun != null && customRun.equalsIgnoreCase("true")){
			getAllNodesInACluster(user, password, host);
			processHost(user, password, host);
		} else{
			getAllNodesInACluster(user, password, host);
			processAllHosts(user, password);
		}
		log.info("End of processAllCassandraNodesInACluster | Pulled logs and command information at {} and {}", _logOutputFolder, _commandOutputFolder);
		
	}

	/**
	 * This method is used to get all the nodes in a particular cluster
	 */
	private static void getAllNodesInACluster(String user, String password, String host) {
		_user = user;
		_password = password;
		_host = host;
		try {
			connect();
			executeCommandToGetNodesInACluster();
			disconnect();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * This method is used to execute the commands to get the nodes in a cluster
	 */
	private static void executeCommandToGetNodesInACluster() throws JSchException, IOException {
		String command = "cd "+ getCassandraNodePath() + "; ./nodetool status";
		log.info("Executing status command :: {}", command);
		Channel channel = session.openChannel("exec");
		((ChannelExec) channel).setCommand(command);
		channel.setInputStream(null);
		((ChannelExec) channel).setErrStream(System.err);
		InputStream in = channel.getInputStream();
		channel.connect();
		StringBuffer buf = new StringBuffer();
		
		byte[] tmp = new byte[1024];
		while (true) {
			while (in.available() > 0) {
				int i = in.read(tmp, 0, 1024);
				if (i < 0)
					break;
				buf.append(new String(tmp, 0, i));
			}
			if (channel.isClosed()) {
				break;
			}
		}
		channel.disconnect();
		extractHostsAndWriteToServersFile(buf);
		log.info("Node Information :: {}", _clusterList);
	}

	/**
	 * This method extract the hosts from a cluster and adds it to the _clusterlist
	 */
	private static void extractHostsAndWriteToServersFile(StringBuffer buf) throws IOException {
		String cluster = null;
		for (String str : buf.toString().split("\n")) {
			if (str.indexOf("Datacenter") == 0) {
				cluster = str.split(" ")[1];
			} else {
				Pattern p = Pattern.compile("^(.* )([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)( .*)( RAC.*)$");
				Matcher m = p.matcher(str);
				if (m.find()) {
					_clusterList.add(new HostDetails(cluster, m.group(2), m.group(4).trim()));
				}
			}
		}
		prepareAHostMap();
		prepareDataCenters();
		prepareRacks();
	}

	/**
	 * This methods creates the _racks information
	 */
	private static void prepareRacks() {
		_clusterList.stream().forEach(data -> {
			_racks.add(data.getRack());
		});
	}

	/**
	 * This method creates the _dataCenters information
	 */
	private static void prepareDataCenters() {
		_clusterList.stream().forEach(data -> {
			_dataCenters.add(data.getCluster());
		});
	}

	/**
	 * This method prepares the _hostmap information
	 */
	private static void prepareAHostMap() {
		_clusterList.stream().forEach(data -> {
			_hostMap.put(data.getHost(), data);
		});
	}

	public static void main(String[] args) throws JSchException, IOException, SftpException {
		String user = "vangsa2";
		String password = "P@ssword";
		processAllHosts(user, password);
	}

	/**
	 * This method is used to process all the hosts
	 */
	private static void processAllHosts(String user, String password) throws JSchException, IOException, SftpException {
		List<HostDetails> hosts = getHosts();
		for (HostDetails host : hosts) {
			processHost(user, password, host.getHost());
		}
	}
	
	/**
	 * This method is used to process a single host. Processing here means executing the nodetool commands, 
	 * copying all the logs and command execution output
	 */
	private static void processHost(String user, String password, String host) throws JSchException, IOException, SftpException {
		_user = user;
		_password = password;
		_host = host;
		List<String> commands = getNodeToolCommands();
		connect();
		log.info("before executing commands");
		String tempCommandOutputInLinux = "/tmp/commandoutput/";
		String commandZipFile = tempCommandOutputInLinux + _host + ".zip";
		String finalCommand = "mkdir " + tempCommandOutputInLinux + " ; cd " + getCassandraNodePath() +"; ";
		for (String command : commands) {
			finalCommand = finalCommand + "./nodetool " + command + " > " + tempCommandOutputInLinux + "/" + command
					+ " ;";
		}
		finalCommand = finalCommand + " cd " + tempCommandOutputInLinux + "; zip " + commandZipFile + " * ;";
		String tempLogOutputInLinux = "/tmp/cassandralogtemp/";
		String logZipFile = tempLogOutputInLinux + _host + ".zip";
		finalCommand += " cd "+ getCassandraLogPath() + " ; mkdir " + tempLogOutputInLinux + " ; zip " + logZipFile + " *";

		executeCommand(finalCommand);
		readZipFilesFromServers(commandZipFile, logZipFile);
		executeCommand("cd /tmp/ ; rm -rf commandoutput ; rm -rf cassandralogtemp ;");
		log.info("after executing commands");
		disconnect();
	}


	/**
	 * This method copies the commandszip file and logs zip file to our local server where the application is running
	 */
	private static void readZipFilesFromServers(String commandZipFile, String logZipFile)
			throws JSchException, SftpException {
		ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
		channel.connect();
		channel.get(commandZipFile, _commandOutputFolder);
		channel.get(logZipFile, _logOutputFolder);
		channel.disconnect();
	}

	/**
	 * This method gives the list of hosts
	 */
	public static List<HostDetails> getHosts() {
		return _clusterList;
	}

	/**
	 * This method gives list of dataCenters
	 */
	public static Set<String> getDataCenters() {
		return _dataCenters;
	}
	
	/**
	 * This method gives list of racks
	 */
	public static Set<String> getRacks() {
		return _racks;
	}

	/**
	 * This method gives the mapping of host name to the host details
	 */
	public static Map<String, HostDetails> getHostsAsMap() {
		return _hostMap;
	}
	
	/**
	 * This method gives the nodes count
	 */
	public static int getNodeCount(){
		return _clusterList.size();
	}

	/**
	 * This method is used to connect to the host
	 */
	private static void connect() throws JSchException {
		log.info("connecting..." + _host +" and collecting Debuglog and Cfstats information");
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		session = jsch.getSession(_user, _host, _port);
		session.setPassword(_password);
		session.setConfig(config);
		session.connect();
		log.info("Connected :"+ _host);
	}

	/**
	 * This method is used to disconnect from a host
	 */
	private static void disconnect() {
		if (session != null) {
			log.info("disconnecting..."+ _host);
			session.disconnect();
			log.info("disconnected "+ _host);
		}
	}

	/**
	 * This method executes the given command on a connected host
	 */
	private static void executeCommand(String command) throws JSchException, IOException {
		ChannelExec channel = (ChannelExec) session.openChannel("exec");
		channel.setErrStream(System.err);
		channel.setCommand(command);
		channel.connect();
		while (true) {
			if (channel.isClosed())
				break;
		}
		channel.disconnect();
	}

	/**
	 * This method reads the cassandraLogPath from the properties file. If it is not give a default path is returned
	 */
	public static String getCassandraLogPath() {
		if(StringUtils.isNotEmpty(_cassandraLogPath)) {
			return _cassandraLogPath;
		} else {
			return "/var/log/cassandra";
		}
	}

	/**
	 * This method sets the cassandraLogPath
	 * @param logPath
	 */
	public static void setCassandraLogPath(String logPath) {
		if(StringUtils.isNotEmpty(logPath)) {
			_cassandraLogPath = logPath;
		}
	}

	/**
	 * This method reads the cassandraNodePath from the properties file. If it is not give a default path is returned
	 */
	public static String getCassandraNodePath() {
		if(StringUtils.isNotEmpty(_cassandraNodePath)) {
			return _cassandraNodePath;
		} else {
			return "/app/cassandra/apache-cassandra*/bin";
		}
	}

	/**
	 *	This method sets the cassandraNodePath 
	 * @param logPath
	 */
	public static void setCassandraNodePath(String logPath) {
		if(StringUtils.isNotEmpty(logPath)) {
			_cassandraNodePath = logPath;
		}
	}
	
	/**
	 * This method give the list of node tool commands that need to be executed while running the application
	 * The commands are specified in a properties file. If nothing is given in properties file then default commands are returned
	 * @return
	 * @throws IOException
	 */
	private static List<String> getNodeToolCommands() throws IOException {
		if(_nodetoolCommands != null && !_nodetoolCommands.isEmpty()) {
			return _nodetoolCommands;
		} else {
			List<String> commands = new ArrayList<>();
			commands.add("cfstats");
			commands.add("compactionhistory");
			commands.add("compactionstats");
			commands.add("getcompcationthroughput");
			commands.add("gossipinfo");
			commands.add("info");
			commands.add("netstats");
			commands.add("ring");
			commands.add("status");
			commands.add("proxyhistograms");
			commands.add("tablehistograms");
			commands.add("statusbinary");
			commands.add("statusthrift");
			commands.add("version");
			commands.add("tpstats");
			_nodetoolCommands = commands;
			return _nodetoolCommands;
		}
	}

	/**
	 * This method sets the nodeToolCommands
	 * @param commands
	 */
	public static void setNodeToolCommands(String commands) {
		if(StringUtils.isNotEmpty(commands)) {
			_nodetoolCommands = Arrays.asList(commands.split(","));
		}
	}
}
