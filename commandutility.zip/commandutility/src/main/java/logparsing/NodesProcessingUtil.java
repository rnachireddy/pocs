package logparsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import logparsing.model.HostDetails;

public class NodesProcessingUtil {

	private static Session session = null;
	private static String _host = null;
	private static String _user = null;
	private static String _password = null;
	private static int _port = 22;
	private static String _logOutputFolder = null;
	private static String _commandOutputFolder = null;
	private static List<HostDetails> _clusterList = null;
	private static Set<String> _dataCenters = null;
	private static Set<String> _racks = null;
	private static Map<String, HostDetails> _hostMap;

	public static void processAllCassandraNodesInACluster(String user, String password, String host,
			String commandOutputFolder, String logsOutputFolder) throws JSchException, IOException, SftpException {
		_logOutputFolder = logsOutputFolder;
		_commandOutputFolder = commandOutputFolder;
		_clusterList = new ArrayList<>();
		_hostMap = new HashMap<>();
		_dataCenters = new HashSet<>();
		_racks = new HashSet<>();
		getAllNodesInACluster(user, password, host);
		processAllHosts(user, password);
	}

	private static void getAllNodesInACluster(String user, String password, String host) {
		_user = user;
		_password = password;
		_host = host;
		try {
			connect();
			executeCommandToGetNodesInACluster();
			disconnect();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private static void executeCommandToGetNodesInACluster() throws JSchException, IOException {
		String command = "cd /app/cassandra/apache-cassandra*/bin; ./nodetool status";
		Channel channel = session.openChannel("exec");
		((ChannelExec) channel).setCommand(command);
		channel.setInputStream(null);
		((ChannelExec) channel).setErrStream(System.err);
		InputStream in = channel.getInputStream();
		channel.connect();
		StringBuffer buf = new StringBuffer();
		
		byte[] tmp = new byte[1024];
		while (true) {
			while (in.available() > 0) {
				int i = in.read(tmp, 0, 1024);
				if (i < 0)
					break;
				buf.append(new String(tmp, 0, i));
			}
			if (channel.isClosed()) {
				break;
			}
		}
		channel.disconnect();
		extractHostsAndWriteToServersFile(buf);
	}

	private static void extractHostsAndWriteToServersFile(StringBuffer buf) throws IOException {
		String cluster = null;
		for (String str : buf.toString().split("\n")) {
			if (str.indexOf("Datacenter") == 0) {
				cluster = str.split(" ")[1];
			} else {
				Pattern p = Pattern.compile("^(.* )([0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+)( .*)( RAC.*)$");
				Matcher m = p.matcher(str);
				if (m.find()) {
					_clusterList.add(new HostDetails(cluster, m.group(2), m.group(4).trim()));
				}
			}
		}
		prepareAHostMap();
		prepareDataCenters();
		prepareRacks();
	}

	private static void prepareRacks() {
		_clusterList.stream().forEach(data -> {
			_racks.add(data.getRack());
		});
	}

	private static void prepareDataCenters() {
		_clusterList.stream().forEach(data -> {
			_dataCenters.add(data.getCluster());
		});
	}

	private static void prepareAHostMap() {
		_clusterList.stream().forEach(data -> {
			_hostMap.put(data.getHost(), data);
		});
	}

	public static void main(String[] args) throws JSchException, IOException, SftpException {
		String user = "vangsa2";
		String password = "P@ssword";
		processAllHosts(user, password);
	}

	private static void processAllHosts(String user, String password) throws JSchException, IOException, SftpException {
		_user = user;
		_password = password;
		List<String> commands = getAllCommands();
		List<HostDetails> hosts = getHosts();

		for (HostDetails host : hosts) {
			_host = host.getHost();
			connect();
			System.out.println("before executing commands");
			String tempCommandOutputInLinux = "/tmp/commandoutput/";
			String commandZipFile = tempCommandOutputInLinux + _host + ".zip";
			String finalCommand = "mkdir " + tempCommandOutputInLinux + " ; cd /app/cassandra/apache-cassandra*/bin; ";
			for (String command : commands) {
				finalCommand = finalCommand + "./nodetool " + command + " > " + tempCommandOutputInLinux + "/" + command
						+ " ;";
			}
			finalCommand = finalCommand + " cd " + tempCommandOutputInLinux + "; zip " + commandZipFile + " * ;";

			String tempLogOutputInLinux = "/tmp/cassandralogtemp/";
			String logZipFile = tempLogOutputInLinux + _host + ".zip";
			finalCommand += " cd /var/log/cassandra ; mkdir " + tempLogOutputInLinux + " ; zip " + logZipFile + " *";

			executeCommand(finalCommand);
			readZipFilesFromServers(commandZipFile, logZipFile);
			executeCommand("cd /tmp/ ; rm -rf commandoutput ; rm -rf cassandralogtemp ;");
			System.out.println("after executing commands");
			disconnect();
		}
	}

	private static List<String> getAllCommands() throws IOException {
		List<String> commands = new ArrayList<>();
		commands.add("cfstats");
		commands.add("compactionhistory");
		commands.add("compactionstats");
		commands.add("getcompcationthroughput");
		commands.add("gossipinfo");
		commands.add("info");
		commands.add("netstats");
		commands.add("ring");
		commands.add("status");
		commands.add("proxyhistograms");
		commands.add("tablehistograms");
		commands.add("statusbinary");
		commands.add("statusthrift");
		commands.add("version");
		commands.add("tpstats");
		return commands;
		/*ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		File file = new File(classLoader.getResource("allowedCommands.txt").getFile());
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		List<String> lines = br.lines().collect(Collectors.toList());
		br.close();
		return lines;*/
	}

	private static void readZipFilesFromServers(String commandZipFile, String logZipFile)
			throws JSchException, SftpException {
		ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
		channel.connect();
		channel.get(commandZipFile, _commandOutputFolder);
		channel.get(logZipFile, _logOutputFolder);
		channel.disconnect();
	}

	public static List<HostDetails> getHosts() {
		return _clusterList;
	}

	public static Set<String> getDataCenters() {
		return _dataCenters;
	}
	
	public static Set<String> getRacks() {
		return _racks;
	}

	public static Map<String, HostDetails> getHostsAsMap() {
		return _hostMap;
	}

	private static void connect() throws JSchException {
		System.out.println("connecting..." + _host);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		session = jsch.getSession(_user, _host, _port);
		session.setPassword(_password);
		session.setConfig(config);
		session.connect();
		System.out.println("Connected");
	}

	private static void disconnect() {
		if (session != null) {
			System.out.println("disconnecting...");
			session.disconnect();
			System.out.println("disconnected...");
		}
	}

	private static void executeCommand(String command) throws JSchException, IOException {
		ChannelExec channel = (ChannelExec) session.openChannel("exec");
		channel.setErrStream(System.err);
		channel.setCommand(command);
		channel.connect();
		while (true) {
			if (channel.isClosed())
				break;
		}
		channel.disconnect();
	}
}
