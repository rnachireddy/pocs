package logparsing;

/**
 * This class holds the user entered values while running the application 
 *
 */
public class ParseRequest {

	private String thresholdInMilliSeconds;
	private String hours;
	private String minutes;
	private String userName;
	private String password;
	private String host;
	private String ssCountThreshold;
	private String readPercentageThreshold;
	private String writePercentageThreshold;
	private String partMeanThreshold;
	private String partMaxThreshold;
	private String cellsMaxThreshold;
	private String cellsMeanThreshold;
	private String tombstoneMeanThreshold;
	private String tombstoneMaxThreshold;
	private String customRun;

	public String getSsCountThreshold() {
		return ssCountThreshold;
	}

	public void setSsCountThreshold(String ssCountThreshold) {
		this.ssCountThreshold = ssCountThreshold;
	}

	public String getReadPercentageThreshold() {
		return readPercentageThreshold;
	}

	public void setReadPercentageThreshold(String readPercentageThreshold) {
		this.readPercentageThreshold = readPercentageThreshold;
	}

	public String getWritePercentageThreshold() {
		return writePercentageThreshold;
	}

	public void setWritePercentageThreshold(String writePercentageThreshold) {
		this.writePercentageThreshold = writePercentageThreshold;
	}

	public String getThresholdInMilliSeconds() {
		return thresholdInMilliSeconds;
	}

	public void setThresholdInMilliSeconds(String thresholdInMilliSeconds) {
		this.thresholdInMilliSeconds = thresholdInMilliSeconds;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPartMaxThreshold() {
		return partMaxThreshold;
	}

	public void setPartMaxThreshold(String partMaxThreshold) {
		this.partMaxThreshold = partMaxThreshold;
	}

	public String getCellsMeanThreshold() {
		return cellsMeanThreshold;
	}

	public void setCellsMeanThreshold(String cellsMeanThreshold) {
		this.cellsMeanThreshold = cellsMeanThreshold;
	}

	public String getTombstoneMeanThreshold() {
		return tombstoneMeanThreshold;
	}

	public void setTombstoneMeanThreshold(String tombstoneMeanThreshold) {
		this.tombstoneMeanThreshold = tombstoneMeanThreshold;
	}

	public String getCustomRun() {
		return customRun;
	}

	public void setCustomRun(String customRun) {
		this.customRun = customRun;
	}

	public String getPartMeanThreshold() {
		return partMeanThreshold;
	}

	public void setPartMeanThreshold(String partMeanThreshold) {
		this.partMeanThreshold = partMeanThreshold;
	}

	public String getCellsMaxThreshold() {
		return cellsMaxThreshold;
	}

	public void setCellsMaxThreshold(String cellsMaxThreshold) {
		this.cellsMaxThreshold = cellsMaxThreshold;
	}

	public String getTombstoneMaxThreshold() {
		return tombstoneMaxThreshold;
	}

	public void setTombstoneMaxThreshold(String tombstoneMaxThreshold) {
		this.tombstoneMaxThreshold = tombstoneMaxThreshold;
	}
	

}
