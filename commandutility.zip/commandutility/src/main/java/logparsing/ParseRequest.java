package logparsing;

public class ParseRequest {

	private String thresholdInMilliSeconds;
	private String hours;
	private String minutes;
	private String userName;
	private String password;
	private String host;

	public String getThresholdInMilliSeconds() {
		return thresholdInMilliSeconds;
	}

	public void setThresholdInMilliSeconds(String thresholdInMilliSeconds) {
		this.thresholdInMilliSeconds = thresholdInMilliSeconds;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

}
