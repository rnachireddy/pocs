package logparsing.model;

/**
 * This Class holds the host details including cluster, host and rack information
 *
 */
public class HostDetails {

	String cluster;
	String host;
	String rack;

	public HostDetails() {
	}

	public HostDetails(String cluster, String host, String rack) {
		this.cluster = cluster;
		this.host = host;
		this.rack = rack;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getRack() {
		return rack;
	}

	public void setRack(String rack) {
		this.rack = rack;
	}

	@Override
	public String toString() {
		return "HostDetails [cluster=" + cluster + ", host=" + host + ", rack=" + rack + "]";
	}

}
