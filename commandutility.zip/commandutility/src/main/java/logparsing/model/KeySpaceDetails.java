package logparsing.model;

public class KeySpaceDetails {

	private String keySpace;
	private String table;
	private String node;
	private String ssTablesCount;
	private String space;
	private String maxPartition;
	private String meanPartition;
	private String cellsMean;
	private String cellsMax;
	private String meanTombStones;
	private String maxTombStones;

	public String getKeySpace() {
		return keySpace;
	}

	public void setKeySpace(String keySpace) {
		this.keySpace = keySpace;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public String getSsTablesCount() {
		return ssTablesCount;
	}

	public void setSsTablesCount(String ssTablesCount) {
		this.ssTablesCount = ssTablesCount;
	}

	public String getSpace() {
		return space;
	}

	public void setSpace(String space) {
		this.space = space;
	}

	public String getMaxPartition() {
		return maxPartition;
	}

	public void setMaxPartition(String maxPartition) {
		this.maxPartition = maxPartition;
	}

	public String getMeanPartition() {
		return meanPartition;
	}

	public void setMeanPartition(String meanPartition) {
		this.meanPartition = meanPartition;
	}

	public String getCellsMean() {
		return cellsMean;
	}

	public void setCellsMean(String cellsMean) {
		this.cellsMean = cellsMean;
	}

	public String getCellsMax() {
		return cellsMax;
	}

	public void setCellsMax(String cellsMax) {
		this.cellsMax = cellsMax;
	}

	public String getMeanTombStones() {
		return meanTombStones;
	}

	public void setMeanTombStones(String meanTombStones) {
		this.meanTombStones = meanTombStones;
	}

	public String getMaxTombStones() {
		return maxTombStones;
	}

	public void setMaxTombStones(String maxTombStones) {
		this.maxTombStones = maxTombStones;
	}

	@Override
	public String toString() {
		return "KeySpaceDetails [keySpace=" + keySpace + ", table=" + table + ", node=" + node + ", ssTablesCount="
				+ ssTablesCount + ", space=" + space + ", maxPartition=" + maxPartition + ", meanPartition="
				+ meanPartition + ", cellsMean=" + cellsMean + ", cellsMax=" + cellsMax + ", meanTombStones="
				+ meanTombStones + ", maxTombStones=" + maxTombStones + "]";
	}

}
