package logparsing.model;

/**
 * This class holds the error/warning count of all the hosts and cluster combinations 
 *
 */
public class ClusterViewDetail {

	String host;
	String cluster;
	String errorCount;
	String warningCount;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public String getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	public String getWarningCount() {
		return warningCount;
	}

	public void setWarningCount(String warningCount) {
		this.warningCount = warningCount;
	}

}
