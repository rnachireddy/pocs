package logparsing.model;

public class ParameterSummary {

	private String maxStatus;
	private String node;
	private String maxTimeStamp;
	private int maxGC;
	private int commitLogAllocatorCount;
	private int slabPoolCleanerCount;
	private int scheduleTaskCount;
	private int compactionExecutorCount;
	private int repairJobTaskCount;
	private String minTimeStamp;
	private int minGC;
	private int gcCount;

	public ParameterSummary(String maxStatus, String node, String maxTimeStamp, int maxGC, int commitLogAllocatorCount,
			int slabPoolCleanerCount, int scheduleTaskCount, int compactionExecutorCount, int repairJobTaskCount,
			String minTimeStamp, int minGC, int gcCount) {
		super();
		this.maxStatus = maxStatus;
		this.node = node;
		this.maxTimeStamp = maxTimeStamp;
		this.maxGC = maxGC;
		this.commitLogAllocatorCount = commitLogAllocatorCount;
		this.slabPoolCleanerCount = slabPoolCleanerCount;
		this.scheduleTaskCount = scheduleTaskCount;
		this.compactionExecutorCount = compactionExecutorCount;
		this.repairJobTaskCount = repairJobTaskCount;
		this.minTimeStamp = minTimeStamp;
		this.minGC = minGC;
		this.gcCount = gcCount;
	}

	public String getMaxStatus() {
		return maxStatus;
	}

	public void setMaxStatus(String maxStatus) {
		this.maxStatus = maxStatus;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public String getMaxTimeStamp() {
		return maxTimeStamp;
	}

	public void setMaxTimeStamp(String maxTimeStamp) {
		this.maxTimeStamp = maxTimeStamp;
	}

	public int getMaxGC() {
		return maxGC;
	}

	public void setMaxGC(int maxGC) {
		this.maxGC = maxGC;
	}

	public int getCommitLogAllocatorCount() {
		return commitLogAllocatorCount;
	}

	public void setCommitLogAllocatorCount(int commitLogAllocatorCount) {
		this.commitLogAllocatorCount = commitLogAllocatorCount;
	}

	public int getSlabPoolCleanerCount() {
		return slabPoolCleanerCount;
	}

	public void setSlabPoolCleanerCount(int slabPoolCleanerCount) {
		this.slabPoolCleanerCount = slabPoolCleanerCount;
	}

	public int getScheduleTaskCount() {
		return scheduleTaskCount;
	}

	public void setScheduleTaskCount(int scheduleTaskCount) {
		this.scheduleTaskCount = scheduleTaskCount;
	}

	public int getCompactionExecutorCount() {
		return compactionExecutorCount;
	}

	public void setCompactionExecutorCount(int compactionExecutorCount) {
		this.compactionExecutorCount = compactionExecutorCount;
	}

	public int getRepairJobTaskCount() {
		return repairJobTaskCount;
	}

	public void setRepairJobTaskCount(int repairJobTaskCount) {
		this.repairJobTaskCount = repairJobTaskCount;
	}

	public String getMinTimeStamp() {
		return minTimeStamp;
	}

	public void setMinTimeStamp(String minTimeStamp) {
		this.minTimeStamp = minTimeStamp;
	}

	public int getMinGC() {
		return minGC;
	}

	public void setMinGC(int minGC) {
		this.minGC = minGC;
	}

	public int getGcCount() {
		return gcCount;
	}

	public void setGcCount(int gcCount) {
		this.gcCount = gcCount;
	}

}
