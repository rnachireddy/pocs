package logparsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import logparsing.model.ParameterSummary;

import org.apache.commons.lang3.StringUtils;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class ParsingUtil {

	private static List<Log> logList;
	private static Date currentDate;
	private static long timeInMilliSeconds;
	private static long thresholdTimeInMilliSeconds;
	private static String currentHost;
	
	
	private static List<ParameterSummary> parameterSummaryList; 
	private static Map<String, List<Log>> reportHashMap =  new HashMap<String, List<Log>>(); 

	public static void parseLogFile(ParseRequest request)
			throws IOException, ParseException, JSchException, SftpException {
		logList = new ArrayList<>();
		currentDate = new Date();
		timeInMilliSeconds = getTimeInMillisecondsFromRequest(request);
		thresholdTimeInMilliSeconds = getThresholdTimeFromRequest(request);
		SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
		String dateString = format.format(new Date());
		String outputFolder = Constants.OUTPUT_FILE_PATH + File.separator + request.getHost() + "_" + dateString
				+ File.separator + "nodes";
		String logOutputFolder = outputFolder + File.separator + "logs";
		/*String commandOutputFolder = outputFolder + File.separator + "commands";
		File file = new File(logOutputFolder);
		if (!file.exists()) {
			file.mkdirs();
		}
		file = new File(commandOutputFolder);
		if (!file.exists()) {
			file.mkdirs();
		}
		NodesProcessingUtil.processAllCassandraNodesInACluster(request.getUserName(), request.getPassword(),
				request.getHost(), commandOutputFolder, logOutputFolder);
		fileReader(logOutputFolder);*/
		fileReader("C:\\var\\log\\cassandra");
		System.out.println("logList ::"+logList);
		reportHashMap = processMap(logList);
		System.out.println("ReportMap Size ::"+reportHashMap.size());
		System.out.println("Report HashMap ::"+reportHashMap);
		getParameterSummaryList();
		PDFGeneratorUtil.generateReport(logList, parameterSummaryList, request.getHost(),reportHashMap.size());
		
		System.out.println("Files copied from server at this path" + Constants.OUTPUT_FILE_PATH);
	}

	private static long getTimeInMillisecondsFromRequest(ParseRequest request) {
		long time = 0;
		if (!StringUtils.isEmpty(request.getHours())) {
			time = (long) (Constants.ONE_HOUR_IN_MILLISECONDS * Double.parseDouble(request.getHours()));
		}
		if (!StringUtils.isEmpty(request.getMinutes())) {
			time = time + (long) (Constants.ONE_MINUTE_IN_MILLISECONDS * Double.parseDouble(request.getMinutes()));
		}
		if (time == 0) {
			time = Constants.ONE_HOUR_IN_MILLISECONDS;
		}
		return time;
	}

	private static long getThresholdTimeFromRequest(ParseRequest request) {
		long threshold = Constants.DEFAULT_THRESHOLD_IN_MILLISECONDS;
		if (!StringUtils.isEmpty(request.getThresholdInMilliSeconds())) {
			threshold = Long.parseLong(request.getThresholdInMilliSeconds());
		}
		return threshold;
	}

	private static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);

	}

	private static void fileReader(File file) throws FileNotFoundException, IOException {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File f : files) {
				fileReader(f);
			}
		} else if (file.getName().endsWith(".zip")) {
			currentHost = file.getName().split(".zip")[0];
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(fileInputStream);
			fileInputStream.close();
		}
	}

	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (isFileConsideredForProcessing(
					Date.from(entry.getLastModifiedTime().toInstant().atZone(ZoneId.systemDefault()).toInstant()),
					currentDate)) {
				if (entry.getName().endsWith(".zip")) {
					extractZip(zipInputStream);
				} else {
					extractFileContents(zipInputStream);
				}
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	private static boolean isFileConsideredForProcessing(Date fileDate, Date currentDate) {
		long timeDifferenceInMilliSeconds = currentDate.getTime() - fileDate.getTime();
		if (timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
			return true;
		}
		return false;
	}

	private static void extractFileContents(InputStream inputStream) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		for (int i = collector.size() - 1; i > 0; i--) {
			String line = collector.get(i);
			Log log = extractLog(line);
			if (log == null) {
				continue;
			} else if (isLogConsideredForProcessing(log, currentDate)) {
				log.setHostName(currentHost);
				//log.setCluster(NodesProcessingUtil.getHostsAsMap().get(currentHost).getCluster());
				//log.setRack(NodesProcessingUtil.getHostsAsMap().get(currentHost).getRack());
				logList.add(log);
			} else {
				return;
			}
		}
	}

	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			Date date = format.parse(timeStamp);
			long timeDifferenceInMilliSeconds = currentDate.getTime() - date.getTime();
			if (timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
				return true;
			}
		} catch (ParseException e) {

		}
		return false;
	}

	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if (log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if (timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			if (log.getThreadName().equals(Constants.THREADNAME_SCHEDULEDTASKS)
					|| log.getThreadName().equals(Constants.THREADNAME_SLABPOOLCLEANER)
					|| log.getThreadName().equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				Double memoryUsed = extractMemoryFromDescription(log.getDescription());
				log.setMemoryUsed(memoryUsed);
			}
			return log;
		}
		return null;
	}

	private static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	private static Double extractMemoryFromDescription(String description) {
		Pattern p = Pattern.compile("^(.*: )(\\d*)( \\(.*)*$");
		Matcher m = p.matcher(description);
		// if memory is given in bytes
		if (m.find()) {
			Double memoryUsed = Long.valueOf(m.group(2)).doubleValue() / 1024 / 1024 / 1024;
			return memoryUsed;
		}
		p = Pattern.compile("^(.*: )(\\d*\\.\\d*)(MiB.*)*$");
		m = p.matcher(description);
		// 86.700MiB
		// if memory is given in mib
		if (m.find()) {
			Double memoryUsed = Double.valueOf(m.group(2)).doubleValue() / 1024;
			return memoryUsed;
		}
		return null;
	}

	private String getClusterFromIp() {

		return null;
	}
	
	private static Map<String, List<Log>>processMap(List<Log> logs) throws FileNotFoundException {
        Map<String, List<Log>> map = new HashMap<>();
        
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        File file = new File(classLoader.getResource("servers.txt").getFile());
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        List<String> lines = br.lines().collect(Collectors.toList());
        
        for(String hostName : lines) {
               List<Log> list = logs.stream().filter(log -> {
                     return hostName.equals(log.getHostName());
               }).collect(Collectors.toList());
               map.put(hostName, list);
        }
        return map;
 }

 private static void  getParameterSummaryList() {
        
        parameterSummaryList = new ArrayList<ParameterSummary>();
        for (Map.Entry<String,List<Log>> entry : reportHashMap.entrySet()) {
               parameterSummaryList.add(getSummaryTabelReport(entry.getKey(), entry.getValue()));
             
     } 
        System.out.println("parameterSummaryList ::"+parameterSummaryList);
 }
 private static ParameterSummary getSummaryTabelReport(String hostName, List<Log> logListObj){
        ParameterSummary summaryTableObj = null;
        
        String node = hostName;
        
        String status = null;
        String timeStamp = null ;
        int maxGC = 0;
        
        int slabPoolCleanerCount=0;
        int commitLogAllocatorCount=0;
        int scheduleTaskCount=0;
        int compactionExecutorCount=0;
        int repairJobTaskCount=0;
        
        for(Log log : logListObj){
               if(log.getClassName().equalsIgnoreCase("GCInspector.java")) {
                     Integer timeInMilliSeconds = extractThreshold(log.getDescription());
                     if(timeInMilliSeconds != null && (timeInMilliSeconds > maxGC)) {
                            maxGC = timeInMilliSeconds;
                            status = log.getLogType();
                            timeStamp = log.getTimeStamp();
                            
                     }
               }else if(log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SCHEDULEDTASKS)){
                     scheduleTaskCount++;
               }else if(log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_SLABPOOLCLEANER)){
                     slabPoolCleanerCount++;
               }else if(log.getThreadName().equalsIgnoreCase(Constants.THREADNAME_COMMITLOGALLOCATOR)){
                     commitLogAllocatorCount++;
               }
               //compactionExecutorCount and repairJobTaskCount updatres to be implemented
        }
        
        summaryTableObj = new ParameterSummary(status, node, timeStamp, maxGC, commitLogAllocatorCount, slabPoolCleanerCount, scheduleTaskCount, compactionExecutorCount, repairJobTaskCount);
        return summaryTableObj;
        
 }


}
