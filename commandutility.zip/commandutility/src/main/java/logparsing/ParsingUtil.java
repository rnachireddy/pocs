package logparsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class ParsingUtil {
	
	private static Logger log =LoggerFactory.getLogger(ParsingUtil.class.getName());

	private static List<Log> logList;
	private static Map<String, List<Log>> logMap;
	private static Date currentDate;
	private static long timeInMilliSeconds;
	private static long thresholdTimeInMilliSeconds;
	private static String currentHost;
	private static String cluster;
	private static String rack;

	/**
	 * This method contains the parsing logic for the user entered inputs
	 * @param request - holds the user entered inputs
	 * @throws IOException
	 * @throws ParseException
	 * @throws JSchException
	 * @throws SftpException
	 * @throws Exception
	 */
	public static void parseLogFile(ParseRequest request)
			throws IOException, ParseException, JSchException, SftpException, Exception {
		log.info("Entering inside parseLogFile : ParseRequest :: {}", request);
		logList = new ArrayList<>();
		logMap = new HashMap<>();
		currentDate = new Date();
		timeInMilliSeconds = getTimeInMillisecondsFromRequest(request);
		thresholdTimeInMilliSeconds = getThresholdTimeFromRequest(request);
		SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
		String dateString = format.format(new Date());
		String outputFolder = Constants.OUTPUT_FILE_PATH + File.separator + request.getHost() + "_" + dateString
				+ File.separator + "nodes";
		String logOutputFolder = outputFolder + File.separator + "logs";
		String commandOutputFolder = outputFolder + File.separator + "commands";
		File file = new File(logOutputFolder);
		if (!file.exists()) {
			file.mkdirs();
		}
		file = new File(commandOutputFolder);
		if (!file.exists()) {
			file.mkdirs();
		}
		NodesProcessingUtil.processAllCassandraNodesInACluster(request.getUserName(), request.getPassword(),
				request.getHost(), request.getCustomRun(), commandOutputFolder, logOutputFolder);
		log.info("Pulled all log and command information");
		log.info("Start log reading and processing : logOutputFolder : {}", logOutputFolder);
		fileReader(logOutputFolder);
		CommandProcessingUtil.processAllCommands(commandOutputFolder);
		PDFGeneratorUtil.generateReport(logList, logMap, request);
		log.info("Report is generated at path : " + Constants.OUTPUT_FILE_PATH);
	}

	/**
	 * Method to get the time in milliseconds from the user given time
	 * @param request
	 * @return
	 */
	private static long getTimeInMillisecondsFromRequest(ParseRequest request) {
		long time = 0;
		if (!StringUtils.isEmpty(request.getHours())) {
			time = (long) (Constants.ONE_HOUR_IN_MILLISECONDS * Double.parseDouble(request.getHours()));
		}
		if (!StringUtils.isEmpty(request.getMinutes())) {
			time = time + (long) (Constants.ONE_MINUTE_IN_MILLISECONDS * Double.parseDouble(request.getMinutes()));
		}
		if (time == 0) {
			time = Constants.ONE_HOUR_IN_MILLISECONDS;
		}
		return time;
	}

	/**
	 * Method to get the threshold time in milliseconds
	 * @param request
	 * @return
	 */
	private static long getThresholdTimeFromRequest(ParseRequest request) {
		long threshold = Constants.DEFAULT_THRESHOLD_IN_MILLISECONDS;
		if (!StringUtils.isEmpty(request.getThresholdInMilliSeconds())) {
			threshold = Long.parseLong(request.getThresholdInMilliSeconds());
		}
		return threshold;
	}

	/**
	 * Method to read the file from the specified file path
	 * @param file - file path
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws Exception
	 */
	private static void fileReader(String file) throws FileNotFoundException, IOException, Exception {
		File f = new File(file);
		fileReader(f);

	}

	/**
	 * Generic Method to read the folder 
	 * @param file - file object
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws Exception
	 */
	private static void fileReader(File file) throws FileNotFoundException, IOException, Exception {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File f : files) {
				fileReader(f);
			}
		} else if (file.getName().endsWith(".zip")) {
			currentHost = file.getName().split(".zip")[0];
			logMap.put(currentHost, new ArrayList<>());
			if(NodesProcessingUtil.getHostsAsMap() != null && NodesProcessingUtil.getHostsAsMap().size() > 0){
				cluster = NodesProcessingUtil.getHostsAsMap().get(currentHost).getCluster();
				rack = NodesProcessingUtil.getHostsAsMap().get(currentHost).getRack();
			}
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else if (file.getName().endsWith(".gz")) {
			currentHost = file.getName().split(".tar.gz")[0];
			logMap.put(currentHost, new ArrayList<>());
			if(NodesProcessingUtil.getHostsAsMap() != null && NodesProcessingUtil.getHostsAsMap().size() > 0){
				cluster = NodesProcessingUtil.getHostsAsMap().get(currentHost).getCluster();
				rack = NodesProcessingUtil.getHostsAsMap().get(currentHost).getRack();
			}
			FileInputStream fileInputStream = new FileInputStream(file);
			extractGZip(fileInputStream);
			fileInputStream.close();
		}  else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(fileInputStream);
			fileInputStream.close();
		}
	}

	/**
	 * Method to read the zip file
	 * @param inputStream
	 * @throws IOException
	 * @throws Exception
	 */
	private static void extractZip(InputStream inputStream) throws IOException, Exception {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (isFileConsideredForProcessing(
					Date.from(entry.getLastModifiedTime().toInstant().atZone(ZoneId.systemDefault()).toInstant()),
					currentDate)) {
				if (entry.getName().endsWith(".zip") && entry.getName().contains("debug")) {
					extractZip(zipInputStream);
				} else if (entry.getName().endsWith(".gz") && entry.getName().contains("debug")) {
					extractGZip(zipInputStream);
				} else if (entry.getName().contains("debug")) {
					extractFileContents(zipInputStream);
				}
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	/**
	 * Method to read the Gzip files
	 * @param is
	 * @throws Exception
	 */
	private static void extractGZip(InputStream is) throws Exception {
		TarArchiveInputStream tais = new TarArchiveInputStream(new GZIPInputStream(is));
		TarArchiveEntry nextEntry = tais.getNextTarEntry();
		while(nextEntry != null) {
			if (isFileConsideredForProcessing(
					Date.from(nextEntry.getLastModifiedDate().toInstant().atZone(ZoneId.systemDefault()).toInstant()),
					currentDate)) {
				if(nextEntry.getName().endsWith(".zip") && nextEntry.getName().contains("debug")) {
					extractZip(tais);
				} else if (nextEntry.getName().endsWith(".gz")) {
					extractGZip(tais);
				} else if(!nextEntry.getName().endsWith("/") && nextEntry.getName().contains("debug")) {
					extractFileContents(tais);
				}
			}
			nextEntry = tais.getNextTarEntry();
		}
	}
	/**
	 * Method to decide whether the file is considered for further processing based on the files timestamp
	 * @param fileDate
	 * @param currentDate
	 * @return
	 */
	private static boolean isFileConsideredForProcessing(Date fileDate, Date currentDate) {
		long timeDifferenceInMilliSeconds = currentDate.getTime() - fileDate.getTime();
		if (timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
			return true;
		}
		return false;
	}

	/**
	 * Method to read the file contents
	 * @param inputStream
	 * @throws IOException
	 * @throws Exception
	 */
	private static void extractFileContents(InputStream inputStream) throws IOException, Exception{

		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		for (int i = collector.size() - 1; i > 0; i--) {
			String line = collector.get(i);
			if ((line.startsWith("INFO") || line.startsWith("DEBUG") || line.startsWith("ERROR")
					|| line.startsWith("WARN") || line.startsWith("TRACE"))
					&& !line.contains("DiskBoundaryManager.java") && line.length() <= 1000) {
				Log log = extractLog(line);
				if (log == null) {
					continue;
				} else if (isLogConsideredForProcessing(log, currentDate)) {
					log.setHostName(currentHost);
					log.setCluster(cluster);
					log.setRack(rack);
					logMap.get(currentHost).add(log);
					logList.add(log);
				} else {
					return;
				}
			}
		}
	}

	/**
	 * This method tells whether the log is considered for processing for the given time
	 * @param log
	 * @param currentDate
	 * @return
	 */
	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			Date date = format.parse(timeStamp);
			long timeDifferenceInMilliSeconds = currentDate.getTime() - date.getTime();
			if (timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
				return true;
			}
		} catch (ParseException e) {

		}
		return false;
	}

	/**
	 * Method to extract the log object from the line in the log file
	 * @param str
	 * @return
	 */
	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if (log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if (timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			/*
			 * if (log.getThreadName().equals(Constants.THREADNAME_SCHEDULEDTASKS) ||
			 * log.getThreadName().equals(Constants.THREADNAME_SLABPOOLCLEANER) ||
			 * log.getThreadName().equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) { Double
			 * memoryUsed = extractMemoryFromDescription(log.getDescription());
			 * log.setMemoryUsed(memoryUsed); }
			 */
			return log;
		}
		return null;
	}

	/**
	 * Method to extract the threshold from the log description
	 * @param description
	 * @return
	 */
	private static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	public static long getTimeInMilliSeconds(){
		return timeInMilliSeconds;
	}

}
