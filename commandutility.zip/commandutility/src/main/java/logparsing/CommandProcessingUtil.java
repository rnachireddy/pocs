package logparsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import logparsing.model.KeySpaceDetails;

public class CommandProcessingUtil {

	private static String currentHost = null;
	private static List<KeySpaceDetails> keySpaceList = null;

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		CommandProcessingUtil
				.processAllCommands("C:\\Users\\vangsa2\\Logs\\var\\log\\cassandra\\commands");
		System.out.println(CommandProcessingUtil.getKeySpaceSummary());
	}

	public static void processAllCommands(String commandOutputFolder) throws FileNotFoundException, IOException {
		keySpaceList = new ArrayList<>();
		fileReader(commandOutputFolder);
	}

	private static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);
	}

	private static void fileReader(File file) throws FileNotFoundException, IOException {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File f : files) {
				fileReader(f);
			}
		} else if (file.getName().endsWith(".zip")) {
			currentHost = file.getName().split(".zip")[0];
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(fileInputStream);
			fileInputStream.close();
		}
	}

	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (entry.getName().endsWith(".zip")) {
				extractZip(zipInputStream);
			} else if (entry.getName().equals("cfstats")) {
				extractFileContents(zipInputStream);
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	private static void extractFileContents(InputStream inputStream) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		String keySpace = null;
		String table = null;
		String ssTableCount = null;
		for (int i = 0; i < collector.size(); i++) {
			String line = collector.get(i);
			if (line.startsWith("----")) {
				keySpace = null;
				table = null;
				ssTableCount = null;
				continue;
			}
			if (line.startsWith("Keyspace")) {
				keySpace = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tTable")) {
				table = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tSSTable count")) {
				ssTableCount = line.split(":")[1].trim();
			} else if (line.equals("")) {
				KeySpaceDetails ksd = new KeySpaceDetails();
				ksd.setKeySpace(keySpace);
				ksd.setTable(table);
				ksd.setNode(currentHost);
				ksd.setSsTablesCount(ssTableCount);
				keySpaceList.add(ksd);
				ssTableCount = null;
				table = null;
			}

		}
	}

	public static List<KeySpaceDetails> getKeySpaceSummary() {
		return keySpaceList;
	}
}
