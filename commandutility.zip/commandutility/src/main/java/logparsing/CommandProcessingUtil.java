package logparsing;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import logparsing.model.KeySpaceDetails;
/**
 * Utility used to read and process all the nodetool commands 
 *
 */
public class CommandProcessingUtil {
	
	private static Logger log =LoggerFactory.getLogger(CommandProcessingUtil.class.getName());

	private static String currentHost = null;
	private static List<KeySpaceDetails> keySpaceList = null;

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		CommandProcessingUtil
				.processAllCommands("C:\\Users\\vangsa2\\Logs\\var\\log\\cassandra\\10.119.8.30_2018_12_21_10_52\\nodes\\commands");
		System.out.println(CommandProcessingUtil.getKeySpaceSummary());
	}

	/**
	 * This method is used to process all the commands that are specified at given folder
	 * @param commandOutputFolder
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void processAllCommands(String commandOutputFolder) throws FileNotFoundException, IOException {
		keySpaceList = new ArrayList<>();
		fileReader(commandOutputFolder);
	}

	/**
	 * This method is used to read folder
	 * @param file - folder path to read
	 */
	private static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);
	}

	/**
	 * This method is used to read folder
	 * @param file - file object
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static void fileReader(File file) throws FileNotFoundException, IOException {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File f : files) {
				fileReader(f);
			}
		} else if (file.getName().endsWith(".zip")) {
			currentHost = file.getName().split(".zip")[0];
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else if (file.getName().endsWith(".gz")) {
			currentHost = file.getName().split(".tar.gz")[0];
			FileInputStream fileInputStream = new FileInputStream(file);
			extractGZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(fileInputStream);
			fileInputStream.close();
		}
	}

	private static void extractGZip(InputStream is) throws IOException {
		TarArchiveInputStream tais = new TarArchiveInputStream(new GZIPInputStream(is));
		TarArchiveEntry nextEntry = tais.getNextTarEntry();
		while(nextEntry != null) {
			if(nextEntry.getName().endsWith(".zip")) {
				extractZip(tais);
			} else if (nextEntry.getName().endsWith(".gz")) {
				extractGZip(tais);
			} else if(nextEntry.getName().endsWith("cfstats")) {
				extractFileContents(tais);
			}
			nextEntry = tais.getNextTarEntry();
		}
	}
	
	/**
	 * Method to read the contents of a zip file
	 * @param inputStream
	 * @throws IOException
	 */
	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (entry.getName().endsWith(".zip")) {
				extractZip(zipInputStream);
			} else if (entry.getName().endsWith(".gz")) {
				extractGZip(zipInputStream);
			}  else if (entry.getName().equals("cfstats")) {
				extractFileContents(zipInputStream);
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	/**
	 * Method to extract the file contents 
	 * @param inputStream
	 * @throws IOException
	 */
	private static void extractFileContents(InputStream inputStream) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		String keySpace = null;
		String table = null;
		String ssTableCount = null;
		String space = null;
		String maxPartition = null;
		String meanPartition = null;
		String cellsMean = null;
		String cellsMax = null;
		String meanTombStones = null;
		String maxTombStones = null;
		String totalReadCount = null;
		String totalWriteCount = null;
		String localReadCount = null;
		String localWriteCount = null;
		String localReadLatency = null;
		String localWriteLatency = null;

		for (int i = 0; i < collector.size(); i++) {
			String line = collector.get(i);
			if (line.startsWith("----")) {
				keySpace = null;
				table = null;
				ssTableCount = null;
				space = null;
				maxPartition = null;
				meanPartition = null;
				cellsMean = null;
				cellsMax = null;
				meanTombStones = null;
				maxTombStones = null;
				totalReadCount = null;
				totalWriteCount = null;
				localReadCount = null;
				localWriteCount = null;
				localReadLatency = null;
				localWriteLatency = null;
				continue;
			}
			if (line.startsWith("Keyspace")) {
				keySpace = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tTable")) {
				table = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tSSTable count")) {
				ssTableCount = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tSpace used (live)")) {
				space = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tCompacted partition maximum bytes")) {
				maxPartition = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tCompacted partition mean bytes")) {
				meanPartition = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tAverage live cells per slice")) {
				cellsMean = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tMaximum live cells per slice")) {
				cellsMax = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tAverage tombstones per slice")) {
				meanTombStones = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tMaximum tombstones per slice")) {
				maxTombStones = line.split(":")[1].trim();
			} else if (line.startsWith("\tRead Count")) {
				totalReadCount = line.split(":")[1].trim();
			} else if (line.startsWith("\tWrite Count")) {
				totalWriteCount = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tLocal read count")) {
				localReadCount = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tLocal write count")) {
				localWriteCount = line.split(":")[1].trim();
			}  else if (line.startsWith("\t\tLocal read latency")) {
				localReadLatency = line.split(":")[1].trim();
			} else if (line.startsWith("\t\tLocal write latency")) {
				localWriteLatency = line.split(":")[1].trim();
			} else if (line.equals("")) {
				KeySpaceDetails ksd = new KeySpaceDetails();
				ksd.setKeySpace(keySpace);
				ksd.setTable(table);
				ksd.setNode(currentHost);
				ksd.setSsTablesCount(ssTableCount);
				ksd.setSpace(space);
				ksd.setMaxPartition(maxPartition);
				ksd.setMeanPartition(meanPartition);
				ksd.setCellsMax(cellsMax);
				ksd.setCellsMean(cellsMean);
				ksd.setMaxTombStones(maxTombStones);
				ksd.setMeanTombStones(meanTombStones);
				ksd.setTotalReadCount(totalReadCount);
				ksd.setTotalWriteCount(totalWriteCount);
				ksd.setLocalReadCount(localReadCount);
				ksd.setLocalWriteCount(localWriteCount);
				ksd.setLocalReadLatency(localReadLatency);
				ksd.setLocalWriteLatency(localWriteLatency);
				keySpaceList.add(ksd);
				ssTableCount = null;
				table = null;
				space = null;
				maxPartition = null;
				meanPartition = null;
				cellsMean = null;
				cellsMax = null;
				meanTombStones = null;
				maxTombStones = null;
				localReadCount = null;
				localWriteCount = null;
				localReadLatency = null;
				localWriteLatency = null;
			}

		}
	}

	/**
	 * Method that gives the KeySpaceDetails of all the hosts
	 * @return
	 */
	public static List<KeySpaceDetails> getKeySpaceSummary() {
		return keySpaceList;
	}
}
