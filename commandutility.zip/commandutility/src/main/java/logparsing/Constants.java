package logparsing;

public class Constants {

	public static final long ONE_HOUR_IN_MILLISECONDS = 3600000;
	public static final long ONE_MINUTE_IN_MILLISECONDS = 60000;
	public static final int DEFAULT_THRESHOLD_IN_MILLISECONDS = 250;
	public static final String THREADNAME_COMMITLOGALLOCATOR = "COMMIT-LOG-ALLOCATOR";
	public static final String THREADNAME_SLABPOOLCLEANER = "SlabPoolCleaner";
	public static final String THREADNAME_SCHEDULEDTASKS = "ScheduledTasks";
	public static final String THREADNAME_REPAIRJOBTASK = "RepairJobTask";
	public static final String THREADNAME_COMPACTIONEXECUTOR = "CompactionExecutor";
	
	public static final String COMMAND_LINE_ARGUMENT_THRESHOLD = "threshold";
	public static final String COMMAND_LINE_ARGUMENT_HOURS = "hours";
	public static final String COMMAND_LINE_ARGUMENT_MINUTES = "minutes";
	public static final String COMMAND_LINE_ARGUMENT_USERNAME = "username";
	public static final String COMMAND_LINE_ARGUMENT_PASSWORD = "password";
	public static final String COMMAND_LINE_ARGUMENT_NOOFMAXGC = "noOfGc";
	public static final String COMMAND_LINE_ARGUMENT_HOST = "host";
	public static final int HOST_PORT = 22;
	public static final String OUTPUT_FILE_PATH = "/var/tmp/logparser";
	
	public static final String COMMAND_LINE_ARUGMENT_SSCOUNT_THRESHOLD = "ssCountThreshold";
	public static final String COMMAND_LINE_ARUGMENT_READ_PERCENTAGE_THRESHOLD = "readPercentageThreshold";
	public static final String COMMAND_LINE_ARUGMENT_WRITE_PERCENTAGE_THRESHOLD = "writePercentageThreshold";
	public static final String COMMAND_LINE_ARUGMENT_PART_MAX_THRESHOLD = "partMaxThreshold";
	public static final String COMMAND_LINE_ARUGMENT_CELLS_MEAN_THRESHOLD = "cellsMeanThreshold";
	public static final String COMMAND_LINE_ARUGMENT_TOMBSTONES_MEAN_THRESHOLD = "tombstoneMeanThreshold";
	
	public static final int DEFAULT_SSCOUNT_THRESHOLD = 50;
	public static final int DEFAULT_READ_PERCENTAGE_THRESHOLD = 2;
	public static final int DEFAULT_WRITE_PERCENTAGE_THRESHOLD = 2;
	public static final int DEFAULT_PART_MAX_THRESHOLD = 100;
	public static final int DEFAULT_CELL_MEAN_THRESHOLD = 300;
	public static final int DEFAULT_TOMBSTONES_MEAN_THRESHOLD = 30;
}


