package logparsing;

public class Constants {
	public static final String LOGS_FILE_PATH = "C:\\Users\\vangsa2\\Logs\\var\\log\\cassandra";
	public static final long ONE_HOUR_IN_MILLISECONDS = 3600000;
	public static final long ONE_MINUTE_IN_MILLISECONDS = 60000;
	public static final int DEFAULT_THRESHOLD_IN_MILLISECONDS = 250;
	public static final String THREADNAME_COMMITLOGALLOCATOR = "COMMIT-LOG-ALLOCATOR";
	public static final String THREADNAME_SLABPOOLCLEANER = "SlabPoolCleaner";
	public static final String THREADNAME_SCHEDULEDTASKS = "ScheduledTasks";
	
	public static final String COMMAND_LINE_ARGUMENT_THRESHOLD = "threshold";
	public static final String COMMAND_LINE_ARGUMENT_HOURS = "hours";
	public static final String COMMAND_LINE_ARGUMENT_MINUTES = "minutes";
	public static final String COMMAND_LINE_ARGUMENT_USERNAME = "username";
	public static final String COMMAND_LINE_ARGUMENT_PASSWORD = "password";
	public static final String COMMAND_LINE_ARGUMENT_NOOFMAXGC = "noOfGc";
	public static final String COMMAND_LINE_ARGUMENT_HOST = "host";
	public static final int HOST_PORT = 22;
	public static final String OUTPUT_FILE_PATH = "C:\\var\\log\\output";
	
	
	/*
	public static final String OUTPUT_FILE_PATH = "C:\\Users\\Kh2244\\Desktop\\sandeep\\var\\log\\";
	
	public static final List<String> DEFAULT_THREAD_NAMES = Arrays.asList("COMMIT-LOG-ALLOCATOR", "SlabPoolCleaner", "ScheduledTasks", "RepairJobTask", "CompactionExecutor", "MemtableFlushWriter");
	public static final List<String> DEFAULT_LOG_TYPES = Arrays.asList("WARN", "ERROR");
	
	
	public static final String THREADNAME_REPAIRJOBTASK = "RepairJobTask";
	public static final String THREADNAME_COMPACTIONEXECUTOR = "CompactionExecutor";
	public static final String THREADNAME_MEMTABLEFLUSHWRITER = "MemtableFlushWriter";
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss,SSS";
	public static final String CASSANDRA_DIRECTORY_PATH_IN_SERVERS = "/var/log/cassandra";
	public static final int HOST_PORT = 22;
	public static final String LINUX_COMMAND_OUTPUT_FOLDER_PATH = "C:\\Users\\vangsa2\\Logs\\var\\command\\latest";
	public static final String LINUX_BASE_COMMAND_OUTPUT_FOLDER_PATH = "C:\\Users\\vangsa2\\Logs\\var\\command\\base";
*/
	
}


