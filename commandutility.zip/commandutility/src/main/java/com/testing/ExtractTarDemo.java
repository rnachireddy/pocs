package com.testing;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;

import logparsing.NodesProcessingUtil;

public class ExtractTarDemo {

	public static void main(String[] args) throws Exception {
		File file = new File("C:\\Users\\vangsa2\\Logs\\var\\log\\cassandra\\10.11.157.14_2018_12_24_02_23\\nodes\\logs\\10.11.157.14.tar.gz");
		//C:\Users\vangsa2\Logs\var\log\cassandra\10.11.157.14_2018_12_24_02_23\nodes\logs\10.11.157.14.tar.gz
		String currentHost = null;
		System.out.println("File Name ::"+file.getName());
		if (file.getName().endsWith(".zip")) {
			currentHost = file.getName().split(".zip")[0];
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else if (file.getName().endsWith(".gz")) {
			currentHost = file.getName().split(".tar.gz")[0];
			System.out.println("currentHost ::"+currentHost);
			FileInputStream fileInputStream = new FileInputStream(file);
			extractGZip(fileInputStream);
		}
		
	}
	
	private static void extractZip(InputStream inputStream) throws IOException, Exception {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			
				if (entry.getName().endsWith(".zip") && entry.getName().contains("debug")) {
					extractZip(zipInputStream);
				} else if (entry.getName().endsWith(".gz") && entry.getName().contains("debug")) {
					extractGZip(zipInputStream);
				} else if (entry.getName().contains("debug")) {
					extractFileContents(zipInputStream);
				}
			}
			entry = zipInputStream.getNextEntry();
		
	}

	/*private static void extractGZip(InputStream is) throws Exception {
		TarArchiveInputStream tais = new TarArchiveInputStream(new GZIPInputStream(is));
		TarArchiveEntry nextEntry = tais.getNextTarEntry();
		while(nextEntry != null) {
			if (nextEntry.getName().equals("cfstats")) {
				extractFileContents(tais);
			}
			nextEntry = tais.getNextTarEntry();
		}
	}*/
	
	private static void extractGZip(InputStream is) throws Exception {
		TarArchiveInputStream tais = new TarArchiveInputStream(new GZIPInputStream(is));
		TarArchiveEntry nextEntry = tais.getNextTarEntry();
		while(nextEntry != null) {
			
				if(nextEntry.getName().endsWith(".zip") && nextEntry.getName().contains("debug")) {
					extractZip(tais);
				} else if (nextEntry.getName().endsWith(".gz")) {
					extractGZip(tais);
				} else if(!nextEntry.getName().endsWith("/") && nextEntry.getName().contains("debug")) {
					extractFileContents(tais);
				}
			
			nextEntry = tais.getNextTarEntry();
		}
	}
	
	private static void extractFileContents(InputStream inputStream) throws IOException, Exception{

		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		
		for(String line : collector){
			System.out.println(line);
		}
	}
}
