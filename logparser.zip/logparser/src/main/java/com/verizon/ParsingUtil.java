package com.verizon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.util.StringUtils;

import com.verizon.constants.Constants;
import com.verizon.dto.GenerateReportRequest;
import com.verizon.dto.GenerateReportResponse;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;
import com.verizon.util.PDFGeneratorUtil;

public class ParsingUtil {

	private static Set<String> threadList;
	private static List<Log> logList;
	private static Date currentDate;
	private static String className = null;
	private static List<String> threadNameList = null;
	private static String threadName = null;
	private static int noOfTimesPrinted = 0;
	private static long timeInMilliSeconds = 3600000;
	
	public static ParseResponse parseLogFile(ParseRequest request) throws IOException {
		threadList = new HashSet<>();
		logList = new ArrayList<Log>();
		currentDate = new Date();
		className = request.getClassName();
		timeInMilliSeconds = 3600000;
		if(!StringUtils.isEmpty(request.getLastTimeInHours())) {
			timeInMilliSeconds =(long)(timeInMilliSeconds * Double.parseDouble(request.getLastTimeInHours()));
		}
		noOfTimesPrinted = 0;
		fileReader(Constants.FILE_PATH);
		ParseResponse response = new ParseResponse(Constants.SUCCESS, "Successfully executed");
		response.setNoOfTimesPrinted(noOfTimesPrinted);
		response.setThreads(threadList);
		response.setThreadCount(threadList.size());
		if("GCInspector.java".equals(className) && logList != null && !logList.isEmpty()) {
			Collections.sort(logList, new Comparator<Log>() {
			    @Override
			    public int compare(Log log1, Log log2) {
			        // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
			    	if(log1.getTimeInMilliSeconds() != null && log2.getTimeInMilliSeconds() != null) {
			    		return log1.getTimeInMilliSeconds() > log2.getTimeInMilliSeconds() ? -1 : (log1.getTimeInMilliSeconds() < log2.getTimeInMilliSeconds()) ? 1 : 0;
			    	} else {
			    		return 0;
			    	}
			    }
			});
			printToFile(logList);
			response.setMax(getTopMaximumFive(logList));
			response.setMin(getTopMinimumFive(logList));
			PDFGeneratorUtil.generateReport(response);
		}
		return response;
	}
	
	public static GenerateReportResponse parseLogFile(GenerateReportRequest request) throws IOException{
		
		currentDate = new Date();
		threadNameList = request.getThreadList();
		timeInMilliSeconds = 3600000;
		if(!StringUtils.isEmpty(request.getTimeDuration())) {
			timeInMilliSeconds = findCutoffTime(request.getTimeDuration());
		}
		for(String tname : threadNameList){
			threadName = tname;
			fileReader(Constants.FILE_PATH);
		}
		return null;
	}

	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			Date date = format.parse(timeStamp);
			long timeDifferenceInMilliSeconds = currentDate.getTime() - date.getTime();
			if(timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
				return true;
			}
		} catch (ParseException e) {
			
		}
		return false;
	}

	private static List<Log> getTopMinimumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for(int i = logList.size() -  1; i >= 0 && count < 5 ; i--, count++ ) {
			list.add(logList.get(i));
		}
		return list;
	}

	private static List<Log> getTopMaximumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for (Log log : logList) {
			count++;
			list.add(log);
			if(count == 5) break;
		}
		return list;
	}
	
	private static void printToFile(List<Log> logList) throws IOException {
		// print in to a file >= 250ms in a meaning ful format
		BufferedWriter writer = new BufferedWriter(new FileWriter(Constants.OUTPUT_FILE_PATH + "\\OutputGcInspector_" +(new Date()).getTime() +".txt"));
		for(Log log : logList) {
			writer.write(log.getLogType() + "\t" + log.getDescription() + "\n");
		}
		writer.close();
	}

	public static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if(log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if(timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			return log;
		}
		return null;
	}

	public static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);
		
	}

	public static void fileReader(File file) throws FileNotFoundException, IOException {
		if(file.isDirectory()) {
			File[] files = file.listFiles();
			for(File f: files) {
				fileReader(f);
			}
		} else if(file.getName().endsWith(".zip")) {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(file.getName(), fileInputStream);
			fileInputStream.close();
		}
	}
	
	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (entry.getName().endsWith(".zip")) {
				extractZip(zipInputStream);
			} else {
				extractFileContents(entry.getName(), zipInputStream);
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	private static void extractFileContents(String fileName, InputStream inputStream) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		String line = null;
		System.out.println(fileName + "*******************");
		while ((line = br.readLine()) != null) {
			if(!StringUtils.isEmpty(className) && line.contains(className)) {
				Log log = extractLog(line);
				if (log != null && isLogConsideredForProcessing(log, currentDate)) {
					noOfTimesPrinted++;
					threadList.add(log.getThreadName());
					if (log.getClassName().equalsIgnoreCase("GCInspector.java")) {
						if(log.getTimeInMilliSeconds() != null && log.getTimeInMilliSeconds() > Constants.THRESHOLD_IN_MILLISECONDS) {
							logList.add(log);
						}
					}
				}
			} else{
					if(line.contains(threadName)) {
						Log log = extractLog(line);
						if (log != null && isLogConsideredForProcessing(log, currentDate)) {
							logList.add(log);
						}
					}
			}
		}
	}
	
	private static long findCutoffTime(String timeDuration){
		
		String[] duration = timeDuration.split("[d:m:s]+");
		if(duration.length > 0){
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, Integer.parseInt(duration[0])*-1);
			cal.add(Calendar.HOUR, Integer.parseInt(duration[1])*-1);
			cal.add(Calendar.MINUTE, Integer.parseInt(duration[2])*-1);
			Date  date = cal.getTime();
			Date currentDate = new Date();
			return currentDate.getTime()-date.getTime();
		} else{
			return timeInMilliSeconds;
		}
		
		
	}

}
