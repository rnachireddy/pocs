package com.verizon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.util.StringUtils;

import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;
import com.verizon.util.BubbleChartGenerator;
import com.verizon.util.PDFGeneratorUtil;

public class ParsingUtil {

	private static Set<String> threadsExecutedGCInspector;
	private static Map<String, List<Log>> logMap;
	private static List<Log> logListForCount;
	private static List<String> allowedThreadNames;
	private static List<Log> gcInspectorLogsWhichCrossedThreshold;
	private static List<Log> logList;
	private static Date currentDate;
	private static int countOfGCInspector = 0;
	private static long timeInMilliSeconds;
	private static long thresholdTimeInMilliSeconds;
	
	public static ParseResponse parseLogFile(ParseRequest request) throws IOException, ParseException {
		logList = new ArrayList<>();
		logListForCount = new ArrayList<>();
		logMap = new HashMap<>();
		threadsExecutedGCInspector = new HashSet<>();
		gcInspectorLogsWhichCrossedThreshold = new ArrayList<Log>();
		currentDate = new Date();
		countOfGCInspector = 0;
		timeInMilliSeconds = getTimeInMillisecondsFromRequest(request);
		allowedThreadNames = getThreadNamesFromRequest(request);
		thresholdTimeInMilliSeconds = getThresholdTimeFromRequest(request);
		fileReader(Constants.FILE_PATH);
		ParseResponse response = new ParseResponse(Constants.SUCCESS, "Successfully executed");
		response.setCountOfGCInspector(countOfGCInspector);
		response.setThreadsExecutedGCInspector(threadsExecutedGCInspector);
		if(gcInspectorLogsWhichCrossedThreshold != null && !gcInspectorLogsWhichCrossedThreshold.isEmpty()) {
			Collections.sort(gcInspectorLogsWhichCrossedThreshold, new Comparator<Log>() {
			    @Override
			    public int compare(Log log1, Log log2) {
			        // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
			    	if(log1.getTimeInMilliSeconds() != null && log2.getTimeInMilliSeconds() != null) {
			    		return log1.getTimeInMilliSeconds() > log2.getTimeInMilliSeconds() ? -1 : (log1.getTimeInMilliSeconds() < log2.getTimeInMilliSeconds()) ? 1 : 0;
			    	} else {
			    		return 0;
			    	}
			    }
			});
			printToFile(gcInspectorLogsWhichCrossedThreshold);
			response.setTopMaximumFiveGCInspectorThreads(getTopMaximumFive(gcInspectorLogsWhichCrossedThreshold));
			response.setTopMinimumFiveGCInspectorThreads(getTopMinimumFive(gcInspectorLogsWhichCrossedThreshold));
			
		}
		logMap = processMap(logList);
		processAndSetMinAndMaxMemoryUsed(response, logList);
		processAndSetMinAndMaxFlushTimeStamp(response);
		PDFGeneratorUtil.generateReport(response, logMap, logListForCount);
		BubbleChartGenerator.generateChart(response, logList);
		return response;
	}

	private static void processAndSetMinAndMaxMemoryUsed(ParseResponse response, List<Log> logList) {
		Double min = null, max = null;
		if (logList != null && !logList.isEmpty()) {
			List<Log> collect = logList.stream().filter(log -> {
				return (log.getThreadName().equals(Constants.THREADNAME_COMMITLOGALLOCATOR)
						|| log.getThreadName().equals(Constants.THREADNAME_SLABPOOLCLEANER)
						|| log.getThreadName().equals(Constants.THREADNAME_SCHEDULEDTASKS))
						&& log.getMemoryUsed() != null;
			}).collect(Collectors.toList());
			if (!collect.isEmpty()) {
				Collections.sort(collect, new Comparator<Log>() {
					@Override
					public int compare(Log log1, Log log2) {
						if (log1 == null || log2 == null)
							return 0;
						return log1.getMemoryUsed().compareTo(log2.getMemoryUsed());
					}

				});
				min = collect.get(0).getMemoryUsed();
				max = collect.get(collect.size()- 1).getMemoryUsed();
			}
		}
		response.setMaximumMemoryUsed(max);
		response.setMinimumMemoryUsed(min);
	}
	
	private static void processAndSetMinAndMaxFlushTimeStamp(ParseResponse response){
		long diffMilliSeconds = new Date().getTime() - timeInMilliSeconds;
		response.setMinFlushTimeStamp(new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT).format(new Date(diffMilliSeconds)));
		response.setMaxFlushTimeStamp(new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT).format(new Date()));
	}

	private static long getThresholdTimeFromRequest(ParseRequest request) {
		long threshold = Constants.DEFAULT_THRESHOLD_IN_MILLISECONDS;
		if(!StringUtils.isEmpty(request.getThresholdInMilliSeconds())) {
			threshold = Long.parseLong(request.getThresholdInMilliSeconds());
		}
		return threshold;
	}

	private static List<String> getThreadNamesFromRequest(ParseRequest request) {
		if(request.getThreadNames() == null || request.getThreadNames().isEmpty()) {
			return Constants.DEFAULT_THREAD_NAMES;
		}
		return request.getThreadNames();
	}

	private static long getTimeInMillisecondsFromRequest(ParseRequest request) {
		long time = 0;
		if (!StringUtils.isEmpty(request.getHours())) {
			time = (long) (Constants.ONE_HOUR_IN_MILLISECONDS * Double.parseDouble(request.getHours()));
		}
		if (!StringUtils.isEmpty(request.getMinutes())) {
			time = time + (long) (Constants.ONE_MINUTE_IN_MILLISECONDS * Double.parseDouble(request.getMinutes()));
		}
		if (time == 0) {
			time = Constants.ONE_HOUR_IN_MILLISECONDS;
		}
		return time;
	}

	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		try {
			Date date = format.parse(timeStamp);
			long timeDifferenceInMilliSeconds = currentDate.getTime() - date.getTime();
			if(timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
				return true;
			}
		} catch (ParseException e) {
			
		}
		return false;
	}

	private static List<Log> getTopMinimumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for(int i = logList.size() -  1; i >= 0 && count < 5 ; i--, count++ ) {
			list.add(logList.get(i));
		}
		return list;
	}

	private static List<Log> getTopMaximumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for (Log log : logList) {
			count++;
			list.add(log);
			if(count == 5) break;
		}
		return list;
	}
	
	private static void printToFile(List<Log> logList) throws IOException {
		// print in to a file >= 250ms in a meaning ful format
		BufferedWriter writer = new BufferedWriter(new FileWriter(Constants.OUTPUT_FILE_PATH + "\\OutputGcInspector_" +(new Date()).getTime() +".txt"));
		for(Log log : logList) {
			writer.write(log.getLogType() + "\t" + log.getDescription() + "\n");
		}
		writer.close();
	}

	public static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if(log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if(timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			if(log.getThreadName().equals(Constants.THREADNAME_SCHEDULEDTASKS)
					|| log.getThreadName().equals(Constants.THREADNAME_SLABPOOLCLEANER)
					|| log.getThreadName().equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				Integer memoryUsed = extractMemoryFromDescription(log.getDescription());
				if(memoryUsed != null) {
					log.setMemoryUsed(Double.parseDouble(new DecimalFormat("##.####").format(memoryUsed.doubleValue() / (1024*1024*1024))));
				}
			}
			return log;
		}
		return null;
	}

	private static Integer extractMemoryFromDescription(String description) {
		Pattern p = Pattern.compile("^(.*: )(\\d*)( \\(.*)*$");
		Matcher m = p.matcher(description);
		if(m.find()) {
			return Integer.parseInt(m.group(2));
		}
		return null;
	}

	public static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);
		
	}

	public static void fileReader(File file) throws FileNotFoundException, IOException {
		if(file.isDirectory()) {
			File[] files = file.listFiles();
			for(File f: files) {
				fileReader(f);
			}
		} else if(file.getName().endsWith(".zip")) {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(file.getName(), fileInputStream);
			fileInputStream.close();
		}
	}
	
	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if (entry.getName().endsWith(".zip")) {
				extractZip(zipInputStream);
			} else {
				extractFileContents(entry.getName(), zipInputStream);
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	private static void extractFileContents(String fileName, InputStream inputStream) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		for (int i = collector.size() - 1; i > 0; i--) {
			String line = collector.get(i);
			Log log = extractLog(line);
			if (log == null) {
				continue;
			} else if (isLogConsideredForProcessing(log, currentDate)) {
				break;
			} else {
				return;
			}
		}
		for (String line : collector) {
			Log log = extractLog(line);
			if (log != null && isLogConsideredForProcessing(log, currentDate)) {
				if ("GCInspector.java".equals(log.getClassName())) {
					countOfGCInspector++;
					threadsExecutedGCInspector.add(log.getThreadName());
					if (log.getTimeInMilliSeconds() != null
							&& log.getTimeInMilliSeconds() >= thresholdTimeInMilliSeconds) {
						gcInspectorLogsWhichCrossedThreshold.add(log);
					}
				}
				if (allowedThreadNames.contains(log.getThreadName())) {
					logList.add(log);
				}
				logListForCount.add(log);
			}
		}
	}

	private static Map<String, List<Log>>processMap(List<Log> logs) {
		Map<String, List<Log>> map = new HashMap<>();
		for(String threadName : allowedThreadNames) {
			List<Log> list = logs.stream().filter(log -> {
				return threadName.equals(log.getThreadName());
			}).collect(Collectors.toList());
			map.put(threadName, list);
		}
		return map;
	}
}
