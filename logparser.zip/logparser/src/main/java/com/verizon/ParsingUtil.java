package com.verizon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FilenameUtils;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;
import com.verizon.itext.HeaderFooter;
import com.verizon.itext.PDFCreator;
import com.verizon.logparser.model.Log;

public class ParsingUtil {
	
	public static final byte[] buffer = new byte[1024];

	public static ParseResponse parseLogFile(String className) throws IOException {
		Set<String> threadList = new HashSet<>();
		List<Log> logList = new ArrayList<Log>();
		Date currentDate = new Date();
		ParseResponse response = null;
		BufferedReader br = null;
		if(!extractFiles(Constants.SRC_DIR).equalsIgnoreCase("done")){
			response = new ParseResponse(Constants.FAILURE, "Error while extracting the files.");
		}
		File srcDir = new File(Constants.EXTRACT_DIR);
		int noOfTimesPrinted = 0;
		for(File filePath : srcDir.listFiles()){
			if(isFileConsideredForProcessing(filePath.getName(), currentDate)){
				br = new BufferedReader(new FileReader(filePath));
				String line = null;
				while ((line = br.readLine()) != null) {
					if(line.contains(className)) {
						Log log = extractLog(line);
						if (log != null && isLogConsideredForProcessing(log, currentDate)) {
							noOfTimesPrinted++;
							threadList.add(log.getThreadName());
							if (log.getClassName().equalsIgnoreCase("GCInspector.java")) {
								if(log.getTimeInMilliSeconds() != null && log.getTimeInMilliSeconds() > Constants.THRESHOLD_IN_MILLISECONDS) {
									logList.add(log);
								}
							}
						}
					}
				}
			}
		}
		
		br.close();
		response = new ParseResponse(Constants.SUCCESS, "Successfully executed");
		response.setNoOfTimesPrinted(noOfTimesPrinted);
		response.setThreads(threadList);
		response.setThreadCount(threadList.size());
		if("GCInspector.java".equals(className) && logList != null && !logList.isEmpty()) {
			Collections.sort(logList, new Comparator<Log>() {
			    @Override
			    public int compare(Log log1, Log log2) {
			        // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
			    	if(log1.getTimeInMilliSeconds() != null && log2.getTimeInMilliSeconds() != null) {
			    		return log1.getTimeInMilliSeconds() > log2.getTimeInMilliSeconds() ? -1 : (log1.getTimeInMilliSeconds() < log2.getTimeInMilliSeconds()) ? 1 : 0;
			    	} else {
			    		return 0;
			    	}
			    }
			});
			printToFile(logList);
			response.setMaxCrossedThreshold(getTopFive(logList));
			response.setMinCrossedThreshold(getLastFive(logList));
			System.out.println("Starting report generation");
			String result = generateLogReport(response);
			System.out.println("Report generated "+result);
		}
		return response;
	}
	
	private static String extractFiles(String directoryPath) throws IOException{
		File srcDir = new File(directoryPath);
		for(File filePath : srcDir.listFiles()){
			if(filePath.isFile()){
				String contentType = getContentType(filePath.getName());
				System.out.println("Content Type :: "+contentType);
				if(contentType.equalsIgnoreCase("ZIP")){
					FileInputStream	fis = new FileInputStream(filePath);
					ZipInputStream	zis = new ZipInputStream(fis);
					FileOutputStream fos = null;
					ZipEntry ze = zis.getNextEntry();
					while (ze != null) {
						String fileName = ze.getName();
						File newFile = new File(Constants.EXTRACT_DIR + File.separator + fileName);
						System.out.println("Unzipping to " + newFile.getAbsolutePath());
						fos = new FileOutputStream(newFile);
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						fos.close();
						zis.closeEntry();
						ze = zis.getNextEntry();
					}
					zis.close();
					fis.close();
				} else{
					FileInputStream fis = new FileInputStream(filePath);
					String fileName = filePath.getName();
					File newFile = new File(Constants.EXTRACT_DIR + File.separator + fileName);
					System.out.println("Writing file to " + newFile.getAbsolutePath());
					FileOutputStream fos = new FileOutputStream(newFile);
					int len;
					while ((len = fis.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					}
					fos.close();
					fis.close();
				}
			}
        }
	return "done";
	}
	
	public static String getContentType(String fileName){
    	return FilenameUtils.getExtension(fileName);
	}

	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			Date date = format.parse(timeStamp);
			if((currentDate.getTime() - date.getTime()) <= 3600000) {
				return true;
			}
		} catch (ParseException e) {
			
		}
		return false;
	}
	
	private static boolean isFileConsideredForProcessing(String fileName, Date currentDate) {
		System.out.println("isFileConsideredForProcessing ::"+fileName);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd_HHmm");
		String fileTimeStamp = null;
		try {
			Pattern p = Pattern.compile("(.*\\.)(.*\\.)(.*)$"); 
			Matcher m = p.matcher(fileName);
			if (m.find()) {
				fileTimeStamp = (m.group(3).trim());
			} else{
				System.out.println("current debug file");
				return true;
			}
			Date date = format.parse(fileTimeStamp);
			if((currentDate.getTime() - date.getTime()) <= 3600000) {
				return true;
			}
		} catch (ParseException e) {
			
		}
		return false;
	}

	private static List<String> getTopFive(List<Log> logList) {
		List<String> list = new ArrayList<>();
		int count = 0;
		for (Log log : logList) {
			count++;
			list.add(log.getLogType() + "\t" + log.getTimeStamp() + "\t" + log.getDescription() + "\n");
			if(count == 5) break;
		}
		return list;
	}
	
	private static List<String> getLastFive(List<Log> logList) {
		Collections.reverse(logList);
		List<String> list = new ArrayList<>();
		int count = 0;
		for (Log log : logList) {
			count++;
			list.add(log.getLogType() + "\t" + log.getTimeStamp() + "\t" + log.getDescription() + "\n");
			if(count == 5) break;
		}
		return list;
	}

	private static void printToFile(List<Log> logList) throws IOException {
		// print in to a file >= 250ms in a meaning ful format
		File file = new File(Constants.DEST_DIR+"output_gcinspector");
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		for(Log log : logList) {
			writer.write(log.getLogType() + "\t" + log.getTimeStamp() + "\t" + log.getDescription() + "\n");
		}
		writer.close();
	}

	public static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if(log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if(timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			return log;
		}
		return null;
	}
	
	private static String generateLogReport(ParseResponse response){
		Document document = null;
		try{
			document = new Document(PageSize.A4);            
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(new File(Constants.DEST_DIR +"cassendraLogReports"+ Constants.PDF_EXTENSION)));
			HeaderFooter event = new HeaderFooter();
	        event.setHeader("Cassendra Log Detailed Summary");
	        writer.setPageEvent(event);
	        document.open();
	        PDFCreator.addContent(document, response);
		}catch (DocumentException | FileNotFoundException e) {
			System.out.println("FileNotFoundException occurs.." + e.getMessage());
		}finally{
			if(null != document){
				document.close();
			}
		}
	return "success";
	}

}
