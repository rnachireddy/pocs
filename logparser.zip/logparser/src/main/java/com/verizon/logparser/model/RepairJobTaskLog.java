package com.verizon.logparser.model;

public class RepairJobTaskLog {
	
	private String tableName;
	private String key;
	
	public RepairJobTaskLog(){
		
	}
	public RepairJobTaskLog(String tableName, String key){
		this.tableName = tableName;
		this.key = key;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}

}
