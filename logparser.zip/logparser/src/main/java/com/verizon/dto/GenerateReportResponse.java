package com.verizon.dto;

import java.util.List;

public class GenerateReportResponse {
	
	private String status;
	private long totalFlush;
	private String message;
	private List<ThreadInformation> threadinfo;
	
	public GenerateReportResponse(String status, String message) {
		this.status = status;
		this.message = message;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public long getTotalFlush() {
		return totalFlush;
	}
	public void setTotalFlush(long totalFlush) {
		this.totalFlush = totalFlush;
	}
	public List<ThreadInformation> getThreadinfo() {
		return threadinfo;
	}
	public void setThreadinfo(List<ThreadInformation> threadinfo) {
		this.threadinfo = threadinfo;
	}
	
	

}
