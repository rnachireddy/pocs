package com.verizon.dto;

import java.util.Map;
import java.util.Set;

public class RepairJobTaskResponse {

	private String threadName;
	private Map<String, Set<String>> keys;
	private long totalCount;
	
	public RepairJobTaskResponse(String threadName){
		this.threadName = threadName;
		this.totalCount = 0;
	}
	public RepairJobTaskResponse(){
		
	}
	public String getThreadName() {
		return threadName;
	}
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}
	public Map<String, Set<String>> getKeys() {
		return keys;
	}
	public void setKeys(Map<String, Set<String>> keys) {
		this.keys = keys;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
}
