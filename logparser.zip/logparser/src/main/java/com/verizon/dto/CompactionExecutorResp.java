package com.verizon.dto;

import java.util.Set;

public class CompactionExecutorResp {
	
	private String threadName;
	private long totalCount;
	private long partitionCount;
	private Set<String> tableNames;
	
	public CompactionExecutorResp(String threadName){
		this.threadName = threadName;
		this.totalCount = 0;
		this.partitionCount = 0;
	}
	public CompactionExecutorResp(){
		
	}
	public String getThreadName() {
		return threadName;
	}
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
	public long getPartitionCount() {
		return partitionCount;
	}
	public void setPartitionCount(long partitionCount) {
		this.partitionCount = partitionCount;
	}
	public Set<String> getTableNames() {
		return tableNames;
	}
	public void setTableNames(Set<String> tableNames) {
		this.tableNames = tableNames;
	}

}
