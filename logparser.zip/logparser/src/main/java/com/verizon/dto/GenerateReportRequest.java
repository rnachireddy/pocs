package com.verizon.dto;

import java.util.List;

public class GenerateReportRequest {
	
	private String timeDuration;
	private List<String> threadList;
	
	public String getTimeDuration() {
		return timeDuration;
	}
	public void setTimeDuration(String timeDuration) {
		this.timeDuration = timeDuration;
	}
	public List<String> getThreadList() {
		return threadList;
	}
	public void setThreadList(List<String> threadList) {
		this.threadList = threadList;
	}
	
	

}
