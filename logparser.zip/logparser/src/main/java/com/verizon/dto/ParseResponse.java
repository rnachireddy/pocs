package com.verizon.dto;

import java.util.List;
import java.util.Set;

import com.verizon.logparser.model.Log;

public class ParseResponse {

	private String status;
	private String message;
	private int threadCount;
	private Set<String> threads;
	private int noOfTimesPrinted;
	private List<Log> max;
	private List<Log> min;

	public ParseResponse(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public ParseResponse() {
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(int threadCount) {
		this.threadCount = threadCount;
	}

	public Set<String> getThreads() {
		return threads;
	}

	public void setThreads(Set<String> threads) {
		this.threads = threads;
	}

	public int getNoOfTimesPrinted() {
		return noOfTimesPrinted;
	}

	public void setNoOfTimesPrinted(int noOfTimesPrinted) {
		this.noOfTimesPrinted = noOfTimesPrinted;
	}

	public List<Log> getMax() {
		return max;
	}

	public void setMax(List<Log> max) {
		this.max = max;
	}

	public List<Log> getMin() {
		return min;
	}

	public void setMin(List<Log> min) {
		this.min = min;
	}

}
