package com.verizon.dto;

import java.util.List;
import java.util.Set;

public class ParseResponse {

	private String status;
	private String message;
	private int threadCount;
	private Set<String> threads;
	private int noOfTimesPrinted;
	private List<String> crossedThreshold;

	public ParseResponse(String status, String message) {
		this.status = status;
		this.message = message;
	}

	public ParseResponse() {
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(int threadCount) {
		this.threadCount = threadCount;
	}

	public Set<String> getThreads() {
		return threads;
	}

	public void setThreads(Set<String> threads) {
		this.threads = threads;
	}

	public int getNoOfTimesPrinted() {
		return noOfTimesPrinted;
	}

	public void setNoOfTimesPrinted(int noOfTimesPrinted) {
		this.noOfTimesPrinted = noOfTimesPrinted;
	}

	public List<String> getCrossedThreshold() {
		return crossedThreshold;
	}

	public void setCrossedThreshold(List<String> crossedThreshold) {
		this.crossedThreshold = crossedThreshold;
	}

}
