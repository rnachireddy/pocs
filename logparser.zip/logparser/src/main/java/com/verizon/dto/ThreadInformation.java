package com.verizon.dto;

public class ThreadInformation {

	private String threadName;
	private String warnCount;
	private String errorCount;
	private String enqueCount;
	
	public String getThreadName() {
		return threadName;
	}
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}
	public String getWarnCount() {
		return warnCount;
	}
	public void setWarnCount(String warnCount) {
		this.warnCount = warnCount;
	}
	public String getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}
	public String getEnqueCount() {
		return enqueCount;
	}
	public void setEnqueCount(String enqueCount) {
		this.enqueCount = enqueCount;
	}
	
	
}
