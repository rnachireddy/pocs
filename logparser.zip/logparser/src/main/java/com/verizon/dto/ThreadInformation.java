package com.verizon.dto;

public class ThreadInformation {
	
	private String threadName;
	private long enqueingCnt;
	private long warnCount;
	private long errorCount;
	
	public ThreadInformation(String threaName){
		this.warnCount = 0;
		this.errorCount = 0;
		this.enqueingCnt = 0;
		this.threadName = threaName;
		
	}
	public ThreadInformation(){
		
	}
	public String getThreadName() {
		return threadName;
	}
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}
	public long getEnqueingCnt() {
		return enqueingCnt;
	}
	public void setEnqueingCnt(long enqueingCnt) {
		this.enqueingCnt = enqueingCnt;
	}
	public long getWarnCount() {
		return warnCount;
	}
	public void setWarnCount(long warnCount) {
		this.warnCount = warnCount;
	}
	public long getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(long errorCount) {
		this.errorCount = errorCount;
	}
	
	
	

}
