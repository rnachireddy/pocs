package com.verizon.dto;

import java.util.List;

public class ParserResponse {
	
	private String status;
	private String message;
	private String totalWarnCount;
	private String totalErrorCount;
	private String totalGCCount;
	private String totalFlushCount;
	private GcLogInformation gcLogResponse;
	private List<ThreadInformation> threadInformationList;
	
	
	public ParserResponse(String status, String message) {
		this.status = status;
		this.message = message;
	}
	
	public ParserResponse() {
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTotalWarnCount() {
		return totalWarnCount;
	}

	public void setTotalWarnCount(String totalWarnCount) {
		this.totalWarnCount = totalWarnCount;
	}

	public String getTotalErrorCount() {
		return totalErrorCount;
	}

	public void setTotalErrorCount(String totalErrorCount) {
		this.totalErrorCount = totalErrorCount;
	}

	public String getTotalGCCount() {
		return totalGCCount;
	}

	public void setTotalGCCount(String totalGCCount) {
		this.totalGCCount = totalGCCount;
	}

	public String getTotalFlushCount() {
		return totalFlushCount;
	}

	public void setTotalFlushCount(String totalFlushCount) {
		this.totalFlushCount = totalFlushCount;
	}

	public GcLogInformation getGcLogResponse() {
		return gcLogResponse;
	}

	public void setGcLogResponse(GcLogInformation gcLogResponse) {
		this.gcLogResponse = gcLogResponse;
	}

	public List<ThreadInformation> getThreadInformationList() {
		return threadInformationList;
	}

	public void setThreadInformationList(
			List<ThreadInformation> threadInformationList) {
		this.threadInformationList = threadInformationList;
	}

	

}
