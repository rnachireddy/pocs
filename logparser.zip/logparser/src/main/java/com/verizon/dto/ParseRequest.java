package com.verizon.dto;

public class ParseRequest {

	private String logAccessBreakPoint;

	public String getLogAccessBreakPoint() {
		return logAccessBreakPoint;
	}

	public void setLogAccessBreakPoint(String logAccessBreakPoint) {
		this.logAccessBreakPoint = logAccessBreakPoint;
	}

	

}
