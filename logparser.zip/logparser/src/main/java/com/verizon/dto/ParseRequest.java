package com.verizon.dto;

public class ParseRequest {

	private String className;
	private String threadName;
	private String lastTimeInHours;

	public ParseRequest(String className, String threadName) {
		this.className = className;
		this.threadName = threadName;
	}

	public ParseRequest() {
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	public String getLastTimeInHours() {
		return lastTimeInHours;
	}

	public void setLastTimeInHours(String lastTimeInHours) {
		this.lastTimeInHours = lastTimeInHours;
	}

}
