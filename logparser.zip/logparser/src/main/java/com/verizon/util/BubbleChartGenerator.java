package com.verizon.util;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;

import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;

public class BubbleChartGenerator {

	public static void generateChart(ParseResponse response, List<Log> logList) throws IOException, ParseException {
		XYZDataset dataset = createDataset(logList, Constants.THREADNAME_SLABPOOLCLEANER);
		JFreeChart jfreechart = ChartFactory.createBubbleChart(Constants.THREADNAME_SLABPOOLCLEANER, "TimeStamp",
				"Memory", dataset, PlotOrientation.VERTICAL, true, true, false);
		saveChartAsJpeg(jfreechart, Constants.THREADNAME_SLABPOOLCLEANER);

		dataset = createDataset(logList, Constants.THREADNAME_COMMITLOGALLOCATOR);
		jfreechart = ChartFactory.createBubbleChart(Constants.THREADNAME_COMMITLOGALLOCATOR, "TimeStamp", "Memory",
				dataset, PlotOrientation.VERTICAL, true, true, false);
		saveChartAsJpeg(jfreechart, Constants.THREADNAME_COMMITLOGALLOCATOR);

		dataset = createDataset(logList, Constants.THREADNAME_SCHEDULEDTASKS);
		jfreechart = ChartFactory.createBubbleChart(Constants.THREADNAME_SCHEDULEDTASKS, "TimeStamp", "Memory", dataset,
				PlotOrientation.VERTICAL, true, true, false);
		saveChartAsJpeg(jfreechart, Constants.THREADNAME_SCHEDULEDTASKS);
	}

	private static void saveChartAsJpeg(JFreeChart jfreechart, String threadName) throws IOException {
		// Set range for X-Axis
		XYPlot plot = jfreechart.getXYPlot();
		XYItemRenderer xyitemrenderer = plot.getRenderer();
		if(threadName.equals(Constants.THREADNAME_SLABPOOLCLEANER)) {
			xyitemrenderer.setSeriesPaint(0, Color.blue);
		} else if (threadName.equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
			xyitemrenderer.setSeriesPaint(0, Color.red);
		} else {
			xyitemrenderer.setSeriesPaint(0, Color.green);
		}
			
		/*xyitemrenderer.setSeriesPaint(0, Color.blue);
		xyitemrenderer.setSeriesPaint(1, Color.red);
		xyitemrenderer.setSeriesPaint(2, Color.green);*/
		plot.setForegroundAlpha(0.65F);
		plot.setDomainAxis(new DateAxis("TimeStamp"));
		DateAxis domain = (DateAxis) plot.getDomainAxis();
		domain.setLowerMargin(0.2);
		domain.setUpperMargin(0.5);
		final DateFormat dateFormat = new SimpleDateFormat("MM-dd HH:mm");
		domain.setDateFormatOverride(dateFormat);
		
		// Set range for Y-Axis
		NumberAxis range = (NumberAxis) plot.getRangeAxis();
		range.setLowerMargin(0.8);
		range.setUpperMargin(0.9);

		int width = 560; /* Width of the image */
		int height = 370; /* Height of the image */
		File bubbleChart = new File(threadName + "_graph.jpeg");
		ChartUtilities.saveChartAsJPEG(bubbleChart, jfreechart, width, height);
	}

	private static XYZDataset createDataset(List<Log> logList, String threadName) throws ParseException {

		DefaultXYZDataset dataset = new DefaultXYZDataset();
		if (threadName.equals(Constants.THREADNAME_SLABPOOLCLEANER)) {
			dataset.addSeries(Constants.THREADNAME_SLABPOOLCLEANER,
					getGraphCoordinateValues(Constants.THREADNAME_SLABPOOLCLEANER, logList));
		} else if (threadName.equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
			dataset.addSeries(Constants.THREADNAME_COMMITLOGALLOCATOR,
					getGraphCoordinateValues(Constants.THREADNAME_COMMITLOGALLOCATOR, logList));
		} else if (threadName.equals(Constants.THREADNAME_SCHEDULEDTASKS)) {
			dataset.addSeries(Constants.THREADNAME_SCHEDULEDTASKS,
					getGraphCoordinateValues(Constants.THREADNAME_SCHEDULEDTASKS, logList));
		}
		return dataset;
	}

	private static double[][] getGraphCoordinateValues(String threadName, List<Log> logList) throws ParseException {

		List<Double> memoryList = new ArrayList<Double>();
		List<Double> timeStampList = new ArrayList<Double>();
		List<Double> countList = new ArrayList<Double>();

		for (Log log : logList) {
			if (log.getThreadName().equalsIgnoreCase(threadName)) {
				if (log.getMemoryUsed() != null) {
					memoryList.add(log.getMemoryUsed());
					timeStampList.add(parseTimeStamp(log.getTimeStamp()));
					countList.add(log.getMemoryUsed()/40);
/*					if(threadName.equals(Constants.THREADNAME_SLABPOOLCLEANER)) {
					} else {
						countList.add(log.getMemoryUsed()/10);
					}*/
					/*
					else if(threadName.equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
						countList.add(0.01);
					}else if(threadName.equals(Constants.THREADNAME_SCHEDULEDTASKS)) {
						countList.add(0.008);
					}*/
				}
			}
		}
		System.out.println("ThreadName ::" + threadName);
		System.out.println("memoryList Size::" + memoryList.size());
		System.out.println("timeStamp Size::" + timeStampList.size());
		System.out.println("CountList Size::" + countList.size());

		System.out.println(memoryList.toString());
		System.out.println(timeStampList.toString());
		System.out.println(countList.toString());
		double[][] seriesValues = { unWrapDouble(timeStampList), unWrapDouble(memoryList), unWrapDouble(countList) };
		return seriesValues;
	}

	private static double parseTimeStamp(String timeStamp) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		Date date = dateFormat.parse(timeStamp);
		return (double) date.getTime();
	}

	private static double[] unWrapDouble(List<Double> list) {
		Double[] doubleArray = list.toArray(new Double[list.size()]);
		double[] array = new double[doubleArray.length];
		for (int i = 0; i < doubleArray.length; i++) {
			if (doubleArray != null) {
				array[i] = doubleArray[i];
			}
		}
		return array;
	}

}
