package com.verizon.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;

public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);

	public static void main(String[] args) {
		generateReport(null);
	}

	public static void generateReport(ParseResponse response) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + "\\Report_" +(new Date()).getTime() +".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			document.open();
			addMetaData(document);
			document.add(createReportTable(response));
			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
		}
	}

	private static Paragraph createReportTable(ParseResponse response) throws DocumentException {
		Paragraph paragraph = new Paragraph();
		paragraph.setFont(NORMAL_FONT);
		paragraph.add(new Chunk("Report Table :- ", SMALL_BOLD));
		PdfPTable table = createTable();
		addHeaderInTable(table);
		createContent(table, response);
		paragraph.add(table);
		createAndAddSubject(paragraph, response);
		return paragraph;
	}

	public static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	private static void createContent(PdfPTable table, ParseResponse response) {
		if (response != null) {
			List<Log> max = response.getMax();
			List<Log> min = response.getMin();
			int size = maximum(max, min);
			PdfPCell cell = createCell(String.valueOf(response.getNoOfTimesPrinted()));
			cell.setRowspan(size);
			table.addCell(cell);
			for (int i = 0; i < size; i++) {
				if (max.size() > i) {
					table.addCell(createCell(String.valueOf(i + 1))); // add Serial No
					createLogDetails(table, max.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
				if (min.size() > i) {
					createLogDetails(table, min.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
			}
		}
	}

	private static void createLogDetails(PdfPTable table, Log log, int i) {
		table.addCell(createCell(log.getThreadName()));
		table.addCell(createCell(log.getTimeStamp()));
		table.addCell(createCell(String.valueOf(log.getTimeInMilliSeconds())));
	}

	private static int maximum(List<Log> max, List<Log> min) {
		int size = max != null ? max.size() : 0;
		size = min != null && min.size() > size ? min.size() : size;
		return size;
	}

	private static PdfPTable createTable() throws DocumentException {
		PdfPTable table = new PdfPTable(8); // 8 Columns
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 9f, 7f, 12f, 34f, 8f, 12f, 34f, 8f };
		table.setWidths(columnWidths);
		return table;
	}

	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}

	private static void addHeaderInTable(PdfPTable table) {
		String headerArray[] = { "Occurences", "S.No", "Thread Name", "Time Stamp for Max five GC", "Max GC",
				"Thread Name", "Time Stamp for Min five GC", "Min GC" };
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}
	
	private static void createAndAddSubject(Paragraph p, ParseResponse response) {
		Font font = new Font(Font.FontFamily.TIMES_ROMAN, 7, Font.NORMAL);
		p.add("Subject");
		com.itextpdf.text.List list = new com.itextpdf.text.List(true, false, 10);
		List<Log> max = response.getMax();
		List<Log> min = response.getMin();
		if(max != null) {
			for(Log log : max) {
				list.add(new ListItem(log.getDescription(), font));
			}
		}
		if(min != null) {
			for(Log log : min) {
				list.add(new ListItem(log.getDescription(), font));
			}
		}
        p.add(list);
    }
}
