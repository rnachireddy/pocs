package com.verizon.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.verizon.constants.Constants;
import com.verizon.dto.CompactionExecutorResp;
import com.verizon.dto.GcLogInformation;
import com.verizon.dto.ParserResponse;
import com.verizon.dto.RepairJobTaskResponse;
import com.verizon.dto.ThreadInformation;
import com.verizon.logparser.model.Log;


public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);
	public final static Font VERY_SMALL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.NORMAL);

	public static void main(String[] args) {
		generateReport(null);
	}

	public static void generateReport(ParserResponse response) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + "\\Report_" +(new Date()).getTime() +".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			HeaderFooter event = new HeaderFooter();
	        event.setHeader("Cassandra GC Log Detailed Summary");
	        writer.setPageEvent(event);
			document.open();
			addMetaData(document);
			
			Paragraph paragraph = createGcLogTable(response.getGcLogResponse());
			paragraph = createTotlaMetricsTable(paragraph,
					response.getTotalWarnCount(),
					response.getTotalErrorCount(), response.getTotalGCCount(),
					response.getTotalFlushCount());
			paragraph = createThreadCountTable(paragraph,
					response.getThreadInformationList());
			paragraph = createCompactExecutorTable(paragraph, response.getCxResponse());
			paragraph = createRepairJobTable(paragraph, response.getRjtResponse());
			document.add(paragraph);
			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
		}
	}

	private static Paragraph createGcLogTable(GcLogInformation response) throws DocumentException {
		Paragraph paragraph = new Paragraph();
		paragraph.setFont(NORMAL_FONT);
		paragraph.add(new Chunk("Report Table :- ", SMALL_BOLD));
		PdfPTable table = createTable();
		addHeaderInTable(table);
		createContent(table, response);
		paragraph.add(table);
		paragraph.add(createAndAddSubject(response));
		paragraph.add(Chunk.NEWLINE);
		return paragraph;
	}
	
	private static PdfPTable createTable() throws DocumentException {
		PdfPTable table = new PdfPTable(8); // 8 Columns
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 9f, 7f, 12f, 34f, 8f, 12f, 34f, 8f };
		table.setWidths(columnWidths);
		return table;
	}
	
	private static void addHeaderInTable(PdfPTable table) {
		String headerArray[] = { "Occurences", "S.No", "Thread Name", "Time Stamp for Max five GC", "Max GC",
				"Thread Name", "Time Stamp for Min five GC", "Min GC" };
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}
	
	private static void createContent(PdfPTable table, GcLogInformation response) {
		if (response != null) {
			List<Log> max = response.getMax();
			List<Log> min = response.getMin();
			int size = maximum(max, min);
			PdfPCell cell = createCell(String.valueOf(response.getNoOfTimesPrinted()));
			cell.setRowspan(size);
			table.addCell(cell);
			for (int i = 0; i < size; i++) {
				if (max.size() > i) {
					table.addCell(createCell(String.valueOf(i + 1))); // add Serial No
					createLogDetails(table, max.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
				if (min.size() > i) {
					createLogDetails(table, min.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
			}
		}
	}
	
	

	public static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}
	
	public static PdfPTable createThreadInformationTable() throws DocumentException{
		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 25f, 25f, 25f, 25f };
		table.setWidths(columnWidths);
		return table;
		
	}
	
	private static Paragraph createThreadCountTable(Paragraph paragraph, List<ThreadInformation> threadList) throws DocumentException {
		paragraph.setFont(NORMAL_FONT);
		PdfPTable table=null;
		
		for(ThreadInformation threadObject : threadList){
			table = createThreadInformationTable();
			addThreadInformationHeaders(table);
			table.addCell(createCell(threadObject.getThreadName()));
			table.addCell(createCell(String.valueOf(threadObject.getEnqueingCnt())));
			table.addCell(createCell(String.valueOf(threadObject.getWarnCount())));
			table.addCell(createCell(String.valueOf(threadObject.getErrorCount())));
			paragraph.add(table);
			paragraph.add(Chunk.NEWLINE);
		}
		return paragraph;
	}
	
	public static Paragraph createTotlaMetricsTable(Paragraph paragraph, String warnCount, String errorCount, String gcCount, String enqueCount) throws DocumentException{
		
	
		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 25f, 25f, 25f, 25f };
		table.setWidths(columnWidths);
		
		String headerArray[] = { "Total Count of Warnings", "Total Count of Errors", "Total Count of GC", "Total Count of Flush"};
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
		table.addCell(createCell(warnCount));
		table.addCell(createCell(errorCount));
		table.addCell(createCell(gcCount));
		table.addCell(createCell(enqueCount));
		
		paragraph.add(table);
		paragraph.add(Chunk.NEWLINE);
		return paragraph;
		
	}
	
	public static Paragraph createCompactExecutorTable(Paragraph paragraph, CompactionExecutorResp response) throws DocumentException{
		
		
		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 25f, 25f, 25f, 25f };
		table.setWidths(columnWidths);
		
		String headerArray[] = { "Thread Name", "Total Count", "Large Partitons Total Count", "Table Name"};
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
		
		int rowspan = response.getTableNames().size();
		table.addCell(createCell(response.getThreadName(),rowspan));
		table.addCell(createCell(String.valueOf(response.getTotalCount()),rowspan));
		table.addCell(createCell(String.valueOf(response.getPartitionCount()),rowspan));
		for(String tableName : response.getTableNames()){
			table.addCell(createCell(tableName));
		}
		
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(Chunk.NEWLINE);
		paragraph.add(table);
		paragraph.add(Chunk.NEWLINE);
		return paragraph;
		
	}
	
	public static Paragraph createRepairJobTable(Paragraph paragraph,
			RepairJobTaskResponse response) throws DocumentException {

		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 25f, 25f, 25f, 25f };
		table.setWidths(columnWidths);

		String headerArray[] = { "Thread Name", "Total Count", "Key",
				"Table Name" };
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);

		int rowspan = getTotalCount(response.getKeys());

		table.addCell(createCell(response.getThreadName(), rowspan));
		table.addCell(createCell(String.valueOf(response.getTotalCount()),
				rowspan));
		for (Map.Entry<String, Set<String>> entry : response.getKeys()
				.entrySet()) {

			String tableName = entry.getKey();
			Set<String> set = entry.getValue();
			int span = set.size();
			boolean flag = true;
			for (String key : set) {
				table.addCell(createCell(key));
				if(flag){
					table.addCell(createCell(tableName, span));
					flag=false;
				}
			}
		}
		paragraph.add(table);
		paragraph.add(Chunk.NEWLINE);
		return paragraph;

	}


	private static int getTotalCount(Map<String, Set<String>> hm) {
		int count = 0;
		for (Map.Entry<String, Set<String>> entry : hm.entrySet()) {
			Set<String> set = entry.getValue();
			count = count + set.size();
		}
		return count;
	}
	

	private static void createLogDetails(PdfPTable table, Log log, int i) {
		table.addCell(createCell(log.getThreadName()));
		table.addCell(createCell(log.getTimeStamp()));
		table.addCell(createCell(String.valueOf(log.getTimeInMilliSeconds())));
	}

	private static int maximum(List<Log> max, List<Log> min) {
		int size = max != null ? max.size() : 0;
		size = min != null && min.size() > size ? min.size() : size;
		return size;
	}

	
	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		return cell;
	}

	private static PdfPCell createCell(String str, int rowspan) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setRowspan(rowspan);
		
		return cell;
	}
	
	
	private static void addThreadInformationHeaders(PdfPTable table) {
		String headerArray[] = { "ThreadName", "Enquieng Count ", "Count of Warnings", "Count of Errors" };
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}
	
	
	
	private static Paragraph createAndAddSubject(GcLogInformation response) {
	       Font font = new Font(Font.FontFamily.COURIER, 8,
	                  Font.NORMAL);
	       Paragraph paragraph = new Paragraph();
	       paragraph.setFont(SMALL_BOLD);
	       paragraph.add("Summary:");
	       com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
	       List<Log> max = response.getMax();
			List<Log> min = response.getMin();
			if(min != null) {
				for(Log log : max){
					orderedList.add(new ListItem(log.getLogType() + "  " +log.getDescription(), font));
				}
			}
			if(max != null) {
				for(Log log : min){
					orderedList.add(new ListItem(log.getLogType() + "  " +log.getDescription(), font));
				}
			}
	       paragraph.add(orderedList);
	       return paragraph;
    }
	
	
}
