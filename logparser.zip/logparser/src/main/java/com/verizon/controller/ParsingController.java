package com.verizon.controller;

import java.io.IOException;

import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.ParsingUtil;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParserResponse;

@RestController
public class ParsingController {

	@CrossOrigin
	@PostMapping(path = "/parse/logfile")
	public ParserResponse parseLogFile(@RequestBody ParseRequest request) {
		ParserResponse response = null;
		try {
			
			if(StringUtils.isEmpty(request.getLogAccessBreakPoint()) || !ParsingUtil.checkInputFormat(request.getLogAccessBreakPoint())) {
				response = new ParserResponse(Constants.FAILURE, "Please provide getLogAccessBreakPoint in 0d:0h:0m format");
			} else {
				response = ParsingUtil.parseLogFile(request);
			}
		} catch (IOException e) {
			response = new ParserResponse(Constants.FAILURE, "Unable to parse the file");
		}
		return response;
	}
	
	@GetMapping(path = "/get")
	public String getsometing() {
		return "Hi";
	}
}
