package com.verizon.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.ParsingUtil;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;

@RestController
public class ParsingController {
	
	private Logger log = LoggerFactory.getLogger(getClass().getName());
	
	@PostMapping(path = "/parse/logfile")
	public ParseResponse parseLogFile(@RequestBody ParseRequest request) {
		ParseResponse response = null;
		try {
			
			if(StringUtils.isEmpty(request.getClassName())) {
				response = new ParseResponse(Constants.FAILURE, "Please provide classname");
			} else {
				response = ParsingUtil.parseLogFile(request.getClassName());
			}
		} catch (IOException e) {
			response = new ParseResponse(Constants.FAILURE, "Unable to parse the file");
		}
		return response;
	}
	
	@GetMapping(path = "/get")
	public String getsometing() {
		return "Hi";
	}
}
