package com.verizon.controller;

import java.io.IOException;
import java.text.ParseException;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.ParsingUtil;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;

@RestController
public class ParsingController {

	@PostMapping(path = "/parse/logfile")
	public ParseResponse parseLogFile(@RequestBody ParseRequest request) {
		ParseResponse response = null;
		try {
			response = ParsingUtil.parseLogFile(request);
		} catch (IOException e) {
			response = new ParseResponse(Constants.FAILURE, "Unable to parse the file");
		} catch(ParseException e){
			response = new ParseResponse(Constants.FAILURE, "Unable to generate pdf");
		}
		return response;
	}

}
