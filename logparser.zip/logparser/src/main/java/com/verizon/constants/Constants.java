package com.verizon.constants;

public class Constants {

	public static final String SUCCESS = "success";
	public static final int THRESHOLD_IN_MILLISECONDS = 0;
	public static final String FAILURE = "failure";
	public static final String FILE_PATH = "C:\\var\\log\\cassandra";
	public static final String OUTPUT_FILE_PATH = "C:\\var\\log\\cassandra\\output";
}
