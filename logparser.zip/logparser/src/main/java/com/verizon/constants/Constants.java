package com.verizon.constants;

public class Constants {

	public static int THRESHOLD_IN_MILLISECONDS = 250;
	
	public static String SUCCESS = "success";
	
	public static String FAILURE = "failure";
	
	public static final String SRC_DIR = "C:\\var\\log\\cassandra";
	
	public static final String EXTRACT_DIR = "C:\\var\\log\\cassandra\\extractFiles";
	
	public static final String DEST_DIR = "C:\\var\\log\\cassandra\\output\\";
	
	public static final String PDF_EXTENSION = ".pdf";
}
