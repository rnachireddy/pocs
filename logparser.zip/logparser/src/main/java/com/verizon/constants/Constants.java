package com.verizon.constants;

import java.util.Arrays;
import java.util.List;

public class Constants {
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String FILE_PATH = "C:\\var\\log\\cassandra";
	public static final String OUTPUT_FILE_PATH = "C:\\var\\log\\cassandra\\output";
	public static final int DEFAULT_THRESHOLD_IN_MILLISECONDS = 100;
	public static final List<String> DEFAULT_THREAD_NAMES = Arrays.asList("COMMIT-LOG-ALLOCATOR", "SlabPoolCleaner", "ScheduledTasks", "RepairJobTask", "CompactionExecutor", "MemtableFlushWriter");
	public static final List<String> DEFAULT_LOG_TYPES = Arrays.asList("WARN", "ERROR");
	public static final long ONE_HOUR_IN_MILLISECONDS = 3600000;
	public static final long ONE_MINUTE_IN_MILLISECONDS = 60000;
	public static final String THREADNAME_COMMITLOGALLOCATOR = "COMMIT-LOG-ALLOCATOR";
	public static final String THREADNAME_SLABPOOLCLEANER = "SlabPoolCleaner";
	public static final String THREADNAME_SCHEDULEDTASKS = "ScheduledTasks";
	public static final String THREADNAME_REPAIRJOBTASK = "RepairJobTask";
	public static final String THREADNAME_COMPACTIONEXECUTOR = "CompactionExecutor";
	public static final String THREADNAME_MEMTABLEFLUSHWRITER = "MemtableFlushWriter";
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss,SSS";
}
