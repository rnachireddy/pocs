package com.verizon.itext;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;

public class PDFCreator {

	private final static String[] HEADER_ARRAY = {"ThreadName","Occurances","S.No","TimeStamp For Max 5", "MAX GC", "TimeStamp For Max 5", "Min GC"};
    private final static int[] COLOUMN_WIDTH = {21,12,5,22,9,22,9};

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN,	8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8,	Font.NORMAL);

	public static void addMetaData(Document document, String sqlXMLFileName) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	public static void addContent(Document document, ParseResponse response) throws DocumentException {

		Paragraph paragraph = new Paragraph();
		paragraph.setFont(NORMAL_FONT);
		createReportTable(paragraph, response);
		document.add(paragraph);
	}
	
	private static void createReportTable(Paragraph paragraph, ParseResponse response)
            throws DocumentException {
                PdfPTable table = new PdfPTable(7);
               
                table.setWidths(COLOUMN_WIDTH);
                paragraph.add(new Chunk("Report Table :- ", SMALL_BOLD));
                if(null == response){
                    paragraph.add(new Chunk("No data to display."));
                    return;
                }
                addHeaderInTable(HEADER_ARRAY, table);
                int count = 1;
              
                List<Log> maxLogList = response.getMax();
                List<Log> minLogList = response.getMin();
                
             PdfPCell cell;
             Iterator<String> iterator = response.getThreads().iterator();
     		 String threadName = iterator.next();
             cell = new PdfPCell(new Phrase(threadName,NORMAL_FONT));
             cell.setRowspan(5);
             table.addCell(cell);
             
             System.out.println("Occurances :: "+response.getThreadCount());
             cell = new PdfPCell(new Phrase(String.valueOf(response.getThreadCount()),NORMAL_FONT));
             
             cell.setHorizontalAlignment(Element.ALIGN_CENTER); /* Left align horizontally */
             cell.setRowspan(5);
             table.addCell(cell);
             for(int i=0;i<5;i++){
               System.out.println("MaxLog ++ "+i+" :: "+maxLogList.get(i));
               System.out.println("MinLog ++ "+i+" :: "+minLogList.get(i));
               
               table.addCell(new PdfPCell(new Phrase(String.valueOf(count++),NORMAL_FONT)));
               table.addCell(new PdfPCell(new Phrase(maxLogList.get(i).getTimeStamp(),NORMAL_FONT)));
               table.addCell(new PdfPCell(new Phrase(String.valueOf(maxLogList.get(i).getTimeInMilliSeconds()+"ms"),NORMAL_FONT)));
               table.addCell(new PdfPCell(new Phrase(minLogList.get(i).getTimeStamp(),NORMAL_FONT)));
               table.addCell(new PdfPCell(new Phrase(String.valueOf(minLogList.get(i).getTimeInMilliSeconds()+"ms"),NORMAL_FONT)));
             }
             paragraph.add(table);
             paragraph.add(setSumamry(response.getMax(), response.getMin()));
	}
	
	public static Paragraph setSumamry(List<Log> list1, List<Log> list2){
	      
	       Font font = new Font(Font.FontFamily.COURIER, 8,
	                  Font.NORMAL);
	       Paragraph summary = new Paragraph();
	       summary.setFont(SMALL_BOLD);
	       summary.add("Summary:");
	       com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
	      
	       for(Log log : list1){
	             orderedList.add(new ListItem(log.getDescription(), font));
	             
	       }
	       for(Log log : list2){
	             orderedList.add(new ListItem(log.getDescription(), font));
	      }
	       summary.add(orderedList);
	       return summary;
	    }



	/** Helper methods start here **/

	public static void addTitlePage(Document document, String title) throws DocumentException {
		
		Paragraph preface = new Paragraph();
		addEmptyLine(preface, 3);
		preface.add(new Phrase("Test Report: ", NORMAL_FONT));
		preface.add(new Phrase(title, PDFCreator.NORMAL_FONT));
		addEmptyLine(preface, 1);
		preface.add(new Phrase("Date: ", PDFCreator.SMALL_BOLD));
		preface.add(new Phrase(new Date().toString(), PDFCreator.NORMAL_FONT));
		addEmptyLine(preface, 1);
		preface.add(new Phrase("Report generated by: ", PDFCreator.SMALL_BOLD));
		preface.add(new Phrase("Verizon", PDFCreator.NORMAL_FONT));
		addEmptyLine(preface, 2);
		preface.add(new Phrase("Cassendra report.", PDFCreator.NORMAL_FONT));
		document.addSubject("PDF : " + title);
		preface.setAlignment(Element.ALIGN_CENTER);
		document.add(preface);
		document.newPage();
	}

	public static void addEmptyLine(Paragraph paragraph, int number) {

		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}

	public static void addHeaderInTable(String[] headerArray, PdfPTable table) {

		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, PDFCreator.SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}

	public static void addToTable(PdfPTable table, String data) {

		table.addCell(new Phrase(data, PDFCreator.NORMAL_FONT));
	}

	public static Paragraph getParagraph() {

		Paragraph paragraph = new Paragraph();
		paragraph.setFont(PDFCreator.NORMAL_FONT);
		addEmptyLine(paragraph, 1);
		return paragraph;
	}

}
