package com.test.jfreeChart;

import java.awt.Color;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.SeriesException;
import org.jfree.data.time.Hour;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.jfree.chart.ChartUtilities;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

public class CassendraLogChartGenerator {

	private static String DATE_FORMAT = "yyyy-MM-dd HH:mm";
	private static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	public static void main(String[] args) throws Exception {

		TimeSeries series1 = new TimeSeries("SlabPoolCleaner");
		TimeSeries series2 = new TimeSeries("COMMIT-LOG-ALLOCATOR");
		TimeSeries series3 = new TimeSeries("ScheduledTasks");

		Date currentDate = new Date();
		Date pastDate = addDays(sdf.format(currentDate), -3,
				getHours(currentDate), getMin(currentDate));
		System.out.println("Current Date :: " + sdf.format(currentDate));
		System.out.println("Past Date ::" + sdf.format(pastDate));

		Random rand = new Random();
		do {

			try {

				int number = rand.nextInt(1000) + 1;

				series1.add(new Hour(pastDate), number);

				number = rand.nextInt(1000) + 1;

				series2.add(new Hour(pastDate), number);

				number = rand.nextInt(1000) + 1;

				series3.add(new Hour(pastDate), number);

				pastDate = addHours(sdf.format(pastDate));
				System.out.println("Past Date ::" + sdf.format(pastDate));

			} catch (SeriesException e) {
				System.err.println("Error adding to series" + e);
				e.printStackTrace();
			}

		} while (pastDate.compareTo(currentDate) <= 0);

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);
		dataset.addSeries(series3);

		// Create the chart
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				"Cassendra Thread Count", "Date", "Count", dataset, true, true,
				false);

		// Get the plot and set date format
		XYPlot plot = chart.getXYPlot();
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("MM-dd HH:mm"));

		// For setting Rendering Points
		plot.setRenderer(0, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(0,
				Color.red);

		plot.setRenderer(1, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(1,
				Color.green);

		plot.setRenderer(2, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(2,
				Color.blue);

		File jpgFile = new File("C:/var/log/cassendra/output/CassendraChart.jpeg");
		ChartUtilities.saveChartAsJPEG(jpgFile, chart, 600, 560);
	}

	public static Date addDays(String oldDate, int numberOfDays, int hours,
			int min) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(oldDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		c.add(Calendar.DAY_OF_MONTH, numberOfDays);
		c.set(Calendar.HOUR_OF_DAY, hours);
		c.set(Calendar.MINUTE, min);

		return c.getTime();
	}

	public static Date addHours(String oldDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(oldDate));
			c.add(Calendar.HOUR_OF_DAY, 6);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		return c.getTime();
	}

	public static int getHours(Date date) {

		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.get(Calendar.HOUR_OF_DAY);

	}

	public static int getDay(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.get(Calendar.DAY_OF_MONTH);
	}

	public static int getMin(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.get(Calendar.MINUTE);
	}

}