package com.verizon.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;

public class NodesProcessingUtil {

	private static Session session = null;
	private static String _host = null;
	private static String _user = null;
	private static String _password = null;
	private static int _port = 22;
	private static List<String> commands = null;

	public static ParseResponse processAllCassandraNodes(String user, String password)
			throws JSchException, IOException, SftpException {
		File directory = new File(Constants.LINUX_BASE_COMMAND_OUTPUT_FOLDER_PATH);
		if (directory.exists()) {
			directory.delete();
		}
		directory.mkdir();
		BufferedReader br = new BufferedReader(
				new InputStreamReader(new ClassPathResource("allowedCommands.txt").getInputStream()));
		commands = br.lines().collect(Collectors.toList());
		
		processAllHosts(user, password);
		return new ParseResponse(Constants.SUCCESS, "success done");
		
	}

	public static void main(String[] args) throws JSchException, IOException, SftpException {
		String user = "vangsa2";
		String password = "P@ssword";
		processAllHosts(user, password);
	}

	public static void processAllHosts(String user, String password)
			throws JSchException, IOException, SftpException {
		_user = user;
		_password = password;
		List<String> hosts = getHosts();
		connect();
		executeCommand("mkdir "+Constants.LINUX_TEMP_DIRETORY_PATH);
		disconnect();
		System.out.println("Linux Directory path created!!");
		for (String host : hosts) {
			connect();
			for (String command : commands) {
				command = "cd /app/cassandra/apache-cassandra-3.0.17/bin ; ./nodetool "+ command + " > " + Constants.LINUX_TEMP_DIRETORY_PATH+command + ".txt";
				executeCommand(command);
			}
			String zipFile = Constants.LINUX_TEMP_DIRETORY_PATH + host + ".zip";
			executeCommand("cd " + Constants.LINUX_TEMP_DIRETORY_PATH + " ; zip "+ zipFile + " *");
			readCommandOutputFromTempFile(zipFile, Constants.LINUX_BASE_COMMAND_OUTPUT_FOLDER_PATH);
			
			executeCommand("rm " +zipFile);
			disconnect();
		}
	}

	private static void readCommandOutputFromTempFile(String source, String destination) throws JSchException, SftpException {
		ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
		channel.connect();
		channel.get(source, destination);
		while (true) {
			if (channel.isClosed())
				break;
		}
		channel.disconnect();
	}

	private static List<String> getHosts() throws IOException {
		BufferedReader br = new BufferedReader(
				new InputStreamReader(new ClassPathResource("servers.txt").getInputStream()));
		List<String> lines = br.lines().collect(Collectors.toList());
		br.close();
		return lines;
	}

	private static void connect() throws JSchException {
		System.out.println("connecting..." + _host);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		session = jsch.getSession(_user, _host, _port);
		session.setPassword(_password);
		session.setConfig(config);
		session.connect();
		System.out.println("Connected");
	}

	private static void disconnect() {
		if (session != null) {
			System.out.println("disconnecting...");
			session.disconnect();
			System.out.println("disconnected...");
		}
	}

	private static void executeCommand(String command) throws JSchException, IOException {
		ChannelExec channel = (ChannelExec) session.openChannel("exec");
		channel.setErrStream(System.err);
		channel.setCommand(command);
		channel.connect();
		while (true) {
			if (channel.isClosed())
				break;
		}
		channel.disconnect();
	}

}
