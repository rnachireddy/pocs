package com.verizon.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;


public class PDFGeneratorUtil {

	public final static Font SMALL_BOLD = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.BOLD);
	public final static Font NORMAL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);
	public final static Font VERY_SMALL_FONT = new Font(Font.FontFamily.TIMES_ROMAN, 5, Font.NORMAL);

	private static long totalEnqueingCount = 0;

	public static void generateReport(ParseResponse response, Map<String, List<Log>> logMap, List<Log> logListForCount, List<String> allowedThreadNames) {
		Document document = new Document();
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(Constants.OUTPUT_FILE_PATH + "\\Report_" +(new Date()).getTime() +".pdf");
			PdfWriter writer = PdfWriter.getInstance(document, os);
			HeaderFooter event = new HeaderFooter();
	        event.setHeader("Cassandra Log Detailed Summary");
	        writer.setPageEvent(event);
			document.open();
			addMetaData(document);
			document.add(createReportTable(response));
			document.add(addEmptyLine());
			document.add(createGeneralThreadTable(logListForCount));
			document.add(addEmptyLine());
			document.add(createFlushThreadTable(logListForCount));
			document.add(addEmptyLine());
			if(allowedThreadNames.contains(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_COMMITLOGALLOCATOR), Constants.THREADNAME_COMMITLOGALLOCATOR));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_SLABPOOLCLEANER)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_SLABPOOLCLEANER), Constants.THREADNAME_SLABPOOLCLEANER));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_SCHEDULEDTASKS)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_SCHEDULEDTASKS), Constants.THREADNAME_SCHEDULEDTASKS));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_REPAIRJOBTASK)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_REPAIRJOBTASK), Constants.THREADNAME_REPAIRJOBTASK));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_COMPACTIONEXECUTOR)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_COMPACTIONEXECUTOR), Constants.THREADNAME_COMPACTIONEXECUTOR));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_MEMTABLEFLUSHWRITER)) {
				document.add(createEnqueThreadTable(logMap.get(Constants.THREADNAME_MEMTABLEFLUSHWRITER), Constants.THREADNAME_MEMTABLEFLUSHWRITER));
				document.add(addEmptyLine());
			}
			BubbleChartGenerator.generateChart(response, logMap);
			if(allowedThreadNames.contains(Constants.THREADNAME_SLABPOOLCLEANER)) {
				document.add(createBubbleChart(Constants.THREADNAME_SLABPOOLCLEANER));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				document.add(createBubbleChart(Constants.THREADNAME_COMMITLOGALLOCATOR));
				document.add(addEmptyLine());
			}
			if(allowedThreadNames.contains(Constants.THREADNAME_SCHEDULEDTASKS)) {
				document.add(createBubbleChart(Constants.THREADNAME_SCHEDULEDTASKS));
				document.add(addEmptyLine());
			}
			document.close();
			writer.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(Exception e){
			e.printStackTrace();
		}finally {
			if (os != null)
				try {
					os.close();
				} catch (IOException e) {
				}
			File file = new File(Constants.THREADNAME_SLABPOOLCLEANER + "_graph.jpeg");
			if(file.exists()) {
				file.delete();
			}
			file = new File(Constants.THREADNAME_COMMITLOGALLOCATOR + "_graph.jpeg");
			if(file.exists()) {
				file.delete();
			}
			file = new File(Constants.THREADNAME_SCHEDULEDTASKS + "_graph.jpeg");
			if(file.exists()) {
				file.delete();
			}
		}
	}

	private static Element createBubbleChart(String threadName) throws IOException, ParseException, BadElementException {
		Image img = Image.getInstance(threadName + "_graph.jpeg");
		img.setScaleToFitLineWhenOverflow(true);
		return img;
	}

	private static Element createFlushThreadTable(List<Log> logListForCount) {
		Paragraph paragraph = new Paragraph();
		PdfPTable table = createTable(1);
		String headerArray[] = { "Total Count of Flush"};
		addHeaderInTable(table, headerArray);
		long totalFlushCount = 0;
		if(logListForCount != null && !logListForCount.isEmpty()) {
			totalFlushCount = logListForCount.stream().filter(log -> {return log.getDescription().contains("Enqueuing flush");}).count();
		}
		totalEnqueingCount = totalFlushCount;
		table.addCell(createCell(String.valueOf(totalFlushCount)));
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph createGeneralThreadTable(List<Log> logListForCount) {
		Paragraph paragraph = new Paragraph();
		PdfPTable table = createTable(2);
		String headerArray[] = { "Total Count of Warnings", "Total Count of Error"};
		addHeaderInTable(table, headerArray);
		long totalWarningCount = 0;
		long totalErrorCount = 0;
		if(logListForCount != null && !logListForCount.isEmpty()) {
			totalWarningCount = logListForCount.stream().filter(log -> {return log.getLogType().equals("WARN");}).count();
			totalErrorCount = logListForCount.stream().filter(log -> {return log.getLogType().equals("ERROR");}).count();
			//totalFlushCount = logListForCount.stream().filter(log -> {return log.getDescription().contains("Enqueuing flush");}).count();
		}
		table.addCell(createCell(String.valueOf(totalWarningCount)));
		table.addCell(createCell(String.valueOf(totalErrorCount)));
		paragraph.add(table);
		return paragraph;
	}

	private static Paragraph addEmptyLine() {
		Paragraph p = new Paragraph();
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		return p;
	}

	private static String[] getHeaderBasedOnThreadName(String threadName) {
		if(Constants.THREADNAME_COMMITLOGALLOCATOR.equals(threadName)
				|| Constants.THREADNAME_SCHEDULEDTASKS.equals(threadName)
				|| Constants.THREADNAME_SLABPOOLCLEANER.equals(threadName)) {
			String array[] = { "Thread Name", "Enqueing Count", "Percentage Of Enqueing"};
			return array;
		}
		if(Constants.THREADNAME_REPAIRJOBTASK.equals(threadName)) {
			String array[] = { "Thread Name", "Total Count", "Table Name"};
			return array;
		}
		if(Constants.THREADNAME_COMPACTIONEXECUTOR.equals(threadName)) {
			String array[] = { "Thread Name", "Total Count", "Large Partition Count", "Key", "Table Name"};
			return array;
		} if(Constants.THREADNAME_MEMTABLEFLUSHWRITER.equals(threadName)) {
			String array[] = { "Thread Name", "Total Count", "Large Partition Message"};
			return array;
		}
		String array[] = { "Total Count of Warnings", "Total Count of Error"};
		return array;
	}
	private static Element createEnqueThreadTable(List<Log> list, String threadName) {
		Paragraph paragraph = new Paragraph();
		int noOfColumns = 3;
		if(threadName.equals(Constants.THREADNAME_COMPACTIONEXECUTOR)) {
			noOfColumns = 5;
		} else if(threadName.equals(Constants.THREADNAME_REPAIRJOBTASK) || threadName.equals(Constants.THREADNAME_MEMTABLEFLUSHWRITER)) {
			noOfColumns = 3;
		}
		PdfPTable table = createTable(noOfColumns);
		addHeaderInTable(table, getHeaderBasedOnThreadName(threadName));
		createContent(table, list, threadName);
		paragraph.add(table);
		return paragraph;
	}

	private static void createContent(PdfPTable table, List<Log> list, String threadName) {
		// Writing large partition aws_or_qa1/cmaf_all:942060984:1:0 (488808900 bytes to sstable /cassandra/data/aws_or_qa1/cmaf_all-d76260b2b13211e8837e9d602768817e/mc-6767-big-Data.db)
		if(Constants.THREADNAME_MEMTABLEFLUSHWRITER.equals(threadName)) {
			long totalCount = 0;
			if(list!= null && !list.isEmpty()) {
				totalCount = list.size();
				list = list.stream().filter(log -> log.getDescription().contains("large partition")).collect(Collectors.toList());
				PdfPCell cell = createCell(String.valueOf(threadName));
				cell.setRowspan(list.size());
				table.addCell(cell);
				cell = createCell(String.valueOf(totalCount));
				cell.setRowspan(list.size());
				table.addCell(cell);
				if(list == null || list.isEmpty()) {
					table.addCell(createCell("NA"));
				} else {
					for(Log l : list) {
						table.addCell(createCell(l.getDescription()));
					}
				}
			} else {
				table.addCell(createCell(threadName));
				table.addCell(createCell(String.valueOf(totalCount)));
				table.addCell(createCell("NA"));
			}
		} else if(Constants.THREADNAME_COMPACTIONEXECUTOR.equals(threadName)) {
			long totalCount = 0;
			long largePartitionCount = 0;
			if(list!= null && !list.isEmpty()) {
				totalCount = list.size();
				largePartitionCount = list.stream().filter(log -> {return log.getDescription().contains("large partition");}).count();
				Map<String, String> map = new HashMap<>();
				for(Log l : list) {
					if(l.getDescription().contains("large partition")) {
						int beginIndex = l.getDescription().lastIndexOf("large partition ") + "large partition ".length();
						int endIndex = l.getDescription().lastIndexOf("bytes to");
						try {
							String substring = l.getDescription().substring(beginIndex, endIndex);
							int index = substring.indexOf("(") + 1;
							if(index > 0) {
								String bytes = substring.substring(index).trim(); 
								long long1 = Long.parseLong(bytes);
								//long1 = long1 /( 1024f * 1024 * 1024);
								bytes = long1 /( 1024f * 1024 * 1024) + " GB";
								String key = substring.substring(substring.indexOf(":") + 1, substring.indexOf(" ")); 
								String value = substring.substring(0, substring.indexOf(":")) + " " + bytes;
								map.put(key, value);
							}
						} catch(Exception ex) {
							
						}
					}
				}
				if(map.size() > 0) {
					PdfPCell cell = createCell(String.valueOf(threadName));
					cell.setRowspan(map.size());
					table.addCell(cell);
					cell = createCell(String.valueOf(totalCount));
					cell.setRowspan(map.size());
					table.addCell(cell);
					cell = createCell(String.valueOf(largePartitionCount));
					cell.setRowspan(map.size());
					table.addCell(cell);
					for(Map.Entry<String, String> entry : map.entrySet()) {
						table.addCell(createCell(entry.getKey()));
						table.addCell(createCell(entry.getValue()));
					}
				} else {
					table.addCell(createCell(threadName));
					table.addCell(createCell(String.valueOf(totalCount)));
					table.addCell(createCell(String.valueOf(largePartitionCount)));
					table.addCell(createCell("NA"));
					table.addCell(createCell("NA"));
				}
			} else {
				table.addCell(createCell(threadName));
				table.addCell(createCell(String.valueOf(totalCount)));
				table.addCell(createCell(String.valueOf(largePartitionCount)));
				table.addCell(createCell("NA"));
				table.addCell(createCell("NA"));
			}
		} else if(Constants.THREADNAME_REPAIRJOBTASK.equals(threadName)) {
			long totalCount = 0;
			Set<String> tableNames = new HashSet<>();
			if(list!= null && !list.isEmpty()) {
				totalCount = list.size();
				for(Log l : list) {
					if(l.getClassName().equalsIgnoreCase("SyncTask.java")) {
						String tableName = l.getDescription().substring(l.getDescription().lastIndexOf(" "));
						tableNames.add(tableName);
					}
				}
				PdfPCell cell = createCell(String.valueOf(threadName));
				cell.setRowspan(tableNames.size());
				table.addCell(cell);
				cell = createCell(String.valueOf(totalCount));
				cell.setRowspan(tableNames.size());
				table.addCell(cell);
				for(String tableName : tableNames) {
					//[repair #89ff8d00-d60f-11e8-9c28-25966d1ef996] Endpoints /10.119.14.80 and /10.119.10.217 are consistent for enterprise_customer
					//table.addCell(createCell(l.getDescription().substring(l.getDescription().indexOf("#"), l.getDescription().indexOf("]"))));
					table.addCell(createCell(tableName));
				}
				
			} else {
				table.addCell(createCell(threadName));
				table.addCell(createCell(String.valueOf(totalCount)));
				table.addCell(createCell("NA"));
			}
		} else if(Constants.THREADNAME_COMMITLOGALLOCATOR.equals(threadName)
				|| Constants.THREADNAME_SCHEDULEDTASKS.equals(threadName)
				|| Constants.THREADNAME_SLABPOOLCLEANER.equals(threadName)) {
			int enqueCount = 0;
			double percentage = 0;
			if(list != null && !list.isEmpty()) {
				enqueCount = (int)list.stream().filter(log -> {return log.getDescription().toLowerCase().contains("enque");}).count();
				percentage = enqueCount * 100f / totalEnqueingCount;
			}
			table.addCell(createCell(threadName));
			table.addCell(createCell(String.valueOf(enqueCount)));
			table.addCell(createCell(new DecimalFormat("##.##").format(percentage) + " %"));
		}
	}

	private static PdfPTable createTable(int i) {
		PdfPTable table = new PdfPTable(i); 
		if(i == 4) {
			table.setWidthPercentage(100);
		} else if(i == 2) {
			table.setWidthPercentage(100);
		} else if( i ==1) {
			table.setWidthPercentage(100);
		} else if(i==3) {
			table.setWidthPercentage(100);
		}  else if(i==5) {
			table.setWidthPercentage(100);
		}
		
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		return table;
	}

	private static Paragraph createReportTable(ParseResponse response) throws DocumentException {
		Paragraph paragraph = new Paragraph();
		paragraph.setFont(NORMAL_FONT);
		paragraph.add(new Chunk("Report Table :- ", SMALL_BOLD));
		PdfPTable table = createTable();
		String headerArray[] = { "GC  Occurences", "S.No", "Thread Name", "Time Stamp for Max five GC", "Max GC",
				"Thread Name", "Time Stamp for Min five GC", "Min GC" };
		addHeaderInTable(table, headerArray);
		createContent(table, response);
		paragraph.add(table);
		//paragraph.add(createAndAddSubject(response));
		return paragraph;
	}

	public static void addMetaData(Document document) {
		document.addTitle("Cassendra Reports");
		document.addSubject("Using iText");
		document.addAuthor("Verizon");
	}

	private static void createContent(PdfPTable table, ParseResponse response) {
		if (response != null) {
			List<Log> max = response.getTopMaximumFiveGCInspectorThreads();
			List<Log> min = response.getTopMinimumFiveGCInspectorThreads();
			int size = maximum(max, min);
			PdfPCell cell = createCell(String.valueOf(response.getCountOfGCInspector()));
			cell.setRowspan(size);
			table.addCell(cell);
			for (int i = 0; i < size; i++) {
				if (max.size() > i) {
					table.addCell(createCell(String.valueOf(i + 1))); // add Serial No
					createLogDetails(table, max.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
				if (min.size() > i) {
					createLogDetails(table, min.get(i), i);
				} else {
					table.addCell(createCell(""));
					table.addCell(createCell(""));
				}
			}
		}
	}

	private static void createLogDetails(PdfPTable table, Log log, int i) {
		table.addCell(createCell(log.getThreadName()));
		table.addCell(createCell(log.getTimeStamp()));
		table.addCell(createCell(String.valueOf(log.getTimeInMilliSeconds())));
	}

	private static int maximum(List<Log> max, List<Log> min) {
		int size = max != null ? max.size() : 0;
		size = min != null && min.size() > size ? min.size() : size;
		return size;
	}

	private static PdfPTable createTable() throws DocumentException {
		PdfPTable table = new PdfPTable(8); // 8 Columns
		table.setWidthPercentage(100); // Width 100%
		table.setSpacingBefore(5f); // Space before table
		table.setSpacingAfter(5f); // S
		float[] columnWidths = { 9f, 7f, 12f, 34f, 8f, 12f, 34f, 8f };
		table.setWidths(columnWidths);
		return table;
	}
	private static PdfPCell createCell(String str) {
		PdfPCell cell = new PdfPCell(new Phrase(str, NORMAL_FONT));
		cell.setBorderColor(BaseColor.BLACK);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}

	private static void addHeaderInTable(PdfPTable table, String headerArray[]) {
		
		PdfPCell c1 = null;
		for (String header : headerArray) {
			c1 = new PdfPCell(new Phrase(header, SMALL_BOLD));
			c1.setBackgroundColor(BaseColor.GREEN);
			c1.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(c1);
		}
		table.setHeaderRows(1);
	}
	
	private static Paragraph createAndAddSubject(ParseResponse response) {
	       Font font = new Font(Font.FontFamily.COURIER, 8,
	                  Font.NORMAL);
	       Paragraph paragraph = new Paragraph();
	       paragraph.setFont(SMALL_BOLD);
	       paragraph.add("Summary:");
	       com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
	       List<Log> max = response.getTopMaximumFiveGCInspectorThreads();
			List<Log> min = response.getTopMinimumFiveGCInspectorThreads();
			if(min != null) {
				for(Log log : max){
					orderedList.add(new ListItem(log.getLogType() + "  " +log.getDescription(), font));
				}
			}
			if(max != null) {
				for(Log log : min){
					orderedList.add(new ListItem(log.getLogType() + "  " +log.getDescription(), font));
				}
			}
	       paragraph.add(orderedList);
	       return paragraph;
    }
	
}
