package com.verizon.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.verizon.constants.Constants;

public class LogsLoadingUtil {


	private static void fetchLogFiles(String hostName, String userName, String password) {
		JSch jsch = new JSch();
		Session session = null;
		ChannelExec channelExec = null;
		ChannelSftp sftpChannel = null;
		try {
			System.out.println("Connecting ..." + hostName);
			String destinationPath = Constants.FILE_PATH;
			String tempDirectoryInLinux = "/tmp/cassandralogtemp/";
			String zipFile = tempDirectoryInLinux + hostName + ".zip";
			File directory = new File(destinationPath);
			if (directory.exists()) {
				directory.delete();
			}
			directory.mkdir();
			session = jsch.getSession(userName, hostName, Constants.HOST_PORT);
			session.setPassword(password);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
			
			channelExec = (ChannelExec) session.openChannel("exec");
			String command = "cd /var/log/cassandra ; mkdir " + tempDirectoryInLinux + " ; zip "+ zipFile + " *";
			channelExec.setCommand(command);
			channelExec.connect();
			//channelExec.disconnect();
			
			while (true) {
				if (channelExec.isClosed()) {
					channelExec.disconnect();
					break;
				}
			}
			sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
			sftpChannel.get(zipFile, destinationPath);
			
			channelExec = (ChannelExec) session.openChannel("exec");
			command = "cd " + tempDirectoryInLinux +" ; rm *";
			channelExec.setCommand(command);
			channelExec.connect();
			
		} catch (JSchException e) {
			System.err.println("GetFilesFromSFTP : JSchException, " + e.toString());
		} catch (SftpException e) {
			System.err.println("GetFilesFromSFTP : SftpException, " + e.toString());
		} finally {
			try {
				if (sftpChannel.isConnected()) {
					channelExec.disconnect();
					sftpChannel.disconnect();
					session.disconnect();
					sftpChannel.quit();
				}
			} catch (Exception e) {
				System.err.println(
						"GetFilesFromSFTP : Could not close SFTP Client after Downloading files from SFPT server, "
								+ e.toString());
			}
		}
		System.out.println("Done " + hostName + " !!");
	}

	public static void main(String args[]) throws FileNotFoundException {
		loadLogsFromAllNodes("vangsa2", "P@ssword");
	}

	public static void loadLogsFromAllNodes(String userName, String password) {

		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(new ClassPathResource("servers.txt").getInputStream()));
			List<String> lines = br.lines().collect(Collectors.toList());
			for (String hostName : lines) {
				fetchLogFiles(hostName, userName, password);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}