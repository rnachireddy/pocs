package com.verizon.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.verizon.constants.Constants;

public class LogsLoadingUtil {

	private static BufferedReader br = null;
	
	private static void fetchLogFiles(String hostName, String userName, String password) {
		Session session = null;
		try {
			System.out.println("Connecting ..." + hostName);
			String destinationPath = Constants.FILE_PATH;
			String tempDirectoryInLinux = "/tmp/cassandralogtemp/";
			String zipFile = tempDirectoryInLinux + hostName + ".zip";
			File directory = new File(destinationPath);
			if (directory.exists()) {
				directory.delete();
			}
			directory.mkdir();
			session = getSession(userName, password, hostName);
			System.out.println("Connected");
			
			String command = "cd /var/log/cassandra ; mkdir " + tempDirectoryInLinux + " ; zip "+ zipFile + " *";
			executeCommand(command, session);
			
			copyRemoteFiles(session, zipFile, destinationPath);
			
			command = "cd " + tempDirectoryInLinux +" ; rm *";
			executeCommand(command, session);
			
			/*
			channel = session.openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.cd(Constants.CASSANDRA_DIRECTORY_PATH_IN_SERVERS);
			@SuppressWarnings("unchecked")
			Vector<LsEntry> filesToDownload = sftpChannel.ls("*");
			
			if (filesToDownload.size() > 0) {
				for(LsEntry entry : filesToDownload) {
					if(entry.getFilename().contains("debug")) 
						sftpChannel.get(entry.getFilename(), destinationPath);
						File downloadedFile = new File(destinationPath + "\\" + entry.getFilename());
						String modifiedTimeString = entry.getAttrs().getMtimeString();
						SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy");
						downloadedFile.setLastModified(format.parse(modifiedTimeString).getTime());
						
					}
			}
			*/
		
		} catch (JSchException e) {
			System.err.println("GetFilesFromSFTP : JSchException, " + e.toString());
		} catch (SftpException e) {
			System.err.println("GetFilesFromSFTP : SftpException, " + e.toString());
		} finally {
			try {
				session.disconnect();
			} catch (Exception e) {
				System.err.println(
						"GetFilesFromSFTP : Could not close SFTP Client after Downloading files from SFPT server, "
								+ e.toString());
			}
		}
		System.out.println("Done " + hostName + " !!");
	}
	
	public static Session getSession(String userName, String password, String hostName) throws JSchException{
		JSch jsch = new JSch();
		Session session = jsch.getSession(userName, hostName, Constants.HOST_PORT);
		session.setPassword(password);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
		session.setConfig(config);
		session.connect();
		return session;
	}
	
	public static void executeCommand(String command, Session session) throws JSchException{
		ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
		channelExec.setCommand(command);
		channelExec.connect();
		while (true) {
			if (channelExec.isClosed()) {
				channelExec.disconnect();
				break;
			}
		}
	}
	
	public static void copyRemoteFiles(Session session, String sourcePath, String destinationPath) throws JSchException, SftpException{
		ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
		sftpChannel.connect();
		sftpChannel.get(sourcePath, destinationPath);
		while (true) {
			if (sftpChannel.isClosed()) {
				sftpChannel.disconnect();
				break;
			}
		}
	}

	public static void main(String args[]) throws FileNotFoundException {
		loadLogsFromAllNodes("vangsa2", "P@ssword");
	}

	public static void loadLogsFromAllNodes(String userName, String password) {

		try {
			List<String> lines = getLinesAsList("servers.txt");
			for (String hostName : lines) {
				fetchLogFiles(hostName, userName, password);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
	
	public static List<String> getLinesAsList(String fileName) throws IOException{
		br = new BufferedReader(new InputStreamReader(new ClassPathResource(fileName).getInputStream()));
		List<String> lines = br.lines().collect(Collectors.toList());
		return lines;
	}
	
	public static String BaseLogsLoad(String userName, String password, String hostName){
		Session session = null;
		String destinationPath = Constants.FILE_PATH+"baseFiles//";
		String tempDirectoryInLinux = "/tmp/cassandralogtemp/baseFiles/";
		String zipFile = tempDirectoryInLinux + hostName + ".zip";
		String baseFileName = null;
		String command = null;
		File directory = new File(destinationPath);
		if (directory.exists()) {
			directory.delete();
		}
		directory.mkdir();
		try {
			List<String> lines = getLinesAsList("commands.txt");
			session = getSession(userName, password, hostName);
			System.out.println("Connected");
			command = "mkdir " + tempDirectoryInLinux;
			executeCommand(command, session);
			System.out.println("Directory Created!!");
			for (String parameter : lines) {
				baseFileName = tempDirectoryInLinux + parameter + ".txt";
				command = "cd /app/cassandra/apache-cassandra-3.0.17/bin ; ./nodetool >"+ baseFileName;
				executeCommand(command, session);
			}
			command = "cd " + tempDirectoryInLinux + " ; zip "+ zipFile + " *";
			executeCommand(command, session);
			
			copyRemoteFiles(session, zipFile, destinationPath);
			
			command = "cd " + tempDirectoryInLinux +" ; rm *";
			executeCommand(command, session);
			
		} catch (JSchException e) {
			System.err.println("GetFilesFromSFTP : JSchException, " + e.toString());
		} catch (SftpException e) {
			System.err.println("GetFilesFromSFTP : SftpException, " + e.toString());
		} catch (IOException e) {
			System.err.println("GetFilesFromSFTP : IOException, " + e.toString());
		} finally {
			try {
				session.disconnect();
			} catch (Exception e) {
				System.err.println(
						"GetFilesFromSFTP : Could not close SFTP Client after Downloading files from SFPT server, "
								+ e.toString());
			}
		}
		System.out.println("Done " + hostName + " !!");
		return "Base Files Downloaded "+ hostName +" !!";
	}

}