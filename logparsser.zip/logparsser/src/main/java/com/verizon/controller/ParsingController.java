package com.verizon.controller;

import java.io.IOException;
import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.verizon.ParsingUtil;
import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;
import com.verizon.util.NodesProcessingUtil;

@RestController
public class ParsingController {

	@PostMapping(path = "/parse/logfile")
	public ParseResponse parseLogFile(@RequestBody ParseRequest request) {
		ParseResponse response = null;
		try {
			if(StringUtils.isNotEmpty(request.getUserName()) && StringUtils.isNotEmpty(request.getPassword()))  {
				response = ParsingUtil.parseLogFile(request);
			} else {
				response = new ParseResponse(Constants.FAILURE, "Please give correct credentials");
			}
		} catch (IOException e) {
			response = new ParseResponse(Constants.FAILURE, "Unable to parse the file");
		} catch (ParseException e) {
			response = new ParseResponse(Constants.FAILURE, "Unable to parse the file");
		}
		return response;
	}
	
	@PostMapping(path = "/process/servers")
	public ParseResponse processAllCassandraNodes(@RequestBody ParseRequest request) throws JSchException, IOException, SftpException {
		ParseResponse response = null;
		if(StringUtils.isNotEmpty(request.getUserName()) && StringUtils.isNotEmpty(request.getPassword()))  {
			response = NodesProcessingUtil.processAllCassandraNodes(request.getUserName(), request.getPassword());
		} else {
			response = new ParseResponse(Constants.FAILURE, "Please give correct credentials");
		}
		return response;
	}

}
