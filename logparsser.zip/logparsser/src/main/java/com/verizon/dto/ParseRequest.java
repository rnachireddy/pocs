package com.verizon.dto;

import java.util.List;

public class ParseRequest {

	private String className;
	private String thresholdInMilliSeconds;
	private String hours;
	private String minutes;
	private List<String> threadNames;
	private List<String> logTypes;
	private String userName;
	private String password;
	
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getThresholdInMilliSeconds() {
		return thresholdInMilliSeconds;
	}

	public void setThresholdInMilliSeconds(String thresholdInMilliSeconds) {
		this.thresholdInMilliSeconds = thresholdInMilliSeconds;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	public List<String> getThreadNames() {
		return threadNames;
	}

	public void setThreadNames(List<String> threadNames) {
		this.threadNames = threadNames;
	}

	public List<String> getLogTypes() {
		return logTypes;
	}

	public void setLogTypes(List<String> logTypes) {
		this.logTypes = logTypes;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

}
