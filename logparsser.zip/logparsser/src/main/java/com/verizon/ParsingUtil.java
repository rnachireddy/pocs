package com.verizon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.util.StringUtils;

import com.verizon.constants.Constants;
import com.verizon.dto.ParseRequest;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;
import com.verizon.util.LogsLoadingUtil;
import com.verizon.util.PDFGeneratorUtil;

public class ParsingUtil {

	private static Map<String, List<Log>> logMap;
	private static List<Log> logListForCount;
	private static List<String> allowedThreadNames;
	private static List<Log> gcInspectorLogsWhichCrossedThreshold;
	private static List<Log> logList;
	private static Date currentDate;
	private static int countOfGCInspector = 0;
	private static long timeInMilliSeconds;
	private static long thresholdTimeInMilliSeconds;
	
	/**
	 * Method to process the request and generate output response
	 * @param request
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public static ParseResponse parseLogFile(ParseRequest request) throws IOException, ParseException {
		logList = new ArrayList<>();
		logListForCount = new ArrayList<>();
		logMap = new HashMap<>();
		gcInspectorLogsWhichCrossedThreshold = new ArrayList<Log>();
		currentDate = new Date();
		countOfGCInspector = 0;
		timeInMilliSeconds = getTimeInMillisecondsFromRequest(request);
		allowedThreadNames = getThreadNamesFromRequest(request);
		thresholdTimeInMilliSeconds = getThresholdTimeFromRequest(request);
		LogsLoadingUtil.loadLogsFromAllNodes(request.getUserName(), request.getPassword());
		fileReader(Constants.FILE_PATH);
		ParseResponse response = new ParseResponse(Constants.SUCCESS, "Successfully executed");
		response.setCountOfGCInspector(countOfGCInspector);
		if(gcInspectorLogsWhichCrossedThreshold != null && !gcInspectorLogsWhichCrossedThreshold.isEmpty()) {
			Collections.sort(gcInspectorLogsWhichCrossedThreshold, new Comparator<Log>() {
			    @Override
			    public int compare(Log log1, Log log2) {
			        // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
			    	if(log1.getTimeInMilliSeconds() != null && log2.getTimeInMilliSeconds() != null) {
			    		return log1.getTimeInMilliSeconds() > log2.getTimeInMilliSeconds() ? -1 : (log1.getTimeInMilliSeconds() < log2.getTimeInMilliSeconds()) ? 1 : 0;
			    	} else {
			    		return 0;
			    	}
			    }
			});
			printToFile(gcInspectorLogsWhichCrossedThreshold);
			response.setTopMaximumFiveGCInspectorThreads(getTopMaximumFive(gcInspectorLogsWhichCrossedThreshold));
			response.setTopMinimumFiveGCInspectorThreads(getTopMinimumFive(gcInspectorLogsWhichCrossedThreshold));
			
		}
		logMap = processMap(logList);
		
		processAndSetMinAndMaxMemoryUsed(response, logMap);
		processAndSetMinAndMaxFlushTimeStamp(response);
		PDFGeneratorUtil.generateReport(response, logMap, logListForCount, allowedThreadNames);
		return response;
	}

	private static void processAndSetMinAndMaxMemoryUsed(ParseResponse response, Map<String, List<Log>> logMap) {
		Double min = null, max = null;
		if (logMap != null && !logMap.isEmpty()) {
			List<Log> list1 = logMap.get(Constants.THREADNAME_COMMITLOGALLOCATOR);
			List<Log> list2 = logMap.get(Constants.THREADNAME_SLABPOOLCLEANER);
			List<Log> list3 = logMap.get(Constants.THREADNAME_SCHEDULEDTASKS);
			List<Log> collect = new ArrayList<>();
			if(list1 != null && !list1.isEmpty()) {
				collect.addAll(list1);
			}
			if (list2 != null && !list2.isEmpty()) {
				collect.addAll(list2);
			}
			if(list3 != null && !list3.isEmpty()) {
				collect.addAll(list3);
			}
			collect = collect.stream().filter(log -> {return log.getMemoryUsed() != null;}).collect(Collectors.toList());
			if (!collect.isEmpty()) {
				Collections.sort(collect, new Comparator<Log>() {
					@Override
					public int compare(Log log1, Log log2) {
						if (log1 == null || log2 == null)
							return 0;
						return log1.getMemoryUsed().compareTo(log2.getMemoryUsed());
					}

				});
				min = collect.get(0).getMemoryUsed();
				max = collect.get(collect.size()- 1).getMemoryUsed();
			}
		}
		response.setMaximumMemoryUsed(max);
		response.setMinimumMemoryUsed(min);
	}

	/**
	 * Method to set the Minimum and Maximum Flush Time Stamp that is to be used while creating the graph
	 * @param response
	 */
	private static void processAndSetMinAndMaxFlushTimeStamp(ParseResponse response){
		long diffMilliSeconds = new Date().getTime() - timeInMilliSeconds;
		response.setMinFlushTimeStamp(new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT).format(new Date(diffMilliSeconds)));
		response.setMaxFlushTimeStamp(new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT).format(new Date()));
	}

	private static long getThresholdTimeFromRequest(ParseRequest request) {
		long threshold = Constants.DEFAULT_THRESHOLD_IN_MILLISECONDS;
		if(!StringUtils.isEmpty(request.getThresholdInMilliSeconds())) {
			threshold = Long.parseLong(request.getThresholdInMilliSeconds());
		}
		return threshold;
	}

	private static List<String> getThreadNamesFromRequest(ParseRequest request) {
		if(request.getThreadNames() == null || request.getThreadNames().isEmpty()) {
			return Constants.DEFAULT_THREAD_NAMES;
		}
		return request.getThreadNames();
	}

	private static long getTimeInMillisecondsFromRequest(ParseRequest request) {
		long time = 0;
		if (!StringUtils.isEmpty(request.getHours())) {
			time = (long) (Constants.ONE_HOUR_IN_MILLISECONDS * Double.parseDouble(request.getHours()));
		}
		if (!StringUtils.isEmpty(request.getMinutes())) {
			time = time + (long) (Constants.ONE_MINUTE_IN_MILLISECONDS * Double.parseDouble(request.getMinutes()));
		}
		if (time == 0) {
			time = Constants.ONE_HOUR_IN_MILLISECONDS;
		}
		return time;
	}

	private static boolean isFileConsideredForProcessing(Date fileDate, Date currentDate) {
		long timeDifferenceInMilliSeconds = currentDate.getTime() - fileDate.getTime();
		if(timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
			return true;
		}
		return false;
	}

	private static boolean isLogConsideredForProcessing(Log log, Date currentDate) {
		String timeStamp = log.getTimeStamp();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			Date date = format.parse(timeStamp);
			long timeDifferenceInMilliSeconds = currentDate.getTime() - date.getTime();
			if(timeDifferenceInMilliSeconds <= timeInMilliSeconds && timeDifferenceInMilliSeconds >= 0) {
				return true;
			}
		} catch (ParseException e) {
			
		}
		return false;
	}

	private static List<Log> getTopMinimumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for(int i = logList.size() -  1; i >= 0 && count < 5 ; i--, count++ ) {
			list.add(logList.get(i));
		}
		return list;
	}

	private static List<Log> getTopMaximumFive(List<Log> logList) {
		List<Log> list = new ArrayList<>();
		int count = 0;
		for (Log log : logList) {
			count++;
			list.add(log);
			if(count == 5) break;
		}
		return list;
	}
	
	private static void printToFile(List<Log> logList) throws IOException {
		// print in to a file >= 250ms in a meaning ful format
		BufferedWriter writer = new BufferedWriter(new FileWriter(Constants.OUTPUT_FILE_PATH + "\\OutputGcInspector_" +(new Date()).getTime() +".txt"));
		for(Log log : logList) {
			writer.write(log.getLogType() + "\t" + log.getDescription() + "\n");
		}
		writer.close();
	}

	public static Integer extractThreshold(String description) {
		Integer timeInMilliSeconds = null;
		Pattern p = Pattern.compile("^(.*)( \\d{1,})(ms)(.*)$");
		Matcher m = p.matcher(description);
		if (m.find()) {
			timeInMilliSeconds = Integer.parseInt(m.group(2).trim());
		}
		return timeInMilliSeconds;
	}

	private static Log extractLog(String str) {
		Pattern p = Pattern.compile(
				"^(INFO|DEBUG|WARN|ERROR|TRACE)(.*\\[)([a-zA-Z0-9\\- ]*)(.*\\].*)(\\d{4}-\\d{2}-\\d{2}.*\\d{2}:\\d{2}:\\d{2},\\d{1,})(.*\\.java)(.*- )(.*)$");
		Matcher m = p.matcher(str);
		if (m.find()) {
			Log log = new Log(m.group(1).trim(), m.group(5).trim(), m.group(6).trim(), m.group(3).trim(),
					m.group(8).trim());
			if(log.getClassName().equals("GCInspector.java")) {
				Integer timeInMilliSeconds = extractThreshold(log.getDescription());
				if(timeInMilliSeconds != null) {
					log.setTimeInMilliSeconds(timeInMilliSeconds);
				}
			}
			if(log.getThreadName().equals(Constants.THREADNAME_SCHEDULEDTASKS)
					|| log.getThreadName().equals(Constants.THREADNAME_SLABPOOLCLEANER)
					|| log.getThreadName().equals(Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				Double memoryUsed = extractMemoryFromDescription(log.getDescription());
				log.setMemoryUsed(memoryUsed);
			}
			return log;
		}
		return null;
	}

	private static Double extractMemoryFromDescription(String description) {
		Pattern p = Pattern.compile("^(.*: )(\\d*)( \\(.*)*$");
		Matcher m = p.matcher(description);
		// if memory is given in bytes
		if(m.find()) {
			Double memoryUsed = Long.valueOf(m.group(2)).doubleValue() / 1024/ 1024/1024;
			return memoryUsed;
		}
		p = Pattern.compile("^(.*: )(\\d*\\.\\d*)(MiB.*)*$");
		m = p.matcher(description);
		//86.700MiB
		// if memory is given in mib
		if(m.find()) {
			Double memoryUsed = Double.valueOf(m.group(2)).doubleValue() / 1024;
			return memoryUsed;
		}
		return null;
	}

	public static void fileReader(String file) throws FileNotFoundException, IOException {
		File f = new File(file);
		fileReader(f);
		
	}

	public static void fileReader(File file) throws FileNotFoundException, IOException {
		if(file.isDirectory()) {
			File[] files = file.listFiles();
			for(File f: files) {
				fileReader(f);
			}
		} else if(file.getName().endsWith(".zip")) {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractZip(fileInputStream);
			fileInputStream.close();
		} else {
			FileInputStream fileInputStream = new FileInputStream(file);
			extractFileContents(fileInputStream);
			fileInputStream.close();
		}
	}
	
	private static void extractZip(InputStream inputStream) throws IOException {
		ZipInputStream zipInputStream = new ZipInputStream(inputStream);
		ZipEntry entry = zipInputStream.getNextEntry();
		while (entry != null) {
			if(isFileConsideredForProcessing(Date.from(entry.getLastModifiedTime().toInstant().atZone(ZoneId.systemDefault()).toInstant()), currentDate)) {
				if (entry.getName().endsWith(".zip")) {
					extractZip(zipInputStream);
				} else {
					extractFileContents(zipInputStream);
				}
			}
			entry = zipInputStream.getNextEntry();
		}
	}

	private static void extractFileContents(InputStream inputStream) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		List<String> collector = br.lines().collect(Collectors.toList());
		for (int i = collector.size() - 1; i > 0; i--) {
			String line = collector.get(i);
			if(isLineConsidered(line) ) {
				Log log = extractLog(line);
				if (log == null) {
					continue;
				} else if (isLogConsideredForProcessing(log, currentDate)) {
					if ("GCInspector.java".equals(log.getClassName())) {
						countOfGCInspector++;
						if (log.getTimeInMilliSeconds() != null
								&& log.getTimeInMilliSeconds() >= thresholdTimeInMilliSeconds) {
							gcInspectorLogsWhichCrossedThreshold.add(log);
						}
					}
					if (allowedThreadNames.contains(log.getThreadName())) {
						logList.add(log);
					}
					logListForCount.add(log);
				} else {
					return;
				}
			}
		}
		/*for (String line : collector) {
			Log log = extractLog(line);
			if (log != null && isLogConsideredForProcessing(log, currentDate)) {
				if ("GCInspector.java".equals(log.getClassName())) {
					countOfGCInspector++;
					if (log.getTimeInMilliSeconds() != null
							&& log.getTimeInMilliSeconds() >= thresholdTimeInMilliSeconds) {
						gcInspectorLogsWhichCrossedThreshold.add(log);
					}
				}
				if (allowedThreadNames.contains(log.getThreadName())) {
					logList.add(log);
				}
				logListForCount.add(log);
			}
		}*/
	}

	private static boolean isLineConsidered(String line) {
		boolean consider = false;
		for(String thread : allowedThreadNames) {
			consider = line.contains(thread);
			if(consider) break;
		}
		if(!consider)
			consider = line.contains("GCInspector.java");
		if(!consider)
			consider = line.contains("WARN") || line.contains("ERROR");
		return consider;
	}

	private static Map<String, List<Log>>processMap(List<Log> logs) {
		Map<String, List<Log>> map = new HashMap<>();
		for(String threadName : allowedThreadNames) {
			List<Log> list = logs.stream().filter(log -> {
				return threadName.equals(log.getThreadName());
			}).collect(Collectors.toList());
			map.put(threadName, list);
			/*List<Log> list = new ArrayList<>();
			for(Log log : logs) {
				if(threadName.equals(log.getThreadName()))
				list.add(log);
			}*/
		}
		return map;
	}
}
