package com.verizon.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.verizon.logparser.model.Log;

public class ParseResponse {

	private String status;
	private String message;
	private Set<String> threadsExecutedGCInspector;
	private int countOfGCInspector;
	private List<Log> topMaximumFiveGCInspectorThreads;
	private List<Log> topMinimumFiveGCInspectorThreads;
	private Double maximumMemoryUsed;
	private Double minimumMemoryUsed;
	private String minFlushTimeStamp;
	private String maxFlushTimeStamp;

	public ParseResponse(String status, String message) {
		this.status = status;
		this.message = message;
		this.topMaximumFiveGCInspectorThreads = new ArrayList<>();
		this.topMinimumFiveGCInspectorThreads = new ArrayList<>();
	}

	public ParseResponse() {
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Set<String> getThreadsExecutedGCInspector() {
		return threadsExecutedGCInspector;
	}

	public void setThreadsExecutedGCInspector(Set<String> threadsExecutedGCInspector) {
		this.threadsExecutedGCInspector = threadsExecutedGCInspector;
	}

	public int getCountOfGCInspector() {
		return countOfGCInspector;
	}

	public void setCountOfGCInspector(int countOfGCInspector) {
		this.countOfGCInspector = countOfGCInspector;
	}

	public List<Log> getTopMaximumFiveGCInspectorThreads() {
		return topMaximumFiveGCInspectorThreads;
	}

	public void setTopMaximumFiveGCInspectorThreads(List<Log> topMaximumFiveGCInspectorThreads) {
		this.topMaximumFiveGCInspectorThreads = topMaximumFiveGCInspectorThreads;
	}

	public List<Log> getTopMinimumFiveGCInspectorThreads() {
		return topMinimumFiveGCInspectorThreads;
	}

	public void setTopMinimumFiveGCInspectorThreads(List<Log> topMinimumFieGCInspectorThreads) {
		this.topMinimumFiveGCInspectorThreads = topMinimumFieGCInspectorThreads;
	}

	public Double getMaximumMemoryUsed() {
		return maximumMemoryUsed;
	}

	public void setMaximumMemoryUsed(Double maximumMemoryUsed) {
		this.maximumMemoryUsed = maximumMemoryUsed;
	}

	public Double getMinimumMemoryUsed() {
		return minimumMemoryUsed;
	}

	public void setMinimumMemoryUsed(Double minimumMemoryUsed) {
		this.minimumMemoryUsed = minimumMemoryUsed;
	}

	public String getMinFlushTimeStamp() {
		return minFlushTimeStamp;
	}

	public void setMinFlushTimeStamp(String minFlushTimeStamp) {
		this.minFlushTimeStamp = minFlushTimeStamp;
	}

	public String getMaxFlushTimeStamp() {
		return maxFlushTimeStamp;
	}

	public void setMaxFlushTimeStamp(String maxFlushTimeStamp) {
		this.maxFlushTimeStamp = maxFlushTimeStamp;
	}

}
