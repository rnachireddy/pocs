package com.verizon.util;

import java.awt.Color;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartUtilities;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

import com.verizon.constants.Constants;
import com.verizon.logparser.model.Log;

public class TimeLineChartGeneratorUtil {

	public static void generateTimeLineChart(List<Log> logList) throws IOException,
			ParseException {

		TimeSeries slabPoolCleanerSeries = new TimeSeries("SlabPoolCleaner");
		TimeSeries commitLogAllocatorSeries = new TimeSeries(
				"COMMIT-LOG-ALLOCATOR");
		TimeSeries scheduledTasksSeries = new TimeSeries("ScheduledTasks");

		for (Log log : logList) {
			if (log.getThreadName().equalsIgnoreCase(
					Constants.THREADNAME_SLABPOOLCLEANER)) {
				slabPoolCleanerSeries.add(
						new Millisecond(parseDate(log.getTimeStamp())),
						log.getMemoryUsed());
			} else if (log.getThreadName().equalsIgnoreCase(
					Constants.THREADNAME_COMMITLOGALLOCATOR)) {
				commitLogAllocatorSeries.add(
						new Millisecond(parseDate(log.getTimeStamp())),
						log.getMemoryUsed());
			} else if (log.getThreadName().equalsIgnoreCase(
					Constants.THREADNAME_SCHEDULEDTASKS)) {
				scheduledTasksSeries.add(
						new Millisecond(parseDate(log.getTimeStamp())),
						log.getMemoryUsed());
			}
		}

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(slabPoolCleanerSeries);
		dataset.addSeries(commitLogAllocatorSeries);
		dataset.addSeries(scheduledTasksSeries);

		// Create the chart
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				"SLAB POOL CLEANER vs COMMON-LOG-ALLOCATOR vs SCHEDULE TASKS",
				"TimeStamp", "Memory Used", dataset, true, true, false);

		// Get the plot and set date format
		XYPlot plot = chart.getXYPlot();
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("MM-dd HH:mm"));

		// For setting Rendering Points
		plot.setRenderer(0, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(0,
				Color.red);

		plot.setRenderer(1, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(1,
				Color.green);

		plot.setRenderer(2, new XYLineAndShapeRenderer());
		plot.getRendererForDataset(plot.getDataset(0)).setSeriesPaint(2,
				Color.blue);

		File jpgFile = new File(Constants.OUTPUT_FILE_PATH + "\\FlushGraph_"
				+ (new Date()).getTime() + ".jpeg");
		ChartUtilities.saveChartAsJPEG(jpgFile, chart, 600, 560);
	}

	public static Date parseDate(String timeStamp) throws ParseException {
		DateFormat sdf = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		return sdf.parse(timeStamp);
	}

}
