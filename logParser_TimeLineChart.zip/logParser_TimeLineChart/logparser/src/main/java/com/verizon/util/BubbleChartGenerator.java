package com.verizon.util;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.chart.ChartUtilities;

import com.verizon.constants.Constants;
import com.verizon.dto.ParseResponse;
import com.verizon.logparser.model.Log;

public class BubbleChartGenerator {
	
	

	public static void generateChart(ParseResponse response, List<Log> logList) throws IOException, ParseException {
		
		
		// Create dataset  
	    XYZDataset dataset = createDataset(logList); 
		
		JFreeChart jfreechart = ChartFactory.createBubbleChart(
				"SLAB POOL CLEANER vs COMMON-LOG-ALLOCATOR vs SCHEDULE TASKS",
				"TimeStamp", "Memory", dataset,
				PlotOrientation.VERTICAL, true, true, false);
		
		// Set range for X-Axis  
	    XYPlot plot = jfreechart.getXYPlot();  
	    
	    plot.setForegroundAlpha(0.65F);
	    NumberAxis domain = (NumberAxis) plot.getDomainAxis();  
	    //domain.setRange(parseTimeStamp(response.getMinFlushTimeStamp()), parseTimeStamp(response.getMaxFlushTimeStamp()));
	    //System.out.println(parseTimeStamp(response.getMinFlushTimeStamp()));
	     domain.setLowerMargin(0.2);
	    domain.setUpperMargin(0.5);
	    
	    // Set range for Y-Axis  
	    NumberAxis range = (NumberAxis) plot.getRangeAxis();
	    range.setRange((double)response.getMinimumMemoryUsed(), (double)response.getMaximumMemoryUsed());
	    range.setLowerMargin(0.8);
	    range.setUpperMargin(0.9);

	    System.out.println((double)response.getMinimumMemoryUsed());
	    
		

		
		final DateFormat dateFormat = new SimpleDateFormat("MM-dd HH:mm");

		domain.setNumberFormatOverride(new NumberFormat() {
			@Override
			public StringBuffer format(double number, StringBuffer toAppendTo,
					FieldPosition pos) {
				return format((long) number, toAppendTo, pos);
			}

			@Override
			public StringBuffer format(long number, StringBuffer toAppendTo,
					FieldPosition pos) {
				return dateFormat.format(new Date(number), toAppendTo, pos);
			}

			@Override
			public Number parse(String source, ParsePosition parsePosition) {
				throw new UnsupportedOperationException();
			}
		});

		int width = 1080; /* Width of the image */
		int height = 960; /* Height of the image */
		File bubbleChart = new File(Constants.OUTPUT_FILE_PATH + "\\FlushGraph_" +(new Date()).getTime() +".jpeg");
		ChartUtilities.saveChartAsJPEG(bubbleChart, jfreechart, width, height);
		
	}
	
	private static XYZDataset createDataset(List<Log> logList) throws ParseException { 
		
	    DefaultXYZDataset dataset = new DefaultXYZDataset();  
	    dataset.addSeries(Constants.THREADNAME_SLABPOOLCLEANER, getGraphCoordinateValues(Constants.THREADNAME_SLABPOOLCLEANER, logList));  
	    dataset.addSeries(Constants.THREADNAME_COMMITLOGALLOCATOR,  getGraphCoordinateValues(Constants.THREADNAME_COMMITLOGALLOCATOR, logList));  
	    dataset.addSeries(Constants.THREADNAME_SCHEDULEDTASKS,  getGraphCoordinateValues(Constants.THREADNAME_SCHEDULEDTASKS, logList));  
	    
	    return dataset;  
	}
	
	private static double[][] getGraphCoordinateValues(String threadName, List<Log> logList) throws ParseException{
		
		List<Double> memoryList = new ArrayList<Double>();
		List<Double> timeStampList = new ArrayList<Double>();
		List<Double> countList = new ArrayList<Double>();
		
		for(Log log : logList){
			if(log.getThreadName().equalsIgnoreCase(threadName)){
				memoryList.add(log.getMemoryUsed());
				timeStampList.add(parseTimeStamp(log.getTimeStamp()));
				countList.add((double)10);
			}
		}
		System.out.println("ThreadName ::"+threadName);
		System.out.println("memoryList Size::"+memoryList.size());
		System.out.println("timeStamp Size::"+timeStampList.size());
		System.out.println("CountList Size::"+countList.size());
		
		System.out.println(memoryList.toString());
		System.out.println(timeStampList.toString());
		System.out.println(countList.toString());
		double[][] seriesValues = {unWrapDouble(memoryList),  
				unWrapDouble(timeStampList),unWrapDouble(countList)};
		return seriesValues;
	}
	
	private static double parseTimeStamp(String timeStamp) throws ParseException{
		DateFormat dateFormat = new SimpleDateFormat(Constants.DEFAULT_DATE_FORMAT);
		Date date = dateFormat.parse(timeStamp);
		return (double) date.getTime();
	}
	
	private static double[] unWrapDouble(List<Double> list){
		
		Double[] doubleArray = list.toArray(new Double[list.size()]);
		try{

			double[] array =  ArrayUtils.toPrimitive(doubleArray);
			return array;
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}
		return null;
	}

}
