package com.verizon.logparser.model;

public class Log {

	private String logType;
	private String timeStamp;
	private String className;
	private String threadName;
	private String description;
	private Integer timeInMilliSeconds;
	private Double memoryUsed;

	public Log() {

	}

	public Log(String logType, String timeStamp, String className, String threadName, String description) {
		this.logType = logType;
		this.timeStamp = timeStamp;
		this.className = className;
		this.threadName = threadName;
		this.description = description;
	}

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getTimeInMilliSeconds() {
		return timeInMilliSeconds;
	}

	public void setTimeInMilliSeconds(Integer timeInMilliSeconds) {
		this.timeInMilliSeconds = timeInMilliSeconds;
	}

	public Double getMemoryUsed() {
		return memoryUsed;
	}

	public void setMemoryUsed(Double memoryUsed) {
		this.memoryUsed = memoryUsed;
	}

}
