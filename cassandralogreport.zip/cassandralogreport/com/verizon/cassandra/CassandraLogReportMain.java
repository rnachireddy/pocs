package com.verizon.cassandra;

import com.verizon.cassandra.util.LogsLoadingUtil;

public class CassandraLogReportMain {

	public static void main(String[] args) {
		
		LogsLoadingUtil.loadLogsFromAllNodes(args[0], args[1]);

	}

}
