package com.verizon.constants;

public class RestConstants {
	
	public static final String DOCUMENT_SEARCH = "elastic/getThreadCount";
	
	public static final String DEFAULT_DELIMETER = " ";

}
