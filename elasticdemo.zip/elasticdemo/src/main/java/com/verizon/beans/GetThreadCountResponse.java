package com.verizon.beans;

public class GetThreadCountResponse {

	private String status;
	private String threadCount;

	public String getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(String threadCount) {
		this.threadCount = threadCount;
	}
	
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "GetThreadCountResponse [status=" + status + ", threadCount="
				+ threadCount + "]";
	}
	
	
}
