package com.verizon.beans;

import java.util.HashMap;

public class GetThreadCountResponse {

	private String status;
	private String totalThreadCount;
	private HashMap<String, Long> threads;

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTotalThreadCount() {
		return totalThreadCount;
	}

	public void setTotalThreadCount(String totalThreadCount) {
		this.totalThreadCount = totalThreadCount;
	}

	
	public HashMap<String, Long> getThreads() {
		return threads;
	}

	public void setThreads(HashMap<String, Long> threads) {
		this.threads = threads;
	}

	@Override
	public String toString() {
		return "GetThreadCountResponse [status=" + status
				+ ", totalThreadCount=" + totalThreadCount + ", threads="
				+ threads + "]";
	}

	
	
}
