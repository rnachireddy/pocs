package com.verizon.beans;

import javax.validation.constraints.NotNull;

public class GetThreadCountRequest {
	
	@NotNull
	private String threadName;

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	@Override
	public String toString() {
		return "GetThreadCountRequest [threadName=" + threadName + "]";
	}
	
	
	
	

}
