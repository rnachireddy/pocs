package com.verizon.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.verizon.beans.GetThreadCountRequest;
import com.verizon.beans.GetThreadCountResponse;
import com.verizon.constants.RestConstants;
import com.verizon.helper.GetThreadCountHelper;

@RestController
@ControllerAdvice
@Configuration
@EnableAutoConfiguration
public class ElasticParserController {
	
	private Logger log = LoggerFactory.getLogger(getClass().getName());
	private ResourceLoader resourceLoader;
	
	@Autowired
	GetThreadCountHelper helper;
	
	@RequestMapping(value = RestConstants.DOCUMENT_SEARCH, method = RequestMethod.POST)
	public String getThreadCount(@Valid @RequestBody GetThreadCountRequest request,
	BindingResult result){
		
		GetThreadCountResponse response = null;
		String jsonResponse = null;
		BufferedReader reader = null;
		
		log.info("Incoming thread count Request :: {}", request.toString());
		String searchString = request.getThreadName();
		try{
			ClassLoader classLoader = getClass().getClassLoader();
			File file = new File(classLoader.getResource("debug.log").getFile());
			
			reader = new BufferedReader(new FileReader(file)); 
			
			response = helper.countOccurences(reader, searchString);
			
		} catch(Exception e){
			log.error("Error while parsing the Document :: {}", e);
		} finally {
			if(reader != null)
				try {
					reader.close();
				} catch (IOException e) {
					log.error("Error while closing conneciton :: {}", e);
				}
		}
		jsonResponse = new Gson().toJson(response);
	return jsonResponse;	
	}

}
