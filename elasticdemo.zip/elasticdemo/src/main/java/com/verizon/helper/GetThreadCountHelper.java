package com.verizon.helper;

import org.springframework.stereotype.Service;

@Service
public class GetThreadCountHelper {
	
	public int countOccurences(String str, String searchString, String delimiter) {
		String a[] = str.split(delimiter);
		int count = 0;
		for (int i = 0; i < a.length; i++) {
			if (searchString.equals(a[i]))
				count++;
		}
		return count;
	} 

}
