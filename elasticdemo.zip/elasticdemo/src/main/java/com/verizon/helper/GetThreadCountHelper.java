package com.verizon.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.verizon.beans.GetThreadCountResponse;
import com.verizon.constants.RestConstants;

@Service
public class GetThreadCountHelper {
	
	private Logger log = LoggerFactory.getLogger(getClass().getName());
	
	public GetThreadCountResponse countOccurences(BufferedReader reader, String searchString) throws IOException, ParseException {
		
		String line = null;
		String threadName = null;
		String timeStamp = null;
		GetThreadCountResponse response = null;
		HashMap<String,String> duration = null;
		HashMap<String,HashMap<String, String>> hm = new HashMap<String,HashMap<String, String>>();
		HashMap<String, Long> responseMap = new HashMap<String, Long>();
		
		do {
			line = reader.readLine();
			if((line != null && line.length() > 0) && line.contains(searchString)){
				/*String a[] = line.split( RestConstants.DEFAULT_DELIMETER);
				for (int i = 0; i < a.length; i++)  { 
					//	if match found increase count 
					if (a[i].contains(searchString)) {
						//count++;
						String threadName = matchString(line);
						if(hm.containsKey(threadName)){
							Integer value = hm.get(threadName);
							value++;
							hm.put(threadName, value);
						}else{
							hm.put(threadName, 1);
						}
					}// End if
				}// End for*/
				String tokens[] = line.split( RestConstants.DEFAULT_DELIMETER);
				threadName = matchString(line);
				log.info("tokens ::"+tokens[2]+" "+tokens[3]+" "+tokens[4]+" "+tokens[5]+" "+tokens[6]);
				if(tokens[2].contains("TCP")){
					timeStamp = tokens[4]+" "+tokens[5];
				}else if(tokens[2].contains("Thread")){
					timeStamp = tokens[3]+" "+tokens[4];
				}else{
					timeStamp = tokens[2]+" "+tokens[3];
				}
				log.info("Thread Name :: "+threadName);
				log.info("Time Stamp ::"+timeStamp);
				if(hm.containsKey(threadName)){
					hm.put(threadName, getDuration(hm.get(threadName), timeStamp));
				}else{
					duration = new HashMap<String,String>();
					duration.put(timeStamp, timeStamp);
					hm.put(threadName, duration);
				}
			}
		}while(line != null);
		response = new GetThreadCountResponse();
		response.setStatus("success");
		response.setTotalThreadCount(String.valueOf(hm.size()));
		for (Map.Entry<String, HashMap<String, String>> entry : hm.entrySet()) {
			responseMap.put(entry.getKey(), getDuration(entry.getValue()));
		}
		response.setThreads(responseMap);
	return response;
	} 
	
	public String matchString(String str){
		

		Pattern p = Pattern.compile("\\[(.*?)\\]");
		Matcher m = p.matcher(str);

		while(m.find()) {
		   return m.group(1);
		}
		
		return "";
	}
	
	public HashMap<String, String> getDuration(HashMap<String, String> duration, String endTimeStamp){
		String key = null;
		for (Map.Entry<String, String> e : duration.entrySet()) {
		    key = e.getKey();
		}
		duration.put(key, endTimeStamp);
	return duration;
	}
	
	public long getDuration(HashMap<String, String> interval) throws ParseException{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss,s");
		Date startDate = null;
		Date endDate = null;
		for (Map.Entry<String, String> e : interval.entrySet()) {
			log.info("Thread Start time stamp::"+e.getKey());
			log.info("Thread End time stamp::"+e.getValue());
		   startDate =  dateFormat.parse(e.getKey());
		   endDate = dateFormat.parse(e.getValue());
		}
	return endDate.getTime()-startDate.getTime();
	}

}
