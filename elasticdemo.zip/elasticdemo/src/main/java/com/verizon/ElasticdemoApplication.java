package com.verizon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages = { "com.verizon"})
public class ElasticdemoApplication{
	
	public static void main(String[] args) {
		SpringApplication.run(ElasticdemoApplication.class, args);
	}
}
